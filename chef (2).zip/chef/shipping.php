<?php
session_start();
ob_start();
error_reporting(0);
include('includes/products-management.php');
$dbFactory= new ProductsManagement();
 

?>
<!DOCTYPE  html>
<html lang="en">

<head>
  <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>DeleciousAndhra</title>


    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="css/animate.css" type="text/css">
	<link rel="stylesheet" href="font-awesome-4.2.0/css/font-awesome.min.css" type="text/css">
    
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script> 
    <script src="js/bootstrap.min.js"></script> 
    <script src="js/scripts.js"></script>
    <!-- Just include this Js file -->
	<script src="./js/jquery.carousel.fullscreen.js"></script>
    <script>
	function newshipp()
{

//alert("prasad");



//alert(t);	
  document.getElementById("newshipping").style.display = "block";

	 
		
 document.getElementById("oldshippingid").style.display = "none";


}
function oldshipp()
{

//alert("prasad");



//alert(t);	
  document.getElementById("newshipping").style.display = "none";

	 
		
 document.getElementById("oldshippingid").style.display = "block";


}
</script>
    <style>
#map-canvas {
	width: 100%;
	height: 320px;
}
</style>
<script type="text/javascript">
        function myFunction()

{

document.getElementById("myForm").submit();

}</script> 
<script  type="text/javascript">
function myfunction(a)
{
	
if(a==1)
{
	//alert(a);
	 if(document.getElementById('my1').className!='active')
	 {
		
		  	 document.getElementById('my2').className='';
		 	 document.getElementById('my3').className='';
			 	 document.getElementById('my4').className='';
	  document.getElementById('my1').className='active';
	
	 }
	}
	if(a==2)
{
	//alert(a);
		 if(document.getElementById('my2').className!='active')
		 {
	
				document.getElementById('my1').className='';
				
		 	 document.getElementById('my3').className='';
			 	 document.getElementById('my4').className='';
	    document.getElementById('my2').className ='active';
		 }
	}
	
	if(a==3)
{
	//alert(a);
		 if(document.getElementById('my3').className!='active'){
			  	 document.getElementById('my2').className='';
			
		 	 document.getElementById('my1').className='';
			 	 document.getElementById('my4').className='';
	    document.getElementById('my3').className = 'active';
		}
	}
	if(a==4)
{
	//alert(a);
		 if(document.getElementById('my4').className!='active'){
			  document.getElementById('my2').className='';
		 	 document.getElementById('my3').className='';
			 	 document.getElementById('my1').className='';
	    document.getElementById('my4').className = 'active';
		
		
		 	
			}
	}	
}

</script> 


<script src="jquery.js"></script> 
<script src="jquery.validate.js"></script> 
<script>

	



	$().ready(function() {

		// validate the comment form when it is submitted

		



		// validate signup form on keyup and submit

		$("#commentForm").validate({

			rules: {

				USERNAME: "required",

				

				EMAIL: {

					required: true,

					email: true,
                 equalTo:"#email_mess"
					

				},
				
				
		

				PASSWORD: {

					required: true,

					minlength: 5

				},

	

			PHONE: {

				required: true,

                            number: true,

							minlength:10,

							maxlength:10

			},

			

		

				

			},

			messages: {

				USERNAME: "Please enter your USERNAME",

					EMAIL: {

					required: "please enter email",

					email: "please enter a valide email address",

					 equalTo:""

				},
			

		

			

				PASSWORD: {

					required: "Please provide a password",

					minlength: "Your password must be at least 5 characters long"

				},

				PHONE: {

				required: "Please enter your phone number",

                            number: "enter digits only",

							minlength:"enter 10 digits mobile number",

							maxlength:"enter 10 digits mobile number"

			},

				

			

			}

		});



	





	});
	

	
	$().ready(function() {
    //simple example 1
    //click event for first button 

        $("#oldshipform").validate(
		
		{

			rules: {
				delivery_date_old: "required",
	
		
				shippingdetails:"required"

			},
			messages: {
				delivery_date_old: "please select Delivery Date",
		
					shippingdetails: "please select address"
				
		}

		}); //validate form 1
		
		
		
    $('#oldshipsubmit').click(function() {
			//alert("plras");
        if ($('#oldshipform').valid()) {
		
		
			

	
		
	 var newurl = '#settings';
          var newurl1 = 'tab';
		 // alert(newurl);
		  //alert(newurl1);
//$('a[href="http://google.com"]').attr('href', 'http://yahoo.com');
          
          //$('a[href="' + oldurl + '"').attr('href', newurl);
          
          // it's not working too...
          $('#oldshipsubmit').attr('href', newurl);
		   $('#oldshipsubmit').attr('data-toggle', newurl1);
		   
		   //active Payment tab class script start
		   if(document.getElementById('my4').className!='active'){
			  document.getElementById('my2').className='';
		 	 document.getElementById('my3').className='';
			 	 document.getElementById('my1').className='';
	    document.getElementById('my4').className = 'active';
		
	
        } 
			         <?php

$s=$dbFactory->address_old_details($_SESSION[user_id]);
?>
for(var i = 0; i < <?php echo count($s);?>; i++){
		if (document.getElementById('shippingdetails'+i).checked) {
			//alert("prasad");
			
			e=document.getElementById('shippingdetails'+i).value;
document.getElementById('oldaddress').value=e;
	document.getElementById('oldaddress1').value=e;
}
}
			
				
	
				var e=document.getElementById('delivery_date_old').value;

		
	
	document.getElementById('newship_name').value='';
	document.getElementById('newshippingaddress').value='';
		document.getElementById('newship_city').value='';
	document.getElementById('newship_state').value='';
		document.getElementById('newship_postal_code').value='';
	document.getElementById('newship_country').value='';
		document.getElementById('newdelivery_date').value=e;
	document.getElementById('newship_phone').value='';
	
		document.getElementById('newship_name1').value='';
	document.getElementById('newshippingaddress1').value='';
		document.getElementById('newship_city1').value='';
	document.getElementById('newship_state1').value='';
		document.getElementById('newship_postal_code1').value='';
	document.getElementById('newship_country1').value='';
		document.getElementById('newdelivery_date1').value=e;
	document.getElementById('newship_phone1').value='';
		
		}
    });
	
	
	
	        $("#newshipform").validate(
		
		{

			rules: {
				ship_name1: "required",
	
		
				shipping1:"required",
				ship_city1: "required",
	
		
				ship_state1:"required",
				ship_postal_code1: "required",
	
		
				ship_phone1:"required",
					delivery_date1: "required"

			},
			messages: {
				ship_name1: "please enter name",
		
					shipping1: "please enter your address",
						ship_city1: "please enter your city",
		
					ship_state1: "please enter your state",
						ship_postal_code1: "please enter postal code",
		
					ship_phone1: "please enter mobile no",
						delivery_date1: "please select Delivery Date"
		
			
				
				
				
				
		}

		}); //validate form 1
		
		
		
    $('#newshipsubmit').click(function() {
			//alert("plras");
        if ($('#newshipform').valid()) {
		
	
		
	 var newurl = '#settings';
          var newurl1 = 'tab';
		 // alert(newurl);
		  //alert(newurl1);
//$('a[href="http://google.com"]').attr('href', 'http://yahoo.com');
          
          //$('a[href="' + oldurl + '"').attr('href', newurl);
          
          // it's not working too...
          $('#newshipsubmit').attr('href', newurl);
		   $('#newshipsubmit').attr('data-toggle', newurl1);
		   
		   //active Payment tab class script start
		   if(document.getElementById('my4').className!='active'){
			  document.getElementById('my2').className='';
		 	 document.getElementById('my3').className='';
			 	 document.getElementById('my1').className='';
	    document.getElementById('my4').className = 'active';

        } 
		
		
				
		
document.getElementById('oldaddress').value='';
	document.getElementById('oldaddress1').value='';

		
						var e=document.getElementById('ship_name1').value;
document.getElementById('newship_name').value=e;
	document.getElementById('newship_name1').value=e;
	
	
	var e=document.getElementById('shipping1').value;
	//alert(e);
document.getElementById('newshippingaddress').value=e;
	document.getElementById('newshippingaddress1').value=e;
	
		var e=document.getElementById('ship_city1').value;
document.getElementById('newship_city').value=e;
	document.getElementById('newship_city1').value=e;
	
			var e=document.getElementById('ship_state1').value;
document.getElementById('newship_state').value=e;
	document.getElementById('newship_state1').value=e;
	
	
		var e=document.getElementById('ship_postal_code1').value;
document.getElementById('newship_postal_code').value=e;
	document.getElementById('newship_postal_code1').value=e;
	
	
		var e=document.getElementById('ship_country1').value;
document.getElementById('newship_country').value=e;
	document.getElementById('newship_country1').value=e;
	
		
		var e=document.getElementById('ship_phone1').value;
document.getElementById('newship_phone').value=e;
	document.getElementById('newship_phone1').value=e;
	
	
		var e=document.getElementById('delivery_date1').value;
		//alert(e);
document.getElementById('newdelivery_date').value=e;
	document.getElementById('newdelivery_date1').value=e;
		
		}
    });
	
	
	
	 $("#newshipformfirst").validate(
		
		{

			rules: {
				
	
		
				shipping2:"required",
				ship_city2: "required",
	
		
				ship_state2:"required",
				ship_postal_code2: "required",
	
		
				ship_phone2:"required",
					delivery_date2: "required"

			},
			messages: {
				ship_name2: "please enter name",
		
					shipping2: "please enter your Address",
						ship_city2: "please enter city",
		
					ship_state2: "please enter state",
						ship_postal_code2: "please enter postal code",
		
					ship_phone2: "please enter mobile no",
						delivery_date2: "please select Delivery Date"
		
			
				
				
				
				
		}

		}); //validate form 1
	
	$('#newshipsubmitfirst').click(function() {
			//alert("plras");
        if ($('#newshipformfirst').valid()) {
		

		
		
		
		
	 var newurl = '#settings';
          var newurl1 = 'tab';
		 // alert(newurl);
		  //alert(newurl1);
//$('a[href="http://google.com"]').attr('href', 'http://yahoo.com');
          
          //$('a[href="' + oldurl + '"').attr('href', newurl);
          
          // it's not working too...
          $('#newshipsubmitfirst').attr('href', newurl);
		   $('#newshipsubmitfirst').attr('data-toggle', newurl1);
		   
		   
		   		

		   
		   //active Payment tab class script start
		   if(document.getElementById('my4').className!='active'){
			  document.getElementById('my2').className='';
		 	 document.getElementById('my3').className='';
			 	 document.getElementById('my1').className='';
	    document.getElementById('my4').className = 'active';

        } 
		
			
document.getElementById('oldaddress').value='';
	document.getElementById('oldaddress1').value='';

						var e=document.getElementById('ship_name2').value;
document.getElementById('newship_name').value=e;
	document.getElementById('newship_name1').value=e;
	
var f=document.getElementById('shipping2').value;
	//alert(f);
document.getElementById('newshippingaddress').value=f;
	document.getElementById('newshippingaddress1').value=f;
	
		var g=document.getElementById('ship_city2').value;
	//alert(g);
document.getElementById('newship_city').value=g;
	document.getElementById('newship_city1').value=g;
	
			var e=document.getElementById('ship_state2').value;
document.getElementById('newship_state').value=e;
	document.getElementById('newship_state1').value=e;
	
	
		var e=document.getElementById('ship_postal_code2').value;
document.getElementById('newship_postal_code').value=e;
	document.getElementById('newship_postal_code1').value=e;
	
	
		var e=document.getElementById('ship_country2').value;
document.getElementById('newship_country').value=e;
	document.getElementById('newship_country1').value=e;
	
		
		var e=document.getElementById('ship_phone2').value;
document.getElementById('newship_phone').value=e;
	document.getElementById('newship_phone1').value=e;
	
	
		var e=document.getElementById('delivery_date2').value;
		//alert(e);
document.getElementById('newdelivery_date').value=e;
	document.getElementById('newdelivery_date1').value=e;

	
		
		
		
		


		
		}
    });
	   

	 });



	</script>
<style>



	form.form1 label.error, label.error {

	/* remove the next line when you have trouble in IE6 with labels in list */

	color: red;

	font-style: italic

}






	</style>
</head>


<body>
	
	<?php include("includes/menu.php"); ?>
    
    <div class="container">
      <h3 class="page-header">Shipping</h3>
      <!-- Content Row -->
      <div class="row"> 
       <ul class="nav nav-tabs" role="tablist">
           <?php if($_REQUEST[mes]==6){?>
            <li id="my2"><a href="#profile" role="tab" data-toggle="tab"> <i class="fa fa-user"></i> ORDER SUMMERY </a> </li>
            <li class="active"  id="my1"> <a href="#home" role="tab" data-toggle="tab">
              <icon class="fa fa-home"></icon>
              SIGN IN </a> </li>
            <li id="my3"> <a <?php if($_SESSION[user_id]!=0&&count($_SESSION[products])!=0){?> href="#messages"  role="tab" data-toggle="tab" id="shippingreturn"<?php }?>  > <i class="fa fa-envelope"></i> SHIPPING </a> </li>
            <li id="my4"> <a > <i class="fa fa-cog"></i> PAYMENT </a> </li>
            <?php } else{?>
            <li class="active" id="my2"><a href="#profile" role="tab" data-toggle="tab"> <i class="fa fa-user"></i> ORDER SUMMERY </a> </li>
            <li  id="my1"> <a href="#home" role="tab" data-toggle="tab">
              <icon class="fa fa-home"></icon>
              SIGN IN </a> </li>
        
            <li id="my3"> <a <?php if($_SESSION[user_id]!=0&&count($_SESSION[products])!=0){?> href="#messages"   role="tab" data-toggle="tab" id="shippingreturn" <?php }?>> <i class="fa fa-envelope"></i> SHIPPING </a> </li>
            <li id="my4"> <a  <?php if($_SESSION[user_id]!=0&&count($_SESSION[products])!=0){?>  href="#settings"  role="tab" data-toggle="tab"<?php }?> > <i class="fa fa-cog"></i> PAYMENT </a> </li>
            <?php }?>
          </ul>
    <!-- Contact Details Column -->
     <div class="tab-content">
    <div class="tab-pane fade <?php if($_REQUEST[mes]!=6){?>active in<?php }?>" id="profile">
              <form id="myForm">
                <div class="table-responsive">
                  <?php if($_GET[mes]==1){?>
                  <strong style="color:#FF0000">Please select between 1 and 10</strong>
                  <?php }?>
                  <?php if(count($_SESSION[products])==0){?>
                  <div class="alert alert-danger" style="margin:15px 0;" role="alert"> Your Order is Empty <a href="index.php" class="alert-link">Continue for shopping</a> Please Select the Items </div>
                  <?php /*}?>
                  <?php
 					if(count($_SESSION[products])==0){?>
                  	No Products Are There In Cart.
                  <?php*/ } else {?>
                  <table class="table table-bordered table-condensed tb2">
                    <tbody>
                      <tr>
                        <th>ITEM</th>
                        <th>ITEM NAME</th>
                        <th>QTY</th>
                        <th>PRICE</th>
                        <th>DELIVARY DETALS</th>
                        <th>SUB TOTAL</th>
                       <!-- <th></th>-->
                      </tr>
                      <?php
   $product_del_dates=implode(",",$_SESSION[products]);
     // $product_dlvry_dates=$dbFactory->products_delivery_dates($product_del_dates);
	 $_SESSION[delivery_days]=$product_dlvry_dates[0][0];
   
   $total=0;
   

  for($i=0;$i<count($_SESSION[products])&&$_SESSION[products][0]!='';$i++){

   $s=$dbFactory->details_item($_SESSION[products][$i]);
  // echo count($s);
   

   

   ?>
                      <tr>
                        <td class="it1"><img src="admin/images/<?php echo $s[0][PIC_ID];?>.jpg" alt="" style="display:inline-block; width:100px;" /></td>
                        <td class="it2" style="color:#0A3151; text-align:center; font-size:16px;"><strong><?php echo $s[0][IMG_NAME];?></strong><br>
                          <?php echo $_SESSION[fieldvalues][$i];?></td>
                        <td class="it3" style="text-align:center;"><input type="text" name="quantity[]" readonly value="<?php echo $_SESSION[qnty][$i];?>" onKeyPress="return isNumberKey(event)" class="form-control" style="width:30px; height: 23px; display:inline-block; position:relative; padding:0;" id="45" autocomplete="off" oncopy="return false" ondrag="return false" ondrop="return false" onpaste="return false">
                         <!-- <img src="images/view_refresh.png" onClick="myFunction()" class="img-responsive" width="16px" />--> </a></td>
                        <td class="it4" style="text-align:center; font-size:18px"><?php    if($_SESSION[price_id][$i]=='')echo $s[0][COST];
						else {
						
						  $price_change_vlaue=$dbFactory->price_change_fileterer_detail_value($_SESSION[price_id][$i],$_SESSION[products][$i]);
						  
						echo $pricevaluediffer=$price_change_vlaue[0][PRODUCT_COST_VALUE];
						  
						
						
						}
						?></td>
                        <td class="it5" style="text-align:center;">Delivered in 2-3 business days.</td>
                        <td class="it6" style="text-align:right; font-size:18px"><?php if($_SESSION[price_id][$i]=='')echo $_SESSION[qnty][$i]*$s[0][COST];
						
						else echo $_SESSION[qnty][$i]*$pricevaluediffer; if($_SESSION[price_id][$i]=='')$total=$total+$_SESSION[qnty][$i]*$s[0][COST];
						else  $total=$total+$_SESSION[qnty][$i]*$pricevaluediffer; ?></td>
                       <!-- <td class="it7" style="text-align:center;"><a href="checkout.php?delete=<?php echo $_SESSION[products][$i];?>">
                          <button type="button" class="close" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                          </a></td>-->
                      </tr>
                      <?php }?>
					                            <?php $_SESSION[total]=$total;?>
                      <tr>
                        <td colspan="6" style="text-align:right; font-size:18px"><span class="label label-warning pull-left">Shipping :
                          <?php if($_SESSION[total]>1000) echo "Free"; else echo "Rs 100";?>
                          </span> TOTAL : RS.
                          <?php
					  if($_SESSION[total]<1000) echo $_SESSION[total]=$total+100; else echo $_SESSION[total]=$total; ?></td>
                        <td>&nbsp;</td>
                      </tr>
                      <?php 
if($_SESSION[coupon-code-val]!=''){  
 $coupon=$dbuser->coupon_check($_SESSION[coupon-code-val]);
//print_r( $coupon);

if($coupon[0][COUPON_VALUE]>0){  
$_SESSION[total]=$_SESSION[total]-$coupon[0][COUPON_VALUE];

?>
                      <tr>
                        <td colspan="6" style="text-align:right;"><strong>FINAL TOTAL: RS.<?php echo $_SESSION[total]; ?></strong></td>
                        <td>&nbsp;</td>
                      </tr>
                      <?php }}?>
                        </tr>
                      
                    </tbody>
                    <tfoot style="background: #ddd; padding: 5px;">
                      <tr>
                        <td colspan="4"><input class="form-control" style="margin:15px 0;" name="coupon-code" placeholder="Enter Your Coupon Code" type="text" value="<?php echo $_SESSION[coupon-code-val];?>"></td>
                        <td colspan="2"><input type="submit" value="Apply" style="margin:15px 0;" class="btn btn-warning"  onclick="myfunction(2);"/>
                          <?php 
if($_SESSION[coupon-code-val]!=''){  
if(count($coupon)==0) {?>
                          <span style="margin-left:8px; color:red;">Invalid coupon-code</span>
                          <?php } 
else{
?>
                          <span style="margin-left:8px; color:green;">coupon value <?php echo $coupon[0][COUPON_VALUE];?> Applied </span>
                          <?php }}?></td>
                        <td><?php if(count($_SESSION[products])!=0){?>
                          <a href="#home" aria-controls="home" role="tab" data-toggle="tab" >
                          <button class="col-lg-12 btn btn-warning" style="margin:15px 0;" type="submit" value="Submit" onClick="myfunction(1)">Next</button>
                          </a>
                          <?php }?></td>
                      </tr>
                      <?php }?>
                    </tfoot>
                  </table>
                </div>
                
               <!-- <a href="checkout.php?clear" class="btn btn-danger pull-left"> Clear All </a> <a href="" class="btn btn-primary pull-right" style="float:right">Continue Shopping</a> -->
                
                <!--</div>-->
              </form>
            </div>
            
            
            <div class="tab-pane fade <?php if($_REQUEST[mes]==6){?>active in<?php }?>" id="home">
              <?php if($_SESSION[user_id]!=''){?>
              <div class="alert alert-success" style="margin:15px 0;" role="alert"> You have already Login please <a href="#messages" class="alert-link">Continue</a> </div>
              <a href="#messages" aria-controls="profile" role="tab" data-toggle="tab" style="display:inline-block; float:right; margin:0;">
              <input type="submit" class="btn btn-primary" name="continue1" value="Next" onClick="myfunction(3)"/>
              </a>
              <?php }else{?>
              <div class="row login_box"  style="margin:15px auto; padding:0 15px">
                <div class="page-header">
                  <h2 align="center" style="color:#f33; margin:0; padding:0;">Login</h2>
                </div>
                <div class="modal-body">
                  <div style="display:none;<?php if($_REQUEST[mess]==1){?>display:block<?php }?>">
                    <div class="alert alert-dismissable alert-danger">
                      <button type="button" class="close" data-dismiss="alert">&#x2715;</button>
                      <strong>Invalid Credentials</strong> </div>
                  </div>
                  <form class="form-horizontal" role="form" method="post" id="">
                    <div class="form-group">
                      <label for="inputEmail3" class="control-label">Email</label>
                      <input type="text"  name="EMAIL" class="form-control" id="inputEmail3" placeholder="Email">
                    </div>
                    <div class="form-group">
                      <label for="inputPassword3" class=" control-label">Password</label>
                      <input type="password"  name="PASSWORD"  class="form-control" id="inputPassword3" placeholder="Password">
                    </div>
                    <div class="form-group">
                      <div class="col-sm-12" style="text-align:center;">
                        <input type="submit" class="btn btn-primary" name="login" value="Login" />
                        <a  data-toggle="modal" data-target="#myModal1" class="btn btn-danger">Register</a> </div>
                    </div>
                  </form>
                </div>
              </div>
              <?php }?>
            </div>
            
            
            
     <div class="tab-pane fade" id="messages" >

            
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" >
                  <h2>Shipping</h2>
                  <!--<h4>Thanks for shopping with us</h4>--> 
                </div>
              
                 <?php


$s=$dbFactory->address_old_details($_SESSION[user_id]);

 if(count($s)!=0)
 {?>
  <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12"  >   
              <input type="radio" name="shippingnames"  onclick="oldshipp()" checked="checked"/> Select Delivery address in our records. 
              </div>
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" id="oldshippingid">
                   
                  <form class="form-horizontal oldshipform " id="oldshipform" name="formshipping"  method="post" autocomplete="off" > 
          
                   <select name="delivery_date_old"  id="delivery_date_old" class="form-control" required>
                      <option value="" >Delivery Date <span style="color:#F00">*</span></option>
                                            <?php
error_reporting(0);
$z=$_SESSION[delivery_days];
for($i=1;$i<=20;$i++)
{
$theDate =  date("Y-m-d");

$timeStamp = StrToTime($theDate);

$in6days = StrToTime('+'.$z.' days', $timeStamp);
 

?>
  <option value="<?php echo date('Y-m-d', $in6days); ?>"><?php echo date('d-F-Y', $in6days);?></option><?php $z=$z+1;}?>
                    </select>
           <?php

$s=$dbFactory->address_old_details($_SESSION[user_id]);

for($i=0; $i<count($s); $i++){

//if($d[$i][person]=='')continue;


?>
                
               <div class="col-xs-12 col-sm-4 col-md-3 col-lg-3" style="border:solid 1px #000 ; margin:5px;padding:10px" >
               
                     <input type="radio" name="shippingdetails" value="<?php echo $s[$i][ADDRESS_ID];?>" id="shippingdetails<?php echo $i;?>"/> <?php echo $s[$i][SHIPP_NAME];?>
                  <div style="overflow:auto">   
                     <?php echo $s[$i][SHIPP_ADDRESS];?>,<br /><?php echo $s[$i][SHIPP_CITY];?>,<br /><?php echo $s[$i][SHIPP_POSTAL_CODE];?>.</div>
                         <label   style="color:#FF0000" ></label>
               
               </div>
         <?php }?>
         <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 pull-right"  >   
              
                                   <button  style="float:right;"  class="btn btn-primary "    href="" data-toggle="" 
                                   id="oldshipsubmit"  >Next</button>
              </div>
           
              </form>
              
                  <!--<h4>Thanks for shopping with us</h4>--> 
                </div>
                
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" >  
              <input type="radio" name="shippingnames"   onclick="newshipp()"/> Or enter new delivery Address 
                    </div>
                <div class=" col-xs-12 col-sm-12 col-md-6 col-lg-6"  style="display:none;" id="newshipping" >
                  <div class="row "> 		
                    <?php   $profile=$dbFactory->user_details($_SESSION[user_id]);?>
                    <!--<strong>Delivery Address</strong> <strong  class="pull-right" onclick="function2()">Copy</strong>
<textarea name="frcr" class="form-control" id="shipping1">
</textarea>-->  <form class="form-horizontal" id="newshipform" name="formshipping"  method="post" autocomplete="off">
                    <div class=" col-xs-12 col-sm-12 col-md-12 col-lg-12" style="padding:10px" >
                    <input name="ship_name1" type="text" placeholder="name *"  id="ship_name1" class="form-control"  />
                    
                    </div>
                           <div class=" col-xs-12 col-sm-12 col-md-12 col-lg-12" style="padding:10px" >
                    <textarea name="shipping1" placeholder="Address *" class="form-control" id="shipping1"></textarea>
                    </div>
                           <div class=" col-xs-12 col-sm-12 col-md-12 col-lg-12" style="padding:10px" >
                    <input name="ship_city1" type="text"  placeholder="City *"  id="ship_city1" class="form-control"/>
                    </div>
                           <div class=" col-xs-12 col-sm-12 col-md-12 col-lg-12" style="padding:10px">
                    <input name="ship_state1" type="text"  placeholder="State/Province *"  id="ship_state1" class="form-control"/>
                    </div>
                           <div class=" col-xs-12 col-sm-12 col-md-12 col-lg-12" style="padding:10px">
                    <input name="ship_postal_code1" type="text" placeholder="Postal Code *"  id="ship_postal_code1" class="form-control"/>
                    </div>
                           <div class=" col-xs-12 col-sm-12 col-md-12 col-lg-12"style="padding:10px" >
                    <select name="ship_country1" id="ship_country1" class="form-control">
                      <option value="IND">India</option>
                    </select>
                    </div>
                           <div class=" col-xs-12 col-sm-12 col-md-12 col-lg-12" style="padding:10px">
                     
                    <input name="ship_phone1" type="text" placeholder="Telephone *" id="ship_phone1" class="form-control"/>
                    </div>
                           <div class=" col-xs-12 col-sm-12 col-md-12 col-lg-12" style="padding:10px">
                     <select name="delivery_date1"  id="delivery_date1" class="form-control" required>
                      <option value="" >Delivery Date <span style="color:#F00">*</span></option>
                                            <?php
error_reporting(0);
$z=$_SESSION[delivery_days];
for($i=1;$i<=20;$i++)
{
$theDate =  date("Y-m-d");

$timeStamp = StrToTime($theDate);

$in6days = StrToTime('+'.$z.' days', $timeStamp);
 

?>
  <option value="<?php echo date('Y-m-d', $in6days); ?>"><?php echo date('d-F-Y', $in6days);?></option><?php $z=$z+1;}?>
                    </select>
                    </div>
                          
              </form><span  style="margin: 10px 0;
display:inline-block">*DENOTES </span> <a href="https://support.ebs.in/index.php?_m=knowledgebase&_a=viewarticle&kbarticleid=183&nav=0,5,2" target="_blank" class="style2"><em>mandatory fields</em></a> <br /><br />
                    <!--<a href="ebs/pay.php">EBS payment</a>--> 
                  </div>
                </div>
                
                 <?php } else{?>
                <div class=" col-xs-12 col-sm-12 col-md-6 col-lg-6"   >
                  <div class="row "> 		
                    <?php   $profile=$dbFactory->user_details($_SESSION[user_id]);
					//echo $profile[0][USER_NAME];?>
                    <!--<strong>Delivery Address</strong> <strong  class="pull-right" onclick="function2()">Copy</strong>
<textarea name="frcr" class="form-control" id="shipping1">
</textarea>-->  <form class="form-horizontal" id="newshipformfirst" name="formshipping"  method="post" autocomplete="off" >
                    <div class=" col-xs-12 col-sm-12 col-md-12 col-lg-12" style="padding:10px" >
                    <input name="ship_name2" type="text" placeholder="name *"  id="ship_name2" class="form-control"  />
                    
                    </div>
                           <div class=" col-xs-12 col-sm-12 col-md-12 col-lg-12" style="padding:10px" >
                    <textarea name="shipping2" placeholder="Address *" class="form-control" id="shipping2"></textarea>
                    </div>
                           <div class=" col-xs-12 col-sm-12 col-md-12 col-lg-12" style="padding:10px" >
                    <input name="ship_city2" type="text"  placeholder="City *"  id="ship_city2" class="form-control"/>
                    </div>
                           <div class=" col-xs-12 col-sm-12 col-md-12 col-lg-12" style="padding:10px">
                    <input name="ship_state2" type="text"  placeholder="State/Province *"  id="ship_state2" class="form-control"/>
                    </div>
                           <div class=" col-xs-12 col-sm-12 col-md-12 col-lg-12" style="padding:10px">
                    <input name="ship_postal_code2" type="text" placeholder="Postal Code *"  id="ship_postal_code2" class="form-control"/>
                    </div>
                           <div class=" col-xs-12 col-sm-12 col-md-12 col-lg-12"style="padding:10px" >
                    <select name="ship_country2" id="ship_country2" class="form-control">
                      <option value="IND">India</option>
                    </select>
                    </div>
                           <div class=" col-xs-12 col-sm-12 col-md-12 col-lg-12" style="padding:10px">
                     
                    <input name="ship_phone2" type="text" placeholder="Telephone *" id="ship_phone2" class="form-control"/>
                    </div>
                           <div class=" col-xs-12 col-sm-12 col-md-12 col-lg-12" style="padding:10px">
                     <select name="delivery_date2"  id="delivery_date2" class="form-control" required>
                      <option value="" >Delivery Date <span style="color:#F00">*</span></option>
                                            <?php
error_reporting(0);
$z=$_SESSION[delivery_days];
for($i=1;$i<=20;$i++)
{
$theDate =  date("Y-m-d");

$timeStamp = StrToTime($theDate);

$in6days = StrToTime('+'.$z.' days', $timeStamp);
 

?>
  <option value="<?php echo date('Y-m-d', $in6days); ?>"><?php echo date('d-F-Y', $in6days);?></option><?php $z=$z+1;}?>
                    </select>
                    </div>
                          <div class=" col-xs-12 col-sm-12 col-md-12 col-lg-12" style="padding:10px">
                    
                                   <input type="button" name="shippingconfirm"  style="float:right;"class="btn btn-primary " value="Next"   href="" data-toggle="" id="newshipsubmitfirst"  />
                                   </div>
              </form><span  style="margin: 10px 0;
display:inline-block">*DENOTES </span> <a href="https://support.ebs.in/index.php?_m=knowledgebase&_a=viewarticle&kbarticleid=183&nav=0,5,2" target="_blank" class="style2"><em>mandatory fields</em></a> <br /><br />
                    <!--<a href="ebs/pay.php">EBS payment</a>--> 
                  </div>
                </div>
                  <?php }?>
              
               
               </div>
               <div class="tab-pane fade" id="settings" >
              <h2>Payment Options</h2>
              <div style="color:#F36E2B; font-weight:bold">Hello <?php echo $profile[0][USER_NAME];;?>, Total Amount to be Paid: RS.<?php echo $_SESSION[total]; ?></div>
              <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6" style="text-align:center;">
                <form action="usertransactions.php" method="post" id="cash">
                
          
                  <input name="oldaddress" type="hidden" placeholder="name *"  id="oldaddress" />
                  
                  <input name="newship_name" type="hidden" placeholder="name *"  id="newship_name" />
                  <input name="newshippingaddress" type="hidden" placeholder="name *"  id="newshippingaddress" />
                  <input name="newship_city" type="hidden"  placeholder="City *"  id="newship_city"/>
                  <input name="newship_state" type="hidden"  placeholder="State/Province *"  id="newship_state"/>
                  <input name="newship_postal_code" type="hidden" placeholder="Postal Code *"  id="newship_postal_code"/>
                  <input name="newship_country" type="hidden" placeholder="name *"  id="newship_country" />
                     <input name="newdelivery_date" type="hidden" placeholder="name *"  id="newdelivery_date" />
                  <input name="newship_phone" type="hidden" placeholder="Telephone *" id="newship_phone"/>
                  <button type="submit" name="confirm" value="" style="border:none; background:none"> <img src="images/Cash-on-Delivery-Icon1.png" class="img-responsive" ></button>
                </form>
              </div>
              <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6" style="text-align:center; border-left:1px solid #ddd;"> 
			  
			         <form action="ebs/secure.php" method="post" id="cash">
                 
                  <input name="oldaddress1" type="hidden" placeholder="name *"  id="oldaddress1" />
                     
                     
                     
                   <input name="newship_name1" type="hidden" placeholder="name *"  id="newship_name1" />
                  <input name="newshippingaddress1" type="hidden" placeholder="name *"  id="newshippingaddress1" />
                  <input name="newship_city1" type="hidden"  placeholder="City *"  id="newship_city1"/>
                  <input name="newship_state1" type="hidden"  placeholder="State/Province *"  id="newship_state1"/>
                  <input name="newship_postal_code1" type="hidden" placeholder="Postal Code *"  id="newship_postal_code1"/>
                  <input name="newship_country1" type="hidden" placeholder="name *"  id="newship_country1" />
                     <input name="newdelivery_date1" type="hidden" placeholder="name *"  id="newdelivery_date1" />
                  <input name="newship_phone1" type="hidden" placeholder="Telephone *" id="newship_phone1"/>
                  <button type="submit" name="confirm" value="" style="border:none; background:none"> <img src="images/onlinepayment.jpg" class="img-responsive" ></button>
                </form>
                <!--<p>For EBS Online payment Click on EBS Payment </p>--> 
              </div>
            </div>
            </div>
          <br />
          <br />
        </div>
    <!-- Map Column -->
    
  </div>
    
</div>
    
	    <?php include("includes/footer.php"); ?>


	
    
</body>
</html>
<script src="js/wow.js"></script>
<script>
new WOW().init();
</script>