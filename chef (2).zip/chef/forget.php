<?php

	session_start();
	ob_start();

	error_reporting(0);

	include('includes/products-management.php');

	$dbFactory= new ProductsManagement();



if(isset($_POST[forget]))



{

	  $name=$_POST['EMAIL'];



$check=$dbFactory->registeruser_forget($_POST['EMAIL']);



   if(count($check)==1)



   {



//echo "prasad";



$x=$check[0]['USER_ID'];



   $link="http://mytestwebsite.in/chef/reset.php?id=$x";



       $from="friendsfocus.com";



   $msg = wordwrap($link,70);


// send email



mail("$name","$name",$link,"From:$from");



header("location:forget.php?mes=2");

   }



   else


   {



	   header("location:forget.php?mes=1");



	   }



}



?>
<!DOCTYPE  html>
<html lang="en">

<head>
  <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>DeleciousAndhra</title>


    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="css/animate.css" type="text/css">
	<link rel="stylesheet" href="font-awesome-4.2.0/css/font-awesome.min.css" type="text/css">
    
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script> 
    <script src="js/bootstrap.min.js"></script> 
    <script src="js/scripts.js"></script>
    <!-- Just include this Js file -->
	<script src="./js/jquery.carousel.fullscreen.js"></script>
    <style>
#map-canvas {
	width: 100%;
	height: 320px;
}
</style>
</head>


<body>
<?php if($_REQUEST[mes]==1){ ?>
 <div class="alert alert-success" style="margin:10px">
        <a href="#" class="close" data-dismiss="alert">&times;</a>
        <strong>Invalid Email .</strong>
    </div>
<?php }?>
<?php if($_REQUEST[mes]==2){ ?>
 <div class="alert alert-success" style="margin:10px">
        <a href="#" class="close" data-dismiss="alert">&times;</a>
        <strong>Check your Email For Password .</strong>
    </div>
<?php }?>
	<?php /*?><div class="mani_slide">
    <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
		<!-- Indicators -->
		<ol class="carousel-indicators">
			<li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
			<li data-target="#carousel-example-generic" data-slide-to="1"></li>
			<li data-target="#carousel-example-generic" data-slide-to="2"></li>
		</ol>

		<!-- Wrapper for slides -->
		<div class="carousel-inner">
         <?php $s=$dbFactory->banner_image();
 // echo count($s);
	for($i=0;$i<count($s);$i++)
	{?>
			<div class="item <?php  if($i==0){?>active <?php }?>">
				<img src="admin/banner_images/<?php echo $s[$i][BANNER_IMG_ID];?>.png" alt="" />
				<div class="container">
					<div class="carousel-caption wow pulse">
						<h1 class="brand_name " style="visibility: visible;">
						<a href="./">DeleciousAndhra</a>
						</h1>
						<p class="brand_slogan">premium cuisine </p>
					</div>
				</div>
			</div>
<?php }?>
			
		</div>

		<!-- Controls -->
		<a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
			<span class="glyphicon glyphicon-chevron-left"></span>
		</a>
		<a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
			<span class="glyphicon glyphicon-chevron-right"></span>
		</a>
	</div>
    </div><?php */?>
	
	<?php include("includes/menu.php"); ?>
    
    <div class="container">
      <h3 class="page-header">Forget Password</h3>
      <!-- Content Row -->
      <div class="row"> 
    <!-- Contact Details Column -->
    <div class="col-md-4"> 
          
          <!-- Contact Form -->


         <form class="form1" id=""  method="post">
        <div class="control-group form-group">
              <div class="controls">
           
<input type="email" name="EMAIL" class="form-control" placeholder="Enter Email" id="" required>            <p class="help-block"></p>
          </div>
            </div>
       
             
        <div id="success"></div>
        <!-- For success/fail messages -->
        <input name="forget" type="submit" class="btn btn-success pull-right" value="Submit">
      </form>
          <br />
          <br />
        </div>
    <!-- Map Column -->
    
  </div>
    
</div>
    
	    <?php include("includes/footer.php"); ?>


	
    
</body>
</html>
<script src="js/wow.js"></script>
<script>
new WOW().init();
</script>