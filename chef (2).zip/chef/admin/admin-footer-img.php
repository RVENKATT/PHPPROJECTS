<?php

session_start();

ob_start();

error_reporting();

if($_SESSION[ADMIN_ID]=='')

{



	

	header("location:index.php");

}





include('includes/admin-menu-db.php');

$dbFactory= new menu_db();

if(isset($_REQUEST[add]))

{

	

	

$f=$dbFactory->footer_add($_REQUEST[FOOTER_IMG_NAME]);
$temp=$f;
if($_FILES["files"]["name"]!='')
{
	for($j=0; $j<count($_FILES["files"]); $j++)
	{
	echo "footer/".$_FILES["files"]["name"][$j];
move_uploaded_file($_FILES["files"]["tmp_name"][$j],"footer/".$temp.".jpg");
}
}
header("location:admin-footer-img.php");

}

if(isset($_REQUEST[update]))

{

	

	

 $f=$dbFactory->footer1_update($_REQUEST[FOOTER_IMG_NAME],$_REQUEST[FOOTER_IMG_ID]);
 $temp=$f;
if($_FILES["files"]["name"]!='')
{
	for($j=0; $j<count($_FILES["files"]); $j++)
	{
	echo "footer/".$_FILES["files"]["name"][$j];
move_uploaded_file($_FILES["files"]["tmp_name"][$j],"footer/".$temp .$temp.".jpg");
}
}
	header("location:admin-footer-img.php");

}



?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="utf-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Dashboard - Dark Admin</title>

<link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.min.css" />

<link rel="stylesheet" type="text/css" href="css/bootstrap.css" />

<link rel="stylesheet" type="text/css" href="css/style.css" />

<link href="http://cdn.datatables.net/plug-ins/725b2a2115b/integration/bootstrap/3/dataTables.bootstrap.css" rel="stylesheet">

<script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>

<script type="text/javascript" src="js/bootstrap.js"></script>

<script src="js/scripts.js"></script>

<script src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js"></script>

<script src="http://cdn.datatables.net/plug-ins/725b2a2115b/integration/bootstrap/3/dataTables.bootstrap.js"></script>

<script type="text/javascript">

	function  pop_function(MENU_ID)

	{

	//menu loading

$.post("ajax/admin-edit.php?FOOTER_IMG_ID="+MENU_ID,function(data){



document.getElementById('myModal1').innerHTML=data;



});

	}

	</script>

<script type="text/javascript">

function delid(id)

{

	

i=confirm("Are you sure to delete the menu");

if(i)

{

$.post("ajax/admin-delete.php?FOOTER_IMG_ID="+id,function(data){



document.getElementById('cat_tab_id').innerHTML=data;



});

}

}



</script>

	<script src="http://tinymce.cachefly.net/4.1/tinymce.min.js"></script>

<script>

tinymce.init({

plugins: [

"code"

],

toolbar: "code",

selector:'textarea'

});</script>

<script src="jquery.js"></script>

<script src="jquery.validate.js"></script>

<script>

	



	$().ready(function() {

		// validate the comment form when it is submitted

		



		// validate signup form on keyup and submit

		$("#commentForm").validate({

			rules: {

				MENU_TITLE: "required",

				

				MENU_PARENT: "required",

				MENU_ORDER: "required"

	

		

		

				

			},

			messages: {

				MENU_TITLE: "Please enter your category title",

					MENU_PARENT: "Please select  parent ",

			

			

				MENU_ORDER: "Please enter your category order"

		

			

			}

		});



			});

	</script>

<style>

form.addform label.error, label.error {

	/* remove the next line when you have trouble in IE6 with labels in list */

	color: red;

	font-style: italic

}

</style>

</head>

<body>

<div id="wrapper">



    <?php include('includes/admin-header.php')?>

  <div id="page-wrapper">

  

    <legend>Footer <span class="pull-right">

    <button class="btn btn-primary" data-toggle="modal" data-target="#myModal">Add</button>

    </span></legend>

    <hr style="color: #303">

    

    <!-- Modal -->

    <div class="modal fade bs-example-modal-lg" id="myModal" tabmenu="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">

      <div class="modal-dialog">

        <div class="modal-content">

          <div class="modal-header">

            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>

            <h4 class="modal-title" id="myModalLabel">ADD</h4>

          </div>

          <div class="modal-body">

            <form enctype="multipart/form-data"  class="addform" id="commentForm" method="post">

              <div class="container-fluid">

                <div class="row">

                  <div  class="col-sm-4 pad">



                    FOOTER NAME: </div>

                  <div class="col-sm-8 pad">

                    <input  type="text" name="FOOTER_IMG_NAME"   />

                  </div>

                  
                                    <div  class="col-sm-4 pad">Upload Image:</div>
                  <div class="col-sm-8 pad">
 <input type="file" id="file" name="files[]" multiple="multiple"  accept="image/*" />
</div>
                  <div  class="col-sm-12 pad">

                    <input type="submit" class="btn btn-primary pull-right" name="add" value="ADD" />

                  </div>

                </div>

              
              </div>

            </form>

          </div>

        </div>

      </div>

    </div>

    <div class="clearfix"></div>

    <div class="table-responsive">

      <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">

        <thead>

          <tr>

            <th>SNO</th>

            <th>TITLLE</th>

              

              

   <th></th>

            

        

            <th></th>

          </tr>

        </thead>

        <tbody id="cat_tab_id">

          <?php

$s=$dbFactory->footers();

for($i=0; $i<count($s); $i++){

//if($d[$i][person]=='')continue;

?>

          <tr height="50px">

            <td><?php echo $i+1 ?></td>

            <td><?php echo $s[$i][FOOTER_IMG_NAME];?></td>

            
              
 <td><img src="footer/<?php echo $s[$i][FOOTER_IMG_ID];?>.jpg" width="50px" height="50px"></td>
          

            <td><span class="btn btn-primary btn-xs" data-toggle="modal" data-target="#myModal1" onClick="pop_function(<?php echo $s[$i][FOOTER_IMG_ID];?>)">EDIT</span></td>

            <td><span onClick="delid(<?php echo $s[$i][FOOTER_IMG_ID]; ?>)">DELETE</span></td>

          </tr>

          <?php }?>

        </tbody>

      </table>

    </div>

  </div>

</div>

<div class="modal fade bs-example-modal-lg" id="myModal1" tabmenu="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true"> </div>

<!-- /#wrapper -->



</body>

</html>

