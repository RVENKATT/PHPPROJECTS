<?php

session_start();

ob_start();



error_reporting(0);

if($_SESSION[ADMIN_ID]=='')

{



	

	header("location:index.php");

}

include('includes/admin-menu-db.php');

$dbFactory= new menu_db();

if(isset($_REQUEST['add']))

{

	

	

	

	if(isset($_FILES['file']))

	{



    $errors= array();

	

	$banner_img=$dbFactory->admin_banner_img_add($_REQUEST[BANNER_ORDER]);

  

		

        $desired_dir="banner_images";

       

            if(is_dir($desired_dir)==false){

                mkdir("$desired_dir", 0700);		// Create directory if it does not exist

            }

         // echo"banner_images/".$banner_img.".jpg";

                move_uploaded_file($_FILES["file"]["tmp_name"],"banner_images/".$banner_img.".png");

						





}



//header("location:admin_banner.php?id=$_REQUEST[CATEGORY_ID]&mes=1");

}

if(isset($_REQUEST['update']))

{

$title=mysql_escape_string($_REQUEST[BANNER_ORDER]);

	$banner_img=$dbFactory->banner_update($_REQUEST[BANNER_ORDER],$_REQUEST[BANNER_IMG_ID]);
	
	  $temp=$_REQUEST[BANNER_IMG_ID];
 if($_FILES["file"]["name"]!='')
{
//echo "upload/" . $temp.".jpg";
move_uploaded_file($_FILES["file"]["tmp_name"],"banner_images/".$temp.".png");
}


	header("location:admin-banner.php?mes=2");

}




if(isset($_REQUEST['did']))

{

   $s=$dbFactory->banner_delete($_REQUEST['did']);

   header("location:admin-banner.php?mes=3");

}





?>



<?php

function make_thumb($img_name,$filename,$new_w,$new_h)

{

$ext=getExtension($img_name);

if(!strcmp("jpg",$ext) || !strcmp("JPG",$ext) || !strcmp("jpeg",$ext) || !strcmp("JPEG",$ext))

$src_img=imagecreatefromjpeg($img_name);

if(!strcmp("gif",$ext) || !strcmp("GIF",$ext))

$src_img=imagecreatefromgif($img_name);

if(!strcmp("png",$ext) || !strcmp("PNG",$ext))

$src_img=imagecreatefrompng($img_name);

$old_x=imagesx($src_img);

$old_y=imagesy($src_img);

$ratio1=$old_x/$new_w;

$ratio2=$old_y/$new_h;

if($ratio1>$ratio2) {

$thumb_w=$new_w;

$thumb_h=$old_y/$ratio1;

}

else {

$thumb_h=$new_h;

$thumb_w=$old_x/$ratio2;

}

$dst_img=ImageCreateTrueColor($thumb_w,$thumb_h);

imagecopyresampled($dst_img,$src_img,0,0,0,0,$thumb_w,$thumb_h,$old_x,$old_y);

if(!strcmp("png",$ext))

imagepng($dst_img,$filename);

if(!strcmp("gif",$ext))

imagegif($dst_img,$filename);

else

imagejpeg($dst_img,$filename);

imagedestroy($dst_img);

imagedestroy($src_img);

}

function getExtension($str) {

$i = strrpos($str,".");

if (!$i) { return ""; }

$l = strlen($str) - $i;

$ext = substr($str,$i+1,$l);

return $ext;

}

 ?>



<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="utf-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Dashboard - Dark Admin</title>



    <link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.min.css" />

    <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />

    <link rel="stylesheet" type="text/css" href="css/style.css" />

		<link href="http://cdn.datatables.net/plug-ins/725b2a2115b/integration/bootstrap/3/dataTables.bootstrap.css" rel="stylesheet">



<script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>

    <script type="text/javascript" src="js/bootstrap.js"></script>

	<script src="js/scripts.js"></script>



	<script src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js"></script>

<script src="http://cdn.datatables.net/plug-ins/725b2a2115b/integration/bootstrap/3/dataTables.bootstrap.js"></script>

    <script type="text/javascript">

	function  pop_function(BANNER_IMG_ID)

	{

	//menu loading

$.post("ajax/admin-edit.php?BANNER_IMG_ID="+BANNER_IMG_ID,function(data){



document.getElementById('myModal1').innerHTML=data;



});

	}

	</script>
    

     <script type="text/javascript">
function delid(BANNER_IMG_ID)

{

i=confirm("Are you sure to delete the item");

if(i)

window.location="admin-banner.php?did="+BANNER_IMG_ID;

}



</script>







<script src="jquery.js"></script>

	<script src="jquery.validate.js"></script>

	<script>

	



	$().ready(function() {

		// validate the comment form when it is submitted

		



		// validate signup form on keyup and submit

		$("#commentForm").validate({

			rules: {

				CATEGORY_TITLE: "required",

				

				PARENT_ID: "required",

				CATEGORY_ORDER: "required"

	

		

		

				

			},

			messages: {

				CATEGORY_TITLE: "Please enter your category title",

					PARENT_ID: "Please select  parent ",

			

			

				CATEGORY_ORDER: "Please enter your category order"

		

			

			}

		});



			});

	</script>

    	<style>



	form.addform label.error, label.error {

	/* remove the next line when you have trouble in IE6 with labels in list */

	color: red;

	font-style: italic

}



	</style>

    



 

</head>

<body>















    <div id="wrapper">



            <?php include('includes/admin-header.php')?>



        <div id="page-wrapper">

		<div style="display:none;<?php if($_GET[mes]==1){?>display:block<?php }?>">

             <div class="alert alert-dismissable alert-success">

               <button type="button" class="close" data-dismiss="alert">&#x2715;</button>

               <strong>banner Added Successfully .</strong>

             </div>

           </div>

           	<div style="display:none;<?php if($_GET[mes]==2){?>display:block<?php }?>">

             <div class="alert alert-dismissable alert-success">

               <button type="button" class="close" data-dismiss="alert">&#x2715;</button>

               <strong> banner Updated Successfully.</strong>

             </div>

           </div>

        

		<legend>Banner

		<span class="pull-right"><button class="btn btn-primary" data-toggle="modal" data-target="#myModal">Add</button></span></legend>

        

        

        <hr style="color: #303">



<!-- Modal -->

<div class="modal fade bs-example-modal-lg" id="myModal" tabadmin_banner="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">

  <div class="modal-dialog">

    <div class="modal-content">

      <div class="modal-header">

        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>

        <h4 class="modal-title" id="myModalLabel">Edit</h4>

      </div>

      <div class="modal-body">

  <form   class="addform" id="commentForm" enctype="multipart/form-data" method="post" > 

  <div class="container-fluid">

  <div class="row">

   <div  class="col-sm-5 pad"> BANNER ORDER:</div><div class="col-sm-7 pad"> <input  type="text" name="BANNER_ORDER" /></div>

  





     <div  class="col-sm-4 pad">UPLOAD IMAGES:</div><div class="col-sm-8 pad"> <input type="file" name="file"  id="file" /> </div>

      

       	

    

       <div  class="col-sm-12 pad">  <input type="submit" class="btn btn-primary pull-right" name="add" value="ADD" /></div></div></div></form>

      </div>

    

      

     

    </div>

  </div>

  </div>



		

		<div class="clearfix"></div>

		<div class="table-responsive">

		<table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">

        <thead>

            <tr>

			 <th>SNO</th>
             <th>Order</th>
              <th>Banner</th>

         <th></th>

                

               <th></th>

            </tr>

        </thead>

 

        

 

        <tbody id="cat_tab_id">

		

	<?php

$s=$dbFactory->admin_banner($_GET[id]);

for($i=0; $i<count($s); $i++){

//if($d[$i][person]=='')continue;

?>	

  <tr height="50px">

    <td><?php echo $i+1 ?></td>
    <td><?php echo $s[$i][BANNER_ORDER] ?></td>
	 

  <td><img src="banner_images/<?php echo $s[$i][BANNER_IMG_ID];?>.png" width="50px" height="50px"></td>

    <td><span class="btn btn-primary btn-xs" data-toggle="modal" data-target="#myModal1" onClick="pop_function(<?php echo $s[$i][BANNER_IMG_ID];?>)">EDIT</span></td>

    <td><span onClick="delid(<?php echo $s[$i][BANNER_IMG_ID]; ?>)">DELETE</span></td>

   



  </tr>

<?php }?>

		

		

           

		</tbody>

    </table>

      

      </div>

		

		</div>

		</div>



    

    

    <div class="modal fade bs-example-modal-lg" id="myModal1" tabadmin_banner="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">

  

</div>

    <!-- /#wrapper -->

    

</body>

</html>

