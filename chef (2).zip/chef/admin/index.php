<?php



session_start();



ob_start();



//error_reporting(0);



include('includes/admin-users-management.php');



$dbFactory= new UsersManagement();



if(isset($_POST[login]))



{



$check=$dbFactory->registeruser_check($_POST['admin'],$_POST['password']);



if(count($check)==1)



{



$_SESSION[ADMIN_ID]=$check[0]['ADMIN_ID'];



$_SESSION[PRODUCT_STATUS]=1;







$_SESSION[password]=$check[0]['PASSWORD'];



header("location:admin-banner.php");


}



else



{



header("location:index.php?mes=1");


}



}



?>

<!DOCTYPE html>

<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard - Dark Admin</title>
<link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.min.css" />
<link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
<link rel="stylesheet" type="text/css" href="css/style.css" />
<link href="http://cdn.datatables.net/plug-ins/725b2a2115b/integration/bootstrap/3/dataTables.bootstrap.css" rel="stylesheet">
<script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
<script type="text/javascript" src="js/bootstrap.js"></script>
<script src="js/scripts.js"></script>
<script src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js"></script>
<script src="http://cdn.datatables.net/plug-ins/725b2a2115b/integration/bootstrap/3/dataTables.bootstrap.js"></script>
<script type="text/javascript">



	function  pop_function(CATEGORY)



	{

	//menu loading



$.post("ajax/popup.php?prasad="+CATEGORY,function(data){


document.getElementById('myModal1').innerHTML=data;


});



	}



	</script>
<script type="text/javascript">



function delid(id)



{

i=confirm("Are you sure to delete the user");



if(i)



window.location="index.php?did="+id;



}


</script>
<script src="jquery.js"></script>
<script src="jquery.validate.js"></script>
<script>


	$().ready(function() {




		$("#commentForm").validate({



			rules: {



				admin: {



					required: true,


					



				},



				password: {



					required: true,



					



				},



			},



			messages: {







					admin: {



					required: "please enter adminusername",



					



					



				},



			



			



				password: {



					required: "Please provide a password",



				



				},







				



			



			}



		});







		// propose username by combining first- and lastname



		$("#username").focus(function() {



			var firstname = $("#firstname").val();



			var lastname = $("#lastname").val();



			if (firstname && lastname && !this.value) {



				this.value = firstname + "." + lastname;



			}



		});







		//code to hide topic selection, disable for demo



		var newsletter = $("#newsletter");



		// newsletter topics are optional, hide at first



		var inital = newsletter.is(":checked");



		var topics = $("#newsletter_topics")[inital ? "removeClass" : "addClass"]("gray");



		var topicInputs = topics.find("input").attr("disabled", !inital);



		// show when newsletter is checked



		newsletter.click(function() {



			topics[this.checked ? "removeClass" : "addClass"]("gray");



			topicInputs.attr("disabled", !this.checked);



		});



	});



	</script>
<style type="text/css">
.gap {
	margin-top:1em;
}
</style>
</head>

<body  style="background:green;">
<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
  <div class="navbar-header">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
    <a class="navbar-brand" href="index.php"></a> </div>
  <div class="collapse navbar-collapse navbar-ex1-collapse"> </div>
</nav>
<div  class="container">
  <div class="row" style=" margin-top:50px">
    <div   class="col-md-4 col-md-offset-4" style="background:white">
      <legend class="topgap">ADMIN</legend>
      
      <!-- Modal -->
      
      <form class="cmxform" id="commentForm"  method="post">
        <div class="container-fluid">
          <div class="row">
            <?php if($_GET[mes]==1) {?>
            <p style="color:#F00; font-size:18px"> Invalid Credentials</p>
            <?php } ?>
            <div  class="col-sm-3 pad"> Username:</div>
            <div  class="col-sm-9 pad">
              <input  type="text" class="form-control"  name="admin" />
            </div>
            <div  class="col-sm-3 pad"> Passoword:</div>
            <div class="col-sm-9 pad">
              <input  type="password" class="form-control"  name="password" />
            </div>
            <div  class="col-sm-6 pad">
              <input type="submit" class="btn btn-primary " name="login" value="login" />
            </div>
            <div  class="col-sm-6 pad" style="padding-top:16px"> <a href="admin-forget.php">Forget Password</a></div>
          </div>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- /#wrapper -->

</body>
</html>
