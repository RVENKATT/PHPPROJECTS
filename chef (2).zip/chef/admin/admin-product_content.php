<?php

session_start();

ob_start();

include('includes/admin-menu-db.php');

$dbFactory= new menu_db();

error_reporting(0);



if($_SESSION[ADMIN_ID]=='')

{

	header("location:index.php");

}





if(isset($_REQUEST[add]))

{
	
	$product_des=mysql_escape_string($_REQUEST[PRODUCT_DES]);
    	

	$d=$dbFactory->product_add($_REQUEST[PRODUCT_TITLE],$product_des);
	

	if($_FILES['files']['name'][0]!='')

{

$errors= array();

foreach($_FILES['files']['tmp_name'] as $key => $tmp_name )

{

$file_name = $_FILES['files']['name'][$key];

$file_size =$_FILES['files']['size'][$key];

$file_tmp =$_FILES['files']['tmp_name'][$key];

$file_type=$_FILES['files']['type'][$key];


	

if($_FILES['files']['type'][$key]=="image/png")

$x="png";

if($_FILES['files']['type'][$key]=="image/jpeg")

$x="jpeg";

if($_FILES['files']['type'][$key]=="image/jpg")

$x="jpg";

if($_FILES['files']['type'][$key]=="image/gif")

$x="gif";



    	

  

$img_name=$d.".$x";

  $desired_dir="product";

        if(is_dir($desired_dir)==false){



                mkdir("$desired_dir", 0700);		// Create directory if it does not exist



            }

            move_uploaded_file($file_tmp,"product/".$img_name);



			

      }



	}





header("location:admin-product_content.php?mes=1");

}

if(isset($_REQUEST[update]))

{

 

    	$product_des=mysql_escape_string($_REQUEST[PRODUCT_DES]);
		

    	

	$s=$dbFactory->product_update($_REQUEST[PRODUCT_TITLE],$product_des,$_REQUEST[PRODUCT_ID]);

   $temp=$_REQUEST[PRODUCT_ID];



	if($_FILES['files']['name'][0]!='')

{

$errors= array();

foreach($_FILES['files']['tmp_name'] as $key => $tmp_name )

{

$file_name = $_FILES['files']['name'][$key];

$file_size =$_FILES['files']['size'][$key];

$file_tmp =$_FILES['files']['tmp_name'][$key];

$file_type=$_FILES['files']['type'][$key];


	

if($_FILES['files']['type'][$key]=="image/png")

$x="png";

if($_FILES['files']['type'][$key]=="image/jpeg")

$x="jpeg";

if($_FILES['files']['type'][$key]=="image/jpg")

$x="jpg";

if($_FILES['files']['type'][$key]=="image/gif")

$x="gif";



    	

  

$img_names=$temp.".$x";

  $desired_dir="product";

        if(is_dir($desired_dir)==false){



                mkdir("$desired_dir", 0700);		// Create directory if it does not exist



            }

            move_uploaded_file($file_tmp,"product/".$img_names);



			

      }
	
       

            


}
header("location:admin-product_content.php?mes=2");

}

?>



<?php

function make_thumb($img_name,$filename,$new_w,$new_h)

{

$ext=getExtension($img_name);

if(!strcmp("jpg",$ext) || !strcmp("JPG",$ext) || !strcmp("jpeg",$ext) || !strcmp("JPEG",$ext))

$src_img=imagecreatefromjpeg($img_name);

if(!strcmp("gif",$ext) || !strcmp("GIF",$ext))

$src_img=imagecreatefromgif($img_name);

if(!strcmp("png",$ext) || !strcmp("PNG",$ext))

$src_img=imagecreatefrompng($img_name);

$old_x=imagesx($src_img);

$old_y=imagesy($src_img);

$ratio1=$old_x/$new_w;

$ratio2=$old_y/$new_h;

if($ratio1>$ratio2) {

$thumb_w=$new_w;

$thumb_h=$old_y/$ratio1;

}

else {

$thumb_h=$new_h;

$thumb_w=$old_x/$ratio2;

}

$dst_img=ImageCreateTrueColor($thumb_w,$thumb_h);

imagecopyresampled($dst_img,$src_img,0,0,0,0,$thumb_w,$thumb_h,$old_x,$old_y);

if(!strcmp("png",$ext))

imagepng($dst_img,$filename);

if(!strcmp("gif",$ext))

imagegif($dst_img,$filename);

else

imagejpeg($dst_img,$filename);

imagedestroy($dst_img);

imagedestroy($src_img);

}

function getExtension($str) {

$i = strrpos($str,".");

if (!$i) { return ""; }

$l = strlen($str) - $i;

$ext = substr($str,$i+1,$l);

return $ext;

}



?>



<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="utf-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Dashboard - Dark Admin</title>



    <link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.min.css" />

    <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />

    <link rel="stylesheet" type="text/css" href="css/style.css" />

		<link href="http://cdn.datatables.net/plug-ins/725b2a2115b/integration/bootstrap/3/dataTables.bootstrap.css" rel="stylesheet">



<script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>

    <script type="text/javascript" src="js/bootstrap.js"></script>

	<script src="js/scripts.js"></script>



	<script src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js"></script>

<script src="http://cdn.datatables.net/plug-ins/725b2a2115b/integration/bootstrap/3/dataTables.bootstrap.js"></script>

    <script type="text/javascript">

	function  pop_function(PRODUCT_ID)

	{

	//menu loading

$.post("ajax/admin-edit.php?PRODUCT_ID="+PRODUCT_ID,function(data){



document.getElementById('myModal1').innerHTML=data;

tinymce.init({

plugins: [

"code"
		

],

toolbar: "code",

selector:'textarea'

});

});

	}

	</script>
<script type="text/javascript">

function  product_img(product_id,img_id)

	{

	i=confirm("Are you sure to edit the Image");

if(i)

	{//menu loadin]

	//alert(img_id);

$.post("ajax/admin-edit.php?PRODUCT_ID="+product_id+"&IMG_ID="+img_id,function(data){

//alert(data);



document.getElementById('product_img_delete').innerHTML=data;



});

	}}

	

	

	</script>
     <script type="text/javascript">

function delid(banner_img_id)

{

	

i=confirm("Are you sure to delete the image");

if(i)

	{

$.post("ajax/admin-delete.php?PRODUCT_ID="+banner_img_id,function(data){



document.getElementById('cat_tab_id').innerHTML=data;



});

	}

}



</script>


<script src="http://tinymce.cachefly.net/4.1/tinymce.min.js"></script>



<script>



tinymce.init({



plugins: [



"code"



],



toolbar: "code",



selector:'textarea'



});</script>



<script src="jquery.js"></script>

	<script src="jquery.validate.js"></script>

	<script>

	



	$().ready(function() {

		// validate the comment form when it is submitted

		



		// validate signup form on keyup and submit

		$("#commentForm").validate({

			rules: {

				CATEGORY_TITLE: "required",

				

				PARENT_ID: "required",

				CATEGORY_ORDER: "required"

	

		

		

				

			},

			messages: {

				CATEGORY_TITLE: "Please enter your category title",

					PARENT_ID: "Please select  parent ",

			

			

				CATEGORY_ORDER: "Please enter your category order"

		

			

			}

		});



			});

	</script>

    	<style>



	form.addform label.error, label.error {

	/* remove the next line when you have trouble in IE6 with labels in list */

	color: red;

	font-style: italic

}



	</style>

    



 

</head>

<body>















    <div id="wrapper">



            <?php include('includes/admin-header.php')?>



        <div id="page-wrapper">

		<div style="display:none;<?php if($_GET[mes]==1){?>display:block<?php }?>">

             <div class="alert alert-dismissable alert-success">

               <button type="button" class="close" data-dismiss="alert">&#x2715;</button>

               <strong>IMAGE Added Successfully .</strong>

             </div>

           </div>

           	<div style="display:none;<?php if($_GET[mes]==2){?>display:block<?php }?>">

             <div class="alert alert-dismissable alert-success">

               <button type="button" class="close" data-dismiss="alert">&#x2715;</button>

               <strong> banner Updated Successfully.</strong>

             </div>

           </div>

        

		<legend>Product

		<span class="pull-right"><button class="btn btn-primary" data-toggle="modal" data-target="#myModal">Add</button></span></legend>

        

        

        <hr style="color: #303">



<!-- Modal -->

<div class="modal fade bs-example-modal-lg" id="myModal" tabmenu="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">



      <div class="modal-dialog">



        <div class="modal-content">



          <div class="modal-header">



            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>



            <h4 class="modal-title" id="myModalLabel">ADD</h4>



          </div>



          <div class="modal-body">

   <form enctype="multipart/form-data"  class="addform" id="commentForm" method="post">



              <div class="container-fluid">



                <div class="row">



   <div  class="col-sm-5 pad"> PRODUCT TITLE:</div><div class="col-sm-7 pad"> <input  type="text" name="PRODUCT_TITLE" /></div>



      <div  class="col-sm-5 pad">DESCRIPTION:</div>



                  <div class="col-sm-7 pad">



              <textarea  name="PRODUCT_DES" ></textarea>



                                       </div>



<div  class="col-sm-4 pad">Upload Image:</div>

                  <div class="col-sm-8 pad">

<input type="file" name="files[]"  id="file" multiple/>

</div>

                  

       	

    

       <div  class="col-sm-12 pad">  <input type="submit" class="btn btn-primary pull-right" name="add" value="ADD" /></div></div></div></form>

      </div>

    

      

     

    </div>

  </div>

  </div>



		

		<div class="clearfix"></div>

		<div class="table-responsive">

		<table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">

        <thead>

            <tr>

			 <th>SNO</th>

                 <th>PRODUCT TITLE</th>

                 <th>DESCRIPTION</th>

                  <th>IMAGE</th>
                  <th>ADD ITEM</th>                    

               <th></th>

            </tr>

        </thead>

 

        

 

        <tbody id="cat_tab_id">

		

	<?php

$s=$dbFactory->products1();

for($i=0; $i<count($s); $i++){

//if($d[$i][person]=='')continue;

?>	

  <tr height="50px">

    <td><?php echo $i+1 ?></td>

    

<td><?php echo $s[$i][PRODUCT_TITLE];?></td>

 <td><?php echo $s[$i][PRODUCT_DES];?></td>

  <td><img src="product/<?php echo $s[$i][PRODUCT_ID];?>.png" width="30" height="30"></td>
  <td><a href="admin-internal.php?id=<?php echo $s[$i][PRODUCT_ID];?>"><img src="images/edit1.png" /></span></a></td>

     <td><span class="btn btn-primary btn-xs" data-toggle="modal" data-target="#myModal1" onClick="pop_function(<?php echo $s[$i][PRODUCT_ID];?>)">EDIT</span></td>



    <td><span onClick="delid(<?php echo $s[$i][PRODUCT_ID]; ?>)">DELETE</span></td>

   



  </tr>

<?php }?>

		

		

           

		</tbody>

    </table>

      

      </div>

		

		</div>

		</div>



    

    

    <div class="modal fade bs-example-modal-lg" id="myModal1" tabadmin_banner="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">

  

</div>

    <!-- /#wrapper -->

    

</body>

</html>

