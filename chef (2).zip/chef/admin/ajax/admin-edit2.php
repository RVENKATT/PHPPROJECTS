<?php
session_start();
ob_start();
error_reporting(0);
?>
<?php //PRODUCT EDIT START?>
<?php 
if($_REQUEST[PRODUCT_ID]!="")
{
include('../includes/admin-products-management.php');
$dbFactory= new ProductsManagement();
?>

 <div class="modal-dialog" >
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel">Edit</h4>
      </div>
      <div class="modal-body">
  <form   class="editform" id="kiran" method="post" enctype="multipart/form-data"> 
  <div class="container-fluid">
  <div class="row">
  	<?php
$product_info=$dbFactory->products_detail($_REQUEST[PRODUCT_ID]);?>
   <div  class="col-sm-4 pad"> PRODUCT TITLE:</div><div class="col-sm-8 pad"> <input  type="text" name="PRODUCT_TITLE" value="<?php echo $product_info[0][PRODUCT_TITLE];?>" /></div>
     <div  class="col-sm-4 pad"> DESCRIPTION:</div><div class="col-sm-8 pad"><textarea  name="PRODUCT_DES" ><?php echo $product_info[0][PRODUCT_DES];?></textarea></div>
     
     <div  class="col-sm-4 pad"> COST:</div><div class="col-sm-8 pad"> <input  type="text" name="PRODUCT_COST" value="<?php echo $product_info[0][PRODUCT_COST];?>"/>
     <select name="CATEGORY_ID">
<?php $s1=$dbFactory->categories();
for($ii=0; $ii<count($s1); $ii++){
?>
	 <option <?php if($_REQUEST[CATEGORY_IDD]==$s1[$ii][CATEGORY_ID]){;?> selected="selected"<?php }?> value="<?php echo $s1[$ii][CATEGORY_ID]; ?>"><?php echo $s1[$ii][CATEGORY_TITLE]; ?></option>
<?php }?>
	 </select>
	 </div>
        <div  class="col-sm-4 pad"> OLD COST:</div>
        <div class="col-sm-8 pad"> <input  type="text" name="PRODUCT_OLD_COST" value="<?php echo $product_info[0][PRODUCT_OLD_COST];?>"/>
  </div>
  
	<?php
$s=$dbFactory->product_categories_fields_detail($_REQUEST[CATEGORY_IDD]);
for($i=0; $i<count($s); $i++){
//if($d[$i][person]=='')continue;
?>	
        <div  class="col-sm-4 pad"> <?php echo $s[$i][CATEGORY_FIELD_TITLE];?></div><div class="col-sm-8 pad">	<?php
$m=$dbFactory->product_categories_fields_vlaues_detail($s[$i][CATEGORY_FIELD_ID]);
for($j=0; $j<count($m); $j++){
?>
 <input  type="checkbox" name="PRODUCT_FIELD_VALUE[]" value="<?php echo $m[$j][CATEGORY_FIELD_VALUE_ID];?>"
<?php 
$product_field_check=$dbFactory->check_product_categories_fields_vlaue_id($m[$j][CATEGORY_FIELD_VALUE_ID],$_REQUEST[PRODUCT_ID]);
 if($product_field_check[0][0]==1){?> checked="checked"<?php }?>
 />

<?php echo $m[$j][CATEGORY_FIELD_VALUE];?>
<?php }?>
</div>


<?php }?>

<span  id="product_img_delete">

<div  class="col-sm-12 pad" ><?php $product_img_del=$dbFactory->product_img_delete($_REQUEST[PRODUCT_ID]);
for($i=0;$i<count($product_img_del);$i++){?> <img  src="product_images/temp/<?php echo $product_img_del[$i][IMG_NAME];?>"
 onClick="product_img(<?php echo $_REQUEST[PRODUCT_ID];?>,<?php echo $product_img_del[$i][IMG_ID];?>)" height="50" width="50"/>&nbsp;&nbsp;<?php }?>
</div>

</span>
         <div  class="col-sm-4 pad">UPLOAD IMAGES:</div><div class="col-sm-8 pad"> <input type="file" name="files[]"  id="file"multiple/> </div>
       <div  class="col-sm-12 pad"> <input type="hidden"  name="PRODUCT_ID" value="<?php echo $_REQUEST[PRODUCT_ID]; ?>" />  <input type="submit" class="btn btn-primary pull-right" name="update" value="UPDATE" /></div></div></div></form>
      </div>
    
      
     
    </div>
  </div>
<?php }?>

<?php //PRODUCT EDIT END?>

<?php // PRODUCT IMAGE DELETE START ?>


<?php 
if($_REQUEST[IMG_ID]!="")
{
	
include('../includes/admin-products-management.php');
$dbFactory= new ProductsManagement();;

$ss=$dbFactory->product_img_delete_detail($_REQUEST[IMG_ID]);
	//echo "../product_images/".$ss[0][IMG_NAME];
	  @unlink("../product_images/".$ss[0][IMG_NAME]);
	    @unlink("../product_images/temp/".$ss[0][IMG_NAME]);
$s=$dbFactory->product_img_delete_edit($_REQUEST[IMG_ID]);


?>

<div  class="col-sm-12 pad" ><?php $product_img_del=$dbFactory->product_img_delete($_REQUEST[PRODUCT_ID_IMG]);
for($i=0;$i<count($product_img_del);$i++){?> <img  src="product_images/temp/<?php echo $product_img_del[$i][IMG_NAME];?>" onClick="product_img(<?php echo $_REQUEST[PRODUCT_ID_IMG];?>,<?php echo $product_img_del[$i][IMG_ID];?>)" height="50" width="50"/>&nbsp;&nbsp;<?php }?>
</div>
	<?php }?>

<?php // PRODUCT IMAGE DELETE START ?>

<?php //USER EDIT START?>
<?php
if($_REQUEST[USER_ID]!="")
{
include('../includes/admin-users-management.php');
$dbFactory= new UsersManagement();
?>
 <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel">Edit</h4>
      </div>
      <div class="modal-body">
  <form   class="cmxform1" id="kiran" method="post"> 
  <div class="container-fluid">
  <div class="row">
   <div  class="col-sm-3 pad">
     <?php 
    $d=$dbFactory->user_detail($_REQUEST[USER_ID]);?>
    User Name: </div><div class="col-sm-9 pad"><input  type="text" name="USERNAME" value="<?php echo $d[0][USERNAME];?>"  /></div>
         <div  class="col-sm-3 pad"> Email:</div> <div  class="col-sm-9 pad"> <input  type="text" name="EMAIL" value="<?php echo $d[0][EMAIL];?>"  /> </div>
     
     <div  class="col-sm-3 pad"> Passoword:</div><div class="col-sm-9 pad"> <input  type="password" name="PASSWORD" value="<?php echo $d[0][PASSWORD];?>" /></div>
  

   
   
     
     <div  class="col-sm-3 pad">  Phone: </div><div  class="col-sm-9 pad"> <input  type="text" name="PHONE" value="<?php echo $d[0][PHONE];?>"  /> 
     <input  type="hidden" name="USER_ID" value="<?php echo $d[0][USER_ID];?>"  /></div>
       <div  class="col-sm-12 pad">  <input type="submit" class="btn btn-primary pull-right" name="update" value="Update" /></div></div></div></form>
      </div>
    
      
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>

      </div>
    </div>
  </div>

<?php }?>


<?php //USER EDIT END?>

<?php //CATEGORY EDIT START?>
<?php 
if($_REQUEST[CATEGORY_ID]!="")
{
include('../includes/admin-products-management.php');
$dbFactory= new ProductsManagement();
?>
 <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel">Edit</h4>
      </div>
      <div class="modal-body">
  <form   class="editform" id="kiran" method="post" enctype="multipart/form-data"> 
  <div class="container-fluid">
  <div class="row">
   <div  class="col-sm-4 pad">
     <?php 
    $d=$dbFactory->categories_detail($_REQUEST[CATEGORY_ID]);?>
    CATEGORY_TITLE: </div><div class="col-sm-8 pad"><input  type="text" name="CATEGORY_TITLE" value="<?php echo $d[0][CATEGORY_TITLE];?>"  /></div>
          
     
     <div  class="col-sm-4 pad"> CATEGORY_ORDER:</div><div class="col-sm-8 pad"> <input  type="text" name="CATEGORY_ORDER" value="<?php echo $d[0][CATEGORY_ORDER];?>" /></div>
  
 <div  class="col-sm-4 pad">UPLOAD IMAGES:</div><div class="col-sm-8 pad"> <input type="file" name="file"  id="file" /> </div>
   
     <input  type="hidden" name="PARENT_ID" value="<?php echo $d[0][PARENT_ID];?>"  />
     <input  type="hidden" name="CATEGORY_ID" value="<?php echo $d[0][CATEGORY_ID];?>"  />
       <div  class="col-sm-12 pad">  <input type="submit" class="btn btn-primary pull-right" name="update" value="Update" /></div></div></div></form>
      </div>
    
      
     
    </div>
  </div>
<?php }?>

<?php //CATEGORY EDIT END?>









<?php //FOOTER EDIT START?>
<?php 
if($_REQUEST[FOOTER_ID]!="")
{
include('../includes/admin-menu-db.php');
$dbFactory= new menu_db();
?>
 <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel">Edit</h4>
      </div>
      <div class="modal-body">
  <form   class="editform" id="kiran" method="post"> 
  <div class="container-fluid">
  <div class="row">
   <div  class="col-sm-4 pad">
     <?php 
    $d=$dbFactory->footer_details($_REQUEST[FOOTER_ID]);?>
    FOOTER CONTENT: </div><div class="col-sm-8 pad"><textarea name="FOOTER_CONTENT" id="editor" ><?php $x=htmlspecialchars_decode($d[0][FOOTER_CONTENT], ENT_QUOTES);
  echo $x;?></textarea></div>
          

  

   

     <input  type="hidden" name="FOOTER_ID" value="<?php echo $_REQUEST[FOOTER_ID];?>"  />
       <div  class="col-sm-12 pad">  <input type="submit" class="btn btn-primary pull-right" name="update" value="Update" /></div></div></div></form>
      </div>
    
      
     
    </div>
  </div>
<?php }?>

<?php //FOOTER EDIT END?>






<?php //TRANSACTION DETAILS VIEW START?>
<?php 
if($_REQUEST[TRANSACTION_ID]!="")
{
include('../includes/admin-products-management.php');
$dbFactory= new ProductsManagement();
?>
 <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel">Edit</h4>
      </div>
      <div class="modal-body">

  <div class="container-fluid">
  <div class="row">



<table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
        <thead>
            <tr>
			 <th>SNO</th>
                <th>PRODCUT_</th>
      
                <th>QUANTITY</th>
           
                <th>INFO </th>        

            </tr>
        </thead>
 
        
 
        <tbody id="cat_tab_id">
		
	<?php
$s=$dbFactory->transaction_details($_REQUEST[TRANSACTION_ID]);
for($i=0; $i<count($s); $i++){
//if($d[$i][person]=='')continue;
?>	
  <tr height="50px">
    <td><?php echo $i+1 ?></td>
    <td><?php echo $s[$i][PRODCUT_ID];?></td>
     <td><?php echo $s[$i][QUANTITY];?></td>
	    <td><?php echo $s[$i][INFO];?></td>
	
		

  
  

  </tr>
<?php }?>
		
		
           
		</tbody>
    </table>
</div></div>
      </div>
    
      
     
    </div>
  </div>
<?php }?>

<?php //TRANSACTION DETAILS VIEW END?>






<?php //MENU EDIT START?>
<?php 
if($_REQUEST[MENU_ID]!="")
{
include('../includes/admin-menu-db.php');
$dbFactory= new menu_db();


?>
 <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel">Edit</h4>
      </div>
      <div class="modal-body">
  <form   enctype="multipart/form-data" class="editform" id="kiran" method="post"> 
  <div class="container-fluid">
  <div class="row">
   <div  class="col-sm-4 pad">
     <?php 
    $d=$dbFactory->menu_detail($_REQUEST[MENU_ID]);
    ?>
    Title: </div><div class="col-sm-8 pad"><input  type="text" name="MENU_TITLE" value="<?php echo $d[0][MENU_TITLE];?>"  /></div>
          
     

  

              <div  class="col-sm-4 pad"> Parent: </div>
                  <div  class="col-sm-8 pad">
                    <select  name="MENU_PARENT" style="width:155px">
                      <option value="0">-Select-</option>
                      <?php
$s=$dbFactory->menu();

for($i=0; $i<count($s); $i++){
//if($d[$i][person]=='')continue;
?>
                      <option value="<?php echo $s[$i][MENU_ID]; ?>" <?php if($s[$i][MENU_ID]==$d[0][MENU_PARENT]) echo "selected"?>><?php echo $s[$i][MENU_TITLE]; ?></option>
                      <?php }?>
                    </select>
                  </div>
                <div  class="col-sm-4 pad"> Order:</div><div class="col-sm-8 pad"> <input  type="text" name="MENU_ORDER" value="<?php echo $d[0][MENU_ORDER];?>" /></div>
  
                  <div  class="col-sm-4 pad">Link:</div>
                  <div class="col-sm-8 pad">
              
                     <input  type="text" name="EXTERNAL_LINK" value="<?php echo $d[0][EXTERNAL_LINK];?>" />
                  </div>
                  <div  class="col-sm-4 pad">Description:</div>
                  <div class="col-sm-8 pad">
                         <textarea  name="MENU_DES" ><?php echo stripslashes($d[0][MENU_DES]);?></textarea>
                  </div>
                  <div  class="col-sm-4 pad">Upload images</div>
                <div class="col-sm-8 pad">
				    <input type="file" id="file" name="files[]" multiple="multiple"  accept="image/*" />
  </div>
				  <div  class="col-sm-4 pad">Send</div>
       
       <div  class="col-sm-8 pad">  <input type="submit" class="btn btn-primary pull-right" name="update" value="Update" /></div>
                  
  
     <input  type="hidden" name="MENU_ID" value="<?php echo $_REQUEST[MENU_ID];?>"  />
				
	   
	 	   
	   </div></form>
      </div>
    
      
     
    </div>
  </div>
<?php }?>

<?php //MENU EDIT END?>






<?php //DELEVERY EDIT START?>
<?php 
if($_REQUEST[DELEVERY_ID]!="")
{
include('../includes/admin-products-management.php');
$dbFactory= new ProductsManagement();
?>
 <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel">Edit</h4>
      </div>
      <div class="modal-body">
  <form   class="editform" id="kiran" method="post"> 
  <div class="container-fluid">
  <div class="row">
   <div  class="col-sm-4 pad">

    DELEVERY STATUS: </div><div class="col-sm-8 pad"><input  type="text" name="DELIVARY_STATUS"  /></div>
          

  

   
    
     <input  type="hidden" name="TRANSACTION_ID" value="<?php echo $_REQUEST[DELEVERY_ID];?>"  />
       <div  class="col-sm-12 pad">  <input type="submit" class="btn btn-primary pull-right" name="update" value="Update" /></div></div></div></form>
      </div>
    
      
     
    </div>
  </div>
<?php }?>

<?php //DELEVERY EDIT END?>












