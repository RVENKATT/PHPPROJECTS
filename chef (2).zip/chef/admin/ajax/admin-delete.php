<?php

session_start();

ob_start();

//error_reporting(0);

?>

<?php //PRODUCT DELETE START?>

<?php /*?><?php



if($_REQUEST[PRODUCT_ID]!="")



{

include('../includes/admin-products-management.php');

$dbFactory= new ProductsManagement();

$s=$dbFactory->products_delete($_REQUEST[PRODUCT_ID]);

$ss=$dbFactory->product_img_delete($_REQUEST[PRODUCT_ID]);

for($i=0;$i<count($ss);$i++){

	$sss=$dbFactory->product_img_delete_detail($ss[$i][IMG_ID]);

	  @unlink("../product_images/".$sss[0][IMG_NAME]);

	    @unlink("../product_images/temp/".$sss[0][IMG_NAME]);

$ssss=$dbFactory->product_img_delete_edit($ss[$i][IMG_ID]);

}



?>



		



<?php



$s=$dbFactory->products($_REQUEST[PRODUCT_ID]);



for($i=0; $i<count($s); $i++){



//if($d[$i][person]=='')continue;



?>	



  <tr height="50px">



    <td><?php echo $i+1 ?></td>



    <td><?php echo $s[$i][PRODUCT_TITLE];?></td>







	    <td><?php echo $s[$i][PRODUCT_DES];?></td>



          <td><?php echo $s[$i][PRODUCT_FEATURE];?></td>



<td><?php echo $s[$i][PRODUCT_SPECIFICATION];?></td>

<td><?php echo $s[$i][PRODUCT_WARRANTY];?></td>



    <td><span class="btn btn-primary btn-xs" data-toggle="modal" data-target="#myModal1" onclick="pop_function(<?php echo $s[$i][PRODUCT_ID];?>)">EDIT</span></td>



    <td><span onclick="delid(<?php echo $s[$i][PRODUCT_ID]; ?>)">DELETE</span></td>







  </tr>



<?php }}?>







<?php //PRODUCT DELETE END ?>

<?php */?>

<?php 



if($_REQUEST[PRODUCT_ID]!="")


{



	



include('../includes/admin-menu-db.php');



$dbFactory= new menu_db();



$s=$dbFactory->product_delete($_REQUEST[PRODUCT_ID]);



?>



		



	<?php

$s=$dbFactory->products1($_GET[id]);

for($i=0; $i<count($s); $i++){

//if($d[$i][person]=='')continue;

?>	

  <tr height="50px">

    <td><?php echo $i+1 ?></td>

    

<td><?php echo $s[$i][PRODUCT_TITLE];?></td>

 <td><?php echo $s[$i][PRODUCT_DES];?></td>

  <td><?php echo $s[$i][PRODUCT_FEATURE];?></td>

  <!-- <td><?php echo $s[$i][PRODUCT_SPECIFICATION];?></td>

    <td><?php echo $s[$i][PRODUCT_WARRANTY];?></td>-->

     <td><span class="btn btn-primary btn-xs" data-toggle="modal" data-target="#myModal1" onClick="pop_function(<?php echo $s[$i][PRODUCT_ID];?>)">EDIT</span></td>



    <td><span onClick="delid(<?php echo $s[$i][PRODUCT_ID]; ?>)">DELETE</span></td>

   



  </tr>



		


<?php }}?>





<?php //USERS DELETE START ?>



<?php 



if($_REQUEST[USER_ID]!="")



{


include('../includes/admin-users-management.php');

$dbFactory= new UsersManagement();



$f=$dbFactory->user_delete($_REQUEST[USER_ID]);



	?>



	<?php



$s=$dbFactory->userss();



for($i=0; $i<count($s); $i++){



//if($d[$i][person]=='')continue;



?>	



  <tr height="50px">



    <td><?php echo $i+1 ?></td>



    <td><?php echo $s[$i][USER_NAME];?></td>



    <td><?php echo $s[$i][USER_EMAIL];?></td>



	   


    <td><?php echo $s[$i][USER_MOBILE];?></td>



    



    <td><span class="btn btn-primary btn-xs" data-toggle="modal" data-target="#myModal1" onclick="pop_function(<?php echo $s[$i][USER_ID];?>)">EDIT</span></td>



    <td><span onclick="delid(<?php echo $s[$i][USER_ID]; ?>)">DELETE</span></td>







  </tr>



<?php }}?>	



<?php //USERS DELETE END ?>	











<?php // CATEGORY DELETE START ?>










		



	<?php



$s=$dbFactory->categories_menu($_REQUEST[PARENT_ID]);



for($i=0; $i<count($s); $i++){



//if($d[$i][person]=='')continue;



?>	



  <tr height="50px">



    <td><?php echo $i+1 ?></td>



    <td><?php echo $s[$i][CATEGORY_TITLE];?></td>



    <td><?php $parent=$dbFactory->parent_detail($s[$i][PARENT_ID]);if($s[$i][PARENT_ID]==0)echo "none";else echo $parent[0][CATEGORY_TITLE];?></td>



	    <td><?php echo $s[$i][CATEGORY_ORDER];?></td>



<td><a href="categories_fields.php?id=<?php echo $s[$i][CATEGORY_ID]; ?>">ADD FIELD LABEL</a></td>



    <td><span class="btn btn-primary btn-xs" data-toggle="modal" data-target="#myModal1" onclick="pop_function(<?php echo $s[$i][CATEGORY_ID];?>)">EDIT</span></td>



    <td><span onclick="delid(<?php echo $s[$i][CATEGORY_ID]; ?>,<?php echo $_REQUEST[PARENT_ID]; ?>)">DELETE</span></td>







  </tr>



<?php }?>	







<?php // CATEGORY DELETE END ?>















<?php // MENU DELETE START ?>







<?php 



if($_REQUEST[MENU_ID]!="")



{



	



include('../includes/admin-menu-db.php');



$dbFactory= new menu_db();



$s=$dbFactory->menu_delete($_REQUEST[MENU_ID]);



?>



		



	<?php



$s=$dbFactory->menu();



for($i=0; $i<count($s); $i++){



//if($d[$i][person]=='')continue;



?>



          <tr height="50px">



            <td><?php echo $i+1 ?></td>



            <td><?php echo $s[$i][MENU_TITLE];?></td>



            <td><?php $parent=$dbFactory->menu_parent_detail($s[$i][MENU_PARENT]);if($s[$i][MENU_PARENT]==0)echo "none";else echo $parent[0][MENU_TITLE];?></td>



            <td><?php echo $s[$i][MENU_ORDER];?></td>



                     <td><?php echo $s[$i][EXTERNAL_LINK];?></td>



              



         



            <td><span class="btn btn-primary btn-xs" data-toggle="modal" data-target="#myModal1" onClick="pop_function(<?php echo $s[$i][MENU_ID];?>)">EDIT</span></td>



            <td><span onClick="delid(<?php echo $_REQUEST[MENU_ID]; ?>)">DELETE</span></td>



          </tr>



        



          <?php }}?>







<?php // MENU DELETE END ?>



<?php // FOOTER DELETE START ?>







<?php 



if($_REQUEST[FOOTER_ID]!="")



{



	



include('../includes/admin-menu-db.php');



$dbFactory= new menu_db();



$s=$dbFactory->footer_delete($_REQUEST[FOOTER_ID]);



?>



		



	<?php



$s=$dbFactory->footer();



for($i=0; $i<count($s); $i++){



//if($d[$i][person]=='')continue;



?>



          <tr height="50px">



            <td><?php echo $i+1 ?></td>



            <td><?php echo $s[$i][FOOTER_TITLE];?></td>



             <td><?php echo $s[$i][FOOTER_DES];?></td> 



         <td><?php echo $s[$i][FOOTER_DATE];?></td> 



            <td><span class="btn btn-primary btn-xs" data-toggle="modal" data-target="#myModal1" onClick="pop_function(<?php echo $s[$i][FOOTER_ID];?>)">EDIT</span></td>



            <td><span onClick="delid(<?php echo $s[$i][FOOTER_ID]; ?>)">DELETE</span></td>



          </tr>



        



          <?php }}?>







<?php // FOOTER DELETE END ?>





<?php // FOOTER_IMG DELETE START ?>







<?php 



if($_REQUEST[FOOTER_IMG_ID]!="")



{



	



include('../includes/admin-menu-db.php');



$dbFactory= new menu_db();



$s=$dbFactory->footer_img_delete($_REQUEST[FOOTER_IMG_ID]);



?>



		



	<?php



$s=$dbFactory->footers();



for($i=0; $i<count($s); $i++){



//if($d[$i][person]=='')continue;



?>



          <tr height="50px">



            <td><?php echo $i+1 ?></td>



            <td><?php echo $s[$i][FOOTER_IMG_NAME];?></td>



           



            <td><span class="btn btn-primary btn-xs" data-toggle="modal" data-target="#myModal1" onClick="pop_function(<?php echo $s[$i][FOOTER_IMG_ID];?>)">EDIT</span></td>



            <td><span onClick="delid(<?php echo $s[$i][FOOTER_IMG_ID]; ?>)">DELETE</span></td>



          </tr>



        



          <?php }}?>







<?php // FOOTER_IMG DELETE END ?>



<?php // ABOUT US DELETE START ?>







<?php 



if($_REQUEST[ABOUTUS_ID]!="")



{



	



include('../includes/admin-menu-db.php');



$dbFactory= new menu_db();



$s=$dbFactory->aboutus_delete($_REQUEST[ABOUTUS_ID]);



?>



		



	<?php



$s=$dbFactory->aboutus();



for($i=0; $i<count($s); $i++){



//if($d[$i][person]=='')continue;



?>



          <tr height="50px">



            <td><?php echo $i+1 ?></td>



            <td><?php echo $s[$i][ABOUTUS_TITLE];?></td>



             <td><?php echo $s[$i][ABOUTUS_DES];?></td> 



         



            <td><span class="btn btn-primary btn-xs" data-toggle="modal" data-target="#myModal1" onClick="pop_function(<?php echo $s[$i][ABOUTUS_ID];?>)">EDIT</span></td>



            <td><span onClick="delid(<?php echo $s[$i][ABOUTUS_ID]; ?>)">DELETE</span></td>



          </tr>



        



          <?php }}?>







<?php // ABOUT US DELETE END ?>









<?php // GALLERY IMAGES DELETE START ?>







<?php 



if($_REQUEST[GALLERY_IMG_ID]!="")



{



	



include('../includes/admin-menu-db.php');



$dbFactory= new menu_db();







	 



	 // @unlink("product_gallery/".$_REQUEST[GALLERY_IMG_ID].".jpg");



$s=$dbFactory->gallery_img_delete($_REQUEST[GALLERY_IMG_ID]);











?>



	



	<?php

$s=$dbFactory->product_gallery();

for($i=0; $i<count($s); $i++){

//if($d[$i][person]=='')continue;

?>	

  <tr height="50px">

    <td><?php echo $i+1 ?></td>

   



	 

  <td><img src="product_gallery/<?php echo $s[$i][PIC_NAME];?>" width="50px" height="50px"></td>

    <td><span onClick="delid(<?php echo $s[$i][GALLERY_IMG_ID]; ?>)">DELETE</span></td>

   



  </tr>







<?php }}?>	







<?php //  GALLERY IMAGES  END ?>





<?php // BANNER IMAGES DELETE START ?>







<?php 



if($_REQUEST[BANNER_IMG_ID]!="")



{



include('../includes/admin-menu-db.php');



$dbFactory= new menu_db();	  



$s=$dbFactory->banner_img_delete($_REQUEST[BANNER_IMG_ID]);




?>



	



	<?php

$s=$dbFactory->admin_banner();

for($i=0; $i<count($s); $i++){

//if($d[$i][person]=='')continue;

?>	

  <tr height="50px">

    <td><?php echo $i+1 ?></td>

     <td><?php echo $s[$i][BANNER_ORDER];?></td>



	 

  <td><img src="gallery/<?php echo $s[$i][BANNER_IMG_ID];?>" width="50px" height="50px"></td>

  <td><span class="btn btn-primary btn-xs" data-toggle="modal" data-target="#myModal1" onClick="pop_function(<?php echo $s[$i][BANNER_IMG_ID];?>)">EDIT</span></td>



    <td><span onClick="delid(<?php echo $s[$i][BANNER_IMG_ID]; ?>)">DELETE</span></td>

   



  </tr>







<?php }}?>	







<?php //  BANNER IMAGES  END ?>