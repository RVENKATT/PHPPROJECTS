<?php
session_start();
ob_start();

error_reporting(0);
if($_SESSION[ADMIN_ID]=='')
{

	
	header("location:index.php");
}
include('includes/admin-menu-db.php');
$dbFactory= new menu_db();
if(isset($_REQUEST[add]))
{
	
    	$aboutus_des=mysql_escape_string($_REQUEST[ABOUTUS_DES]);
	$d=$dbFactory->aboutus_add($_REQUEST[ABOUTUS_TITLE],$aboutus_des);
  


header("location:admin-aboutus.php?mes=1");
}
if(isset($_REQUEST[update]))
{
 
    	$aboutus_des=mysql_escape_string($_REQUEST[ABOUTUS_DES]);
	$d=$dbFactory->aboutus_update($_REQUEST[ABOUTUS_TITLE],$aboutus_des,$_REQUEST[ABOUTUS_ID]);
  

	  
	header("location:admin-aboutus.php?id=$_REQUEST[CATEGORY_ID]&mes=2");
}

if(isset($_REQUEST['did']))

{

   $s=$dbFactory->aboutus_delete($_REQUEST['did']);

   header("location:admin-aboutus.php?mes=3");

}



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Dark Admin</title>

    <link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.min.css" />
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
    <link rel="stylesheet" type="text/css" href="css/style.css" />
		<link href="http://cdn.datatables.net/plug-ins/725b2a2115b/integration/bootstrap/3/dataTables.bootstrap.css" rel="stylesheet">

<script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.js"></script>
	<script src="js/scripts.js"></script>

	<script src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js"></script>
<script src="http://cdn.datatables.net/plug-ins/725b2a2115b/integration/bootstrap/3/dataTables.bootstrap.js"></script>
    <script type="text/javascript">
	function  pop_function(BANNER_IMG_ID,category_id)
	{
	//menu loading

$.post("ajax/admin-edit.php?ABOUTUS_ID="+BANNER_IMG_ID,function(data){

document.getElementById('myModal1').innerHTML=data;
tinymce.init({

plugins: [

"code"

],

toolbar: "code",

selector:'textarea'

});

});
	}
	</script>
    
    <script type="text/javascript">
	
function delid(ABOUTUS_ID)

{

i=confirm("Are you sure to delete the item");

if(i)

window.location="admin-aboutus.php?did="+ABOUTUS_ID;

}



</script>

    <script src="http://tinymce.cachefly.net/4.1/tinymce.min.js"></script>

<script>

tinymce.init({

plugins: [

"code"

],

toolbar: "code",

selector:'textarea'

});</script>
    
     


<script src="jquery.js"></script>
	<script src="jquery.validate.js"></script>
	<script>
	

	$().ready(function() {
		// validate the comment form when it is submitted
		

		// validate signup form on keyup and submit
		$("#commentForm").validate({
			rules: {
				CATEGORY_TITLE: "required",
				
				PARENT_ID: "required",
				CATEGORY_ORDER: "required"
	
		
		
				
			},
			messages: {
				CATEGORY_TITLE: "Please enter your category title",
					PARENT_ID: "Please select  parent ",
			
			
				CATEGORY_ORDER: "Please enter your category order"
		
			
			}
		});

			});
	</script>
    	<style>

	form.addform label.error, label.error {
	/* remove the next line when you have trouble in IE6 with labels in list */
	color: red;
	font-style: italic
}

	</style>
    

 
</head>
<body>







    <div id="wrapper">

            <?php include('includes/admin-header.php')?>

        <div id="page-wrapper">
		<div style="display:none;<?php if($_GET[mes]==1){?>display:block<?php }?>">
             <div class="alert alert-dismissable alert-success">
               <button type="button" class="close" data-dismiss="alert">&#x2715;</button>
               <strong>IMAGE Added Successfully .</strong>
             </div>
           </div>
           	<div style="display:none;<?php if($_GET[mes]==2){?>display:block<?php }?>">
             <div class="alert alert-dismissable alert-success">
               <button type="button" class="close" data-dismiss="alert">&#x2715;</button>
               <strong> banner Updated Successfully.</strong>
             </div>
           </div>
        
		<legend>About us
		<span class="pull-right"><button class="btn btn-primary" data-toggle="modal" data-target="#myModal">Add</button></span></legend>
        
        
        <hr style="color: #303">

<!-- Modal -->
<div class="modal fade bs-example-modal-lg" id="myModal" tabmenu="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">

      <div class="modal-dialog">

        <div class="modal-content">

          <div class="modal-header">

            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>

            <h4 class="modal-title" id="myModalLabel">ADD</h4>

          </div>

          <div class="modal-body">
   <form enctype="multipart/form-data"  class="addform" id="commentForm" method="post">

              <div class="container-fluid">

                <div class="row">
                <div  class="col-sm-5 pad">ABOUT US TITLE:</div>

                  <div class="col-sm-7 pad">

              <input type="text"  name="ABOUTUS_TITLE" >

                                       </div>
   
      <div  class="col-sm-5 pad">DESCRIPTION:</div>

                  <div class="col-sm-7 pad">

              <textarea  name="ABOUTUS_DES" ></textarea>

                                       </div>
                  
       	
    
       <div  class="col-sm-12 pad">  <input type="submit" class="btn btn-primary pull-right" name="add" value="ADD" /></div></div></div></form>
      </div>
    
      
     
    </div>
  </div>
  </div>

		
		<div class="clearfix"></div>
		<div class="table-responsive">
		<table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
        <thead>
            <tr>
			 <th>SNO</th>
             <th>TITLE</th>
             <th>DESCRIPTION</th>
                   <th></th>      
               <th></th>
            </tr>
        </thead>
 
        
 
        <tbody id="cat_tab_id">
		
	<?php
$s=$dbFactory->aboutus($_GET[id]);
for($i=0; $i<count($s); $i++){
//if($d[$i][person]=='')continue;
?>	
  <tr height="50px">
    <td><?php echo $i+1 ?></td>
 <td><?php echo $s[$i][ABOUTUS_TITLE];?></td>   
 <td><?php echo $s[$i][ABOUTUS_DES];?></td>
     <td><span class="btn btn-primary btn-xs" data-toggle="modal" data-target="#myModal1" onClick="pop_function(<?php echo $s[$i][ABOUTUS_ID];?>)">EDIT</span></td>

    <td><span onClick="delid(<?php echo $s[$i][ABOUTUS_ID]; ?>)">DELETE</span></td>
   

  </tr>
<?php }?>
		
		
           
		</tbody>
    </table>
      
      </div>
		
		</div>
		</div>

    
    
    <div class="modal fade bs-example-modal-lg" id="myModal1" tabadmin_banner="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  
</div>
    <!-- /#wrapper -->
    
</body>
</html>
