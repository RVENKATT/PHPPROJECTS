<?php
session_start();
ob_start();

error_reporting(0);
if($_SESSION[ADMIN_ID]=='')
{

	
	header("location:index.php");
}
include('includes/admin-menu-db.php');
$dbFactory= new menu_db();


if(isset($_REQUEST[add]))
{
	$link=mysql_escape_string($_REQUEST[EXTERNAL_LINK]);
	$product_img=$dbFactory->gallery_img_add($_REQUEST[CONTENT]);

	

//header("location:admin_banner.php?id=$_REQUEST[CATEGORY_ID]&mes=1");
}


if(isset($_REQUEST['update']))

{



	$link=mysql_escape_string($_REQUEST[EXTERNAL_LINK]);
	$product_img=$dbFactory->gallery_update($_REQUEST[IMG_NAME],$_REQUEST[CONTENT],$_REQUEST[GALLERY_IMG_ID]);

	
	
	//header("location:admin_banner.php?id=$_REQUEST[CATEGORY_ID]&mes=1");
}



if(isset($_REQUEST['did']))

{

   $s=$dbFactory->gallery_delete($_REQUEST['did']);

   header("location:admin-gallery.php?mes=3");

}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Dark Admin</title>

    <link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.min.css" />
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
    <link rel="stylesheet" type="text/css" href="css/style.css" />
		<link href="http://cdn.datatables.net/plug-ins/725b2a2115b/integration/bootstrap/3/dataTables.bootstrap.css" rel="stylesheet">

<script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.js"></script>
	<script src="js/scripts.js"></script>

	<script src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js"></script>
<script src="http://cdn.datatables.net/plug-ins/725b2a2115b/integration/bootstrap/3/dataTables.bootstrap.js"></script>
<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
  <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
    
	<script type="text/javascript">
	
	function  pop_function(GALLERY_IMG_ID)
	{
	//menu loading
$.post("ajax/admin-edit.php?GALLERY_IMG_ID="+GALLERY_IMG_ID,function(data){

document.getElementById('myModal2').innerHTML=data;

 $( "#datepicker" ).datepicker({
      
	  dateFormat:"yy-mm-dd",
	  changeMonth: true,
      changeYear: true
    });
	tinymce.init({

plugins: [

"code"

],

toolbar: "code",

selector:'textarea'

});
 
});
	}
	</script>
    
    
     <script type="text/javascript">
function delid(GALLERY_IMG_ID)

{

i=confirm("Are you sure to delete the item");

if(i)

window.location="admin-gallery.php?did="+GALLERY_IMG_ID;

}



</script>


<script src="jquery.js"></script>
	<script src="jquery.validate.js"></script>
	<script>
	

	$().ready(function() {
		// validate the comment form when it is submitted
		

		// validate signup form on keyup and submit
		$("#commentForm").validate({
			rules: {
				CATEGORY_TITLE: "required",
				
				PARENT_ID: "required",
				CATEGORY_ORDER: "required"
	
		
		
				
			},
			messages: {
				CATEGORY_TITLE: "Please enter your category title",
					PARENT_ID: "Please select  parent ",
			
			
				CATEGORY_ORDER: "Please enter your category order"
		
			
			}
		});

			});
	</script>
    <script src="http://tinymce.cachefly.net/4.1/tinymce.min.js"></script>

<script>

tinymce.init({

plugins: [

"code"

],

toolbar: "code",

selector:'textarea'

});</script>
    	<style>

	form.addform label.error, label.error {
	/* remove the next line when you have trouble in IE6 with labels in list */
	color: red;
	font-style: italic
}

	</style>
    

 
</head>
<body>







    <div id="wrapper">

            <?php include('includes/admin-header.php')?>

        <div id="page-wrapper">
		<div style="display:none;<?php if($_GET[mes]==1){?>display:block<?php }?>">
             <div class="alert alert-dismissable alert-success">
               <button type="button" class="close" data-dismiss="alert">&#x2715;</button>
               <strong>IMAGE Added Successfully .</strong>
             </div>
           </div>
           	<div style="display:none;<?php if($_GET[mes]==2){?>display:block<?php }?>">
             <div class="alert alert-dismissable alert-success">
               <button type="button" class="close" data-dismiss="alert">&#x2715;</button>
               <strong> banner Updated Successfully.</strong>
             </div>
           </div>
        
		<legend>Gallery
		<span class="pull-right"><button class="btn btn-primary" data-toggle="modal" data-target="#myModal">Add</button></span></legend>
        
        
        <hr style="color: #303">

<!-- Modal -->
<div class="modal fade bs-example-modal-lg" id="myModal" tabadmin_banner="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel">Edit</h4>
      </div>
      <div class="modal-body">
  <form   class="addform" id="commentForm" enctype="multipart/form-data" method="post" > 
  <div class="container-fluid">
  <div class="row">

      <div  class="col-sm-5 pad">DESCRIPTION:</div>

                  <div class="col-sm-7 pad"> <textarea name="CONTENT" /></textarea> </div>         

                     

    
       <div  class="col-sm-12 pad">  <input type="submit" class="btn btn-primary pull-right" name="add" value="ADD" /></div></div></div></form>
      </div>
    
      
     
    </div>
    
  </div>
  
  </div>

		
		<div class="clearfix"></div>
		<div class="table-responsive">
		<table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
        <thead>
            <tr>
			 <th>SNO</th>
                <th>DESCRIPTION</th>
                 <th>DATE</th>
         
                <th></th>
               <th></th>
            </tr>
        </thead>
 
        
 
        <tbody id="cat_tab_id">
		
	<?php
$s=$dbFactory->gallery();
for($i=0; $i<count($s); $i++){
//if($d[$i][person]=='')continue;
?>	
  <tr height="50px">
    <td><?php echo $i+1 ?></td>
    <td><?php echo $s[$i][CONTENT];?></td>

	 
  <td><?php echo $s[$i][DATE];?></td>
  <td><span class="btn btn-primary btn-xs" data-toggle="modal" data-target="#myModal2" onClick="pop_function(<?php echo $s[$i][GALLERY_IMG_ID];?>)">EDIT</span></td>
    <td><span onClick="delid(<?php echo $s[$i][GALLERY_IMG_ID]; ?>)">DELETE</span></td>
   

  </tr>
<?php }?>
		
		
           
		</tbody>
    </table>
      
      </div>
		
		</div>
		</div>

    
    
    <div class="modal fade bs-example-modal-lg" id="myModal2" tabadmin_banner="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  
</div>
    <!-- /#wrapper -->
    
</body>
</html>
