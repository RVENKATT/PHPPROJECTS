<?php

session_start();

ob_start();

error_reporting();

if($_SESSION[ADMIN_ID]=='')

{
header("location:index.php");
}

include('includes/admin-menu-db.php');

$dbFactory= new menu_db();

if(isset($_REQUEST[add]))

{
$menu_title=mysql_escape_string($_REQUEST[MENU_TITLE]);

	$menu_des=mysql_escape_string($_REQUEST[MENU_DES]);

	$link=mysql_escape_string($_REQUEST[EXTERNAL_LINK]);

$f=$dbFactory->menu_add($menu_title,$_REQUEST[MENU_PARENT],$_REQUEST[MENU_ORDER],$link,$menu_des,$_REQUEST[MENU_OR_NOT]);



header("location:admin-menu.php");

}

if(isset($_REQUEST[update]))

{

//echo "Updating<br>";
	$menu_des=mysql_escape_string($_REQUEST[MENU_DES]);

	$link=mysql_escape_string($_REQUEST[EXTERNAL_LINK]);

 $f=$dbFactory->menu_update($_REQUEST[MENU_TITLE],$menu_des,$link,$_REQUEST[MENU_ID],$_REQUEST[MENU_ORDER],$_REQUEST[STYLE]);
if($_FILES['files']['name'][0]!='')

	{



    $errors= array();

	foreach($_FILES['files']['tmp_name'] as $key => $tmp_name )

	{

		$file_name = $_FILES['files']['name'][$key];

		$file_size =$_FILES['files']['size'][$key];

		$file_tmp =$_FILES['files']['tmp_name'][$key];

		$file_type=$_FILES['files']['type'][$key];	

   

	if($_FILES['files']['type'][$key]=="image/png")

	$x="png";

	if($_FILES['files']['type'][$key]=="image/jpeg")

	$x="jpeg";

	if($_FILES['files']['type'][$key]=="image/jpg")

	$x="jpg";

	if($_FILES['files']['type'][$key]=="image/gif")

	$x="gif";



	$product_img=$dbFactory->products_img_add($_REQUEST[MENU_ID],$img_name);

  

		$img_name=$product_img.".".$x;

  

			$product_img_update=$dbFactory->products_img_add_update($product_img,$img_name);

        $desired_dir="images";

       

            if(is_dir($desired_dir)==false){

                mkdir("$desired_dir", 0700);		// Create directory if it does not exist

            }

           echo "images/".$product_img.".".$x;

                move_uploaded_file($file_tmp,"images/".$product_img.".".$x);

         			

      }



}


	header("location:admin-menu.php");

}

if(isset($_REQUEST['did']))

{

   $s=$dbFactory->menu_delete($_REQUEST['did']);

   header("location:admin-menu.php?mes=3");

}



?>
<?php

function make_thumb($img_name,$filename,$new_w,$new_h)

{

$ext=getExtension($img_name);

if(!strcmp("jpg",$ext) || !strcmp("JPG",$ext) || !strcmp("jpeg",$ext) || !strcmp("JPEG",$ext))

$src_img=imagecreatefromjpeg($img_name);

if(!strcmp("gif",$ext) || !strcmp("GIF",$ext))

$src_img=imagecreatefromgif($img_name);

if(!strcmp("png",$ext) || !strcmp("PNG",$ext))

$src_img=imagecreatefrompng($img_name);

$old_x=imagesx($src_img);

$old_y=imagesy($src_img);

$ratio1=$old_x/$new_w;

$ratio2=$old_y/$new_h;

if($ratio1>$ratio2) {

$thumb_w=$new_w;

$thumb_h=$old_y/$ratio1;

}

else {

$thumb_h=$new_h;

$thumb_w=$old_x/$ratio2;

}

$dst_img=ImageCreateTrueColor($thumb_w,$thumb_h);

imagecopyresampled($dst_img,$src_img,0,0,0,0,$thumb_w,$thumb_h,$old_x,$old_y);

if(!strcmp("png",$ext))

imagepng($dst_img,$filename);

if(!strcmp("gif",$ext))

imagegif($dst_img,$filename);

else

imagejpeg($dst_img,$filename);

imagedestroy($dst_img);

imagedestroy($src_img);

}

function getExtension($str) {

$i = strrpos($str,".");

if (!$i) { return ""; }

$l = strlen($str) - $i;

$ext = substr($str,$i+1,$l);

return $ext;

}

 ?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="utf-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Dashboard - Dark Admin</title>

<link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.min.css" />

<link rel="stylesheet" type="text/css" href="css/bootstrap.css" />

<link rel="stylesheet" type="text/css" href="css/style.css" />

<link href="http://cdn.datatables.net/plug-ins/725b2a2115b/integration/bootstrap/3/dataTables.bootstrap.css" rel="stylesheet">

<script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>

<script type="text/javascript" src="js/bootstrap.js"></script>

<script src="js/scripts.js"></script>

<script src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js"></script>

<script src="http://cdn.datatables.net/plug-ins/725b2a2115b/integration/bootstrap/3/dataTables.bootstrap.js"></script>

<script type="text/javascript">

	function  pop_function(MENU_ID)

	{

	//menu loading

$.post("ajax/admin-edit.php?MENU_ID="+MENU_ID,function(data){



document.getElementById('myModal1').innerHTML=data;

tinymce.init({
plugins: [
"code"
],
toolbar: "code",
selector:'textarea'
});


});

	}
</script>

<script type="text/javascript">

	function  pop_function(MENU_ID)

	{

	//menu loading

$.post("ajax/admin-edit.php?MENU_ID="+MENU_ID,function(data){



document.getElementById('myModal1').innerHTML=data;



});

	}

	</script>
	

	

	</script>

<script type="text/javascript">

function delid(MENU_ID)

{

i=confirm("Are you sure to delete the item");

if(i)

window.location="admin-menu.php?did="+MENU_ID;

}



</script>

	<script src="http://tinymce.cachefly.net/4.1/tinymce.min.js"></script>

<script>

tinymce.init({

plugins: [

"code"

],

toolbar: "code",

selector:'textarea'

});</script>

<script src="jquery.js"></script>

<script src="jquery.validate.js"></script>

<script>

	



	$().ready(function() {

		// validate the comment form when it is submitted

		



		// validate signup form on keyup and submit

		$("#commentForm").validate({

			rules: {

				MENU_TITLE: "required",

				

				MENU_PARENT: "required",

				MENU_ORDER: "required"

	

		

		

				

			},

			messages: {

				MENU_TITLE: "Please enter your category title",

					MENU_PARENT: "Please select  parent ",

			

			

				MENU_ORDER: "Please enter your category order"

		

			

			}

		});



			});

	</script>

<style>

form.addform label.error, label.error {

	/* remove the next line when you have trouble in IE6 with labels in list */

	color: red;

	font-style: italic

}

</style>

</head>

<body>

<div id="wrapper">



    <?php include('includes/admin-header.php')?>
  <div id="page-wrapper">

  

    <legend>menu <span class="pull-right">

    <button class="btn btn-primary" data-toggle="modal" data-target="#myModal">Add</button>

    </span></legend>

    <hr style="color: #303">

    

    <!-- Modal -->

    <div class="modal fade bs-example-modal-lg" id="myModal" tabmenu="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">

      <div class="modal-dialog">

        <div class="modal-content">

          <div class="modal-header">

            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>

            <h4 class="modal-title" id="myModalLabel">ADD</h4>

          </div>

          <div class="modal-body">


            <form enctype="multipart/form-data"  class="addform" id="commentForm" method="post">

              <div class="container-fluid">

                <div class="row">

                  <div  class="col-sm-4 pad">



                    Menu Title: </div>

                  <div class="col-sm-8 pad">

                    <input  type="text" name="MENU_TITLE"   />

                  </div>

                  <div  class="col-sm-4 pad"> Parent: </div>

                  <div  class="col-sm-8 pad">

                    <select  name="MENU_PARENT" style="width:155px">

                      <option value="0">-Select-</option>

                      <?php

$s=$dbFactory->menu();

for($i=0; $i<count($s); $i++){

//if($d[$i][person]=='')continue;

?>

                      <option value="<?php echo $s[$i][MENU_ID]; ?>"><?php echo $s[$i][MENU_TITLE]; ?></option>

                      <?php }?>

                    </select>

                  </div>

                  <div  class="col-sm-4 pad">Order:</div>

                  <div class="col-sm-8 pad">

                    <input  type="text" name="MENU_ORDER" />

                  </div>

                  <div  class="col-sm-4 pad">Link:</div>

                  <div class="col-sm-8 pad">

              

                     <input  type="text" name="EXTERNAL_LINK" />

                  </div>

                  <div  class="col-sm-4 pad">Description:</div>

                  <div class="col-sm-8 pad">

                         <textarea  name="MENU_DES" ></textarea>

                  </div>
                   <div  class="col-sm-4 pad">MENU OR NOT:</div>
                  <div class="col-sm-8 pad">
                      <input  type="radio" name="MENU_OR_NOT"  value="0" />MENU PAGE
                         <input  type="radio" name="MENU_OR_NOT"  value="1" />NOT MENU PAGE
                     
                  </div>
                  <div  class="col-sm-4 pad">Upload Image:</div>
                  <div class="col-sm-8 pad">
<input type="file" name="files[]"  id="file" multiple/>
</div>
                  <div  class="col-sm-12 pad">

                    <input type="submit" class="btn btn-primary pull-right" name="add" value="ADD" />

                  </div>

                </div>

              
              </div>

            </form>

          </div>

        </div>

      </div>

    </div>

    <div class="clearfix"></div>

    <div class="table-responsive">

      <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">

        <thead>

          <tr>

            <th>SNO</th>

            <th>TITLLE</th>

                <th>PAGE</th>

              

        

            <th>MENU_DES</th>

             

             

   					<th></th>

            

        

            <th></th>

          </tr>

        </thead>

        <tbody id="cat_tab_id">

          <?php

$s=$dbFactory->menu();

for($i=0; $i<count($s); $i++){

//if($d[$i][person]=='')continue;

?>

          <tr height="50px">

            <td><?php echo $i+1 ?></td>

            <td><?php echo $s[$i][MENU_TITLE];?></td>

            <td>content.php?id=<?php echo $s[$i][MENU_ID];?></td>

<!--            <td><?php $parent=$dbFactory->menu_parent_detail($s[$i][MENU_PARENT]);if($s[$i][MENU_PARENT]==0)echo "none";else echo $parent[0][MENU_TITLE];?></td>
-->
            <td><?php echo $s[$i][MENU_DES];?></td>

    

            <td><span class="btn btn-primary btn-xs" data-toggle="modal" data-target="#myModal1" onClick="pop_function(<?php echo $s[$i][MENU_ID];?>)">EDIT</span></td>

            <td><span onClick="delid(<?php echo $s[$i][MENU_ID]; ?>)">DELETE</span></td>

          </tr>

          <?php }?>

        </tbody>

      </table>

    </div>

  </div>

</div>

<div class="modal fade bs-example-modal-lg" id="myModal1" tabmenu="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true"> </div>

<!-- /#wrapper -->



</body>

</html>

