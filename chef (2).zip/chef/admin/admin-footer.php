<?php



session_start();



ob_start();



error_reporting();



if($_SESSION[ADMIN_ID]=='')



{	



	header("location:index.php");



}











include('includes/admin-menu-db.php');



$dbFactory= new menu_db();



if(isset($_REQUEST[add]))



{



	$footer_des=mysql_escape_string($_REQUEST[FOOTER_DES]);


$f=$dbFactory->footer_add($_REQUEST[FOOTER_NAME],$footer_des);

$temp=$f;

if($_FILES["files"]["name"]!='')

{

	for($j=0; $j<count($_FILES["files"]); $j++)

	{

	echo "footer/".$_FILES["files"]["name"][$j];

move_uploaded_file($_FILES["files"]["tmp_name"][$j],"footer/".$temp.".jpg");

}

}

header("location:admin-footer.php");



}



if(isset($_REQUEST[update]))



{



	$CONTENT_DESCRIPTION=mysql_escape_string($_REQUEST[FOOTER_CONTENT]);



	



 $f=$dbFactory->footer_update($CONTENT_DESCRIPTION,$_REQUEST[FOOTER_ID]);

 $temp=$f;


	header("location:admin-footer.php");



}

if(isset($_REQUEST[did]))



{	

 $f=$dbFactory->footer_delete(($_REQUEST[did]));


	header("location:admin-footer.php?mes=3");

}








?>

<!DOCTYPE html>

<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard - Dark Admin</title>
<link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.min.css" />
<link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
<link rel="stylesheet" type="text/css" href="css/style.css" />
<link href="http://cdn.datatables.net/plug-ins/725b2a2115b/integration/bootstrap/3/dataTables.bootstrap.css" rel="stylesheet">
<script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
<script type="text/javascript" src="js/bootstrap.js"></script>
<script src="js/scripts.js"></script>
<script src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js"></script>
<script src="http://cdn.datatables.net/plug-ins/725b2a2115b/integration/bootstrap/3/dataTables.bootstrap.js"></script>
<script type="text/javascript">



	function  pop_function(FOOTER_ID)



	{



	//menu loading



$.post("ajax/admin-edit.php?FOOTER_ID="+FOOTER_ID,function(data){







document.getElementById('myModal2').innerHTML=data;


tinymce.init({



plugins: [



"code"



],



toolbar: "code",



selector:'textarea'



});




});



	}



	</script>
    
<script type="text/javascript">

function delid(FOOTER_ID)

{

i=confirm("Are you sure to delete the item");

if(i)

window.location="admin-footer.php?did="+FOOTER_ID;

}



</script>


<script src="http://tinymce.cachefly.net/4.1/tinymce.min.js"></script>



<script>



tinymce.init({



plugins: [



"code"



],



toolbar: "code",



selector:'textarea'



});</script>




</head>

<body>
<div id="wrapper">
  <?php include('includes/admin-header.php')?>
  <div id="page-wrapper">
   <!-- <legend>Footer <span class="pull-right">
    <button class="btn btn-primary" data-toggle="modal" data-target="#myModal">Add</button>
    </span></legend>-->
    <hr style="color: #303">
    
    <!-- Modal -->
    <div class="modal fade bs-example-modal-lg" id="myModal" tabadmin_banner="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">

  <div class="modal-dialog">

    <div class="modal-content">

      <div class="modal-header">

        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>

        <h4 class="modal-title" id="myModalLabel">ADD</h4>

      </div>

      <div class="modal-body">

  <form   class="addform" id="commentForm" enctype="multipart/form-data" method="post" > 

  <div class="container-fluid">

  <div class="row">

   <div  class="col-sm-5 pad">FOOTER NAME</div><div class="col-sm-7 pad"> <input  type="text" name="FOOTER_NAME" /></div>
	
    
  





     <div  class="col-sm-5 pad">FOOTER_DES</div><div class="col-sm-7 pad"> <textarea  name="FOOTER_DES"  col="5" rows="5"></textarea></div>

       <div  class="col-sm-12 pad">  <input type="submit" class="btn btn-primary pull-right" name="add" value="ADD" /></div></div></div></form>

      </div>
      </div>
      </div>
      </div>
      

    <div class="clearfix"></div>
    <div class="table-responsive">
      <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
        <thead>
          <tr>
            <th>SNO</th>
           
            <th>FOOTER DES</th>
            <th></th>
          <!--  <th></th>-->
         
          </tr>
        </thead>
        <tbody id="cat_tab_id">
          <?php



$s=$dbFactory->footer1();



for($i=0; $i<count($s); $i++){



//if($d[$i][person]=='')continue;



?>
          <tr height="50px">
            <td><?php echo $i+1 ?></td>
           
            <td><?php echo $s[$i][FOOTER_CONTENT];?></td>
            <td><span class="btn btn-primary btn-xs" data-toggle="modal" data-target="#myModal2" onClick="pop_function(<?php echo $s[$i][FOOTER_ID];?>)">EDIT</span></td>
            
                 <!-- <td><span onClick="delid(<?php echo $s[$i][FOOTER_ID]; ?>)">DELETE</span></td> -->
            
          </tr>
          <?php }?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<div class="modal fade bs-example-modal-lg" id="myModal2" tabmenu="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true"> </div>

<!-- /#wrapper -->

</body>
</html>
