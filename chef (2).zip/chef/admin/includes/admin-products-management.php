<?php



/***************************************************************



* Author      : Anand



* Description : This is a DBFactory deals with model operations 



* Date        : 21-09-2011







****************************************************************/



include('admin-connection-db.php');







class ProductsManagement{







   /* This function connects to the database server and selects the database it deals with. */







  function query($str)



   {   



        $result=mysql_query($str);



		while($row=mysql_fetch_array($result))



		$output[]=$row;



		return $output;



   }







function offers_admin($s)







   {







   $str="select * from adminuser where username ='$s'";







   $result=$this->query($str);







   return $result;







   }



   function equery($str)



   {   



        mysql_query($str);



   }



 



   function count_query($str)



   {



   		$result=mysql_query($str);



		$row=mysql_num_rows($result);



		return $row;



   }



   function registeruser_check($name,$password)



	 {



	 "select * from userss where EMAIL='$name' and PASSWORD='$password'";



     $str="select * from userss where EMAIL='$name' and PASSWORD='$password'";



     $result=$this->query($str);



     return $result;



	 } 



	    function registeruser_check1($name,$password)



	 {



	 "select * from adminuser where admin='$name' and password='$password'";



     $str="select * from adminuser where ADMIN_NAME='$name' and PASSWORD='$password'";



     $result=$this->query($str);



     return $result;



	 } 



	 //PRODUCTS



	 function products_add($PRODUCT_TITLE,$PRODUCT_DES,$PRODUCT_COST,$PRODUCT_OLD_COST,$CATEGORY_ID,$CATEGORY_FIELD_VALUE_ID,$PRODUCT_STATUS)



    {



	$que="INSERT INTO products(PRODUCT_TITLE,PRODUCT_DES,PRODUCT_COST,PRODUCT_OLD_COST,CATEGORY_ID,PRODUCT_STATUS) VALUES('$PRODUCT_TITLE','$PRODUCT_DES','$PRODUCT_COST','$PRODUCT_OLD_COST','$CATEGORY_ID','$PRODUCT_STATUS')";



	$this->equery($que);



	$product_id=mysql_insert_id();



	for($i=0;$i<count($CATEGORY_FIELD_VALUE_ID);$i++)



	{



		$x=$CATEGORY_FIELD_VALUE_ID[$i];



		 $ques="INSERT INTO  product_field_values(CATEGORY_FIELD_VALUE_ID,PRODUCT_ID) VALUES($x,$product_id)";



	$this->equery($ques);



	}



	return $product_id;



	}



	



		 function products_add_excel($PRODUCT_TITLE,$PRODUCT_DES,$PRODUCT_COST,$CATEGORY_ID)



    {



	 $que="INSERT INTO products(PRODUCT_TITLE,PRODUCT_DES,PRODUCT_COST,CATEGORY_ID,PRODUCT_STATUS) VALUES('$PRODUCT_TITLE','$PRODUCT_DES','$PRODUCT_COST','$CATEGORY_ID',1)";



	$this->equery($que);











	}



	



	



	function products_img_add($PRODUCT_ID,$IMG_NAME)



    {



	$que="INSERT INTO product_images(PRODUCT_ID,IMG_NAME) VALUES('$PRODUCT_ID','$IMG_NAME')";



	$this->equery($que);



	$product_img_id=mysql_insert_id();



	return $product_img_id;







	}



	function products_img_add_update($IMG_ID,$IMG_NAME)



    {



	$que="UPDATE  product_images SET IMG_NAME='$IMG_NAME' where IMG_ID=$IMG_ID";



	$this->query($que);







	







	}



	  	  	 function product_img_delete($PRODUCT_ID)



   {



    $str="select * from images where PRODUCT_ID=$PRODUCT_ID ";



   $result=$this->query($str);



   return $result;



   }





		

		 function products_update($PRODUCT_TITLE,$PRODUCT_DES,$PRODUCT_COST,$PRODUCT_OLD_COST,$CATEGORY_ID,$CATEGORY_FIELD_VALUE_ID,$PRODUCT_ID)



    {



	 $que="UPDATE   products SET  PRODUCT_TITLE='$PRODUCT_TITLE',PRODUCT_DES='$PRODUCT_DES' ,PRODUCT_COST='$PRODUCT_COST',PRODUCT_OLD_COST='$PRODUCT_OLD_COST',CATEGORY_ID=$CATEGORY_ID where PRODUCT_ID=$PRODUCT_ID";



	$this->query($que);







		  $que="delete from product_field_values where PRODUCT_ID='$PRODUCT_ID'";



			$this->equery($que);  



	for($i=0;$i<count($CATEGORY_FIELD_VALUE_ID);$i++)



	{



		$x=$CATEGORY_FIELD_VALUE_ID[$i];



		 $ques="INSERT INTO  product_field_values(CATEGORY_FIELD_VALUE_ID,PRODUCT_ID) VALUES($x,$PRODUCT_ID)";



	$this->equery($ques);



	}



	}



	  



	  	 function products()



   {



    $str="select * from product  ";



   $result=$this->query($str);



   return $result;



   }



   	  



	  	 function pending_products()



   {



    $str="select * from products where PRODUCT_STATUS=0 



	 ORDER BY PRODUCT_ID DESC";



   $result=$this->query($str);



   return $result;



   }




   	  	 function allproducts()



   {



    $str="select * from products ";



   $result=$this->query($str);



   return $result;



   }



   	  	 function products_detail($PRODUCT_ID)



   {



    $str="select * from product where PRODUCT_ID=$PRODUCT_ID ";



   $result=$this->query($str);



   return $result;



   }

function aboutus_detail($ABOUTUS_ID)



   {



    $str="select * from aboutus where ABOUTUS_ID=$ABOUTUS_ID ";



   $result=$this->query($str);



   return $result;



   }

   



    	 function products_delete($PRODUCT_ID)



   {



    $str="delete from products where PRODUCT_ID=$PRODUCT_ID ";



	



   $this->equery($str);



     $str1="delete from product_field_values where PRODUCT_ID=$PRODUCT_ID ";



	



   $this->equery($str1);







   }





	



	



		  	    	  	     function user_old_product_update1($PRODUCT_ID)



	  {



	   $str="update products set PRODUCT_STATUS='1' where PRODUCT_ID=$PRODUCT_ID";



       $this->query($str);



       



      }



	    	    	  	     function user_old_product_update2($PRODUCT_ID)



	  {



	   $str="update products set PRODUCT_STATUS='0' where PRODUCT_ID=$PRODUCT_ID";



       $this->query($str);



       



      }













		  	    	  	     function notfeatured($PRODUCT_ID)



	  {



	   $str="update products set FEATURE='1' where PRODUCT_ID=$PRODUCT_ID";



       $this->query($str);



       



      }



	    	    	  	     function featured($PRODUCT_ID)



	  {



	   $str="update products set FEATURE='0' where PRODUCT_ID=$PRODUCT_ID";



       $this->query($str);



       



      }

	 



	 //PRODUCTS



	 



	   	  	 function transactions()



   {



    $str="select * from transaction  ORDER BY TRANSACTION_ID DESC";



   $result=$this->query($str);



   return $result;



   }



   



      	  	 function transaction_details($TRANSACTION_ID)



   {



    $str="select * from transaction_details where TRANSACTION_ID=$TRANSACTION_ID ";



   $result=$this->query($str);



   return $result;



   }

   	 function product_review($PRODUCT_ID)



	   {



		$str="select * from product_reviews where PRODUCT_ID=$PRODUCT_ID ";



	   $result=$this->query($str);



	   return $result;



	   }


	

}







 



?>