<div id="fblock" class="cl">
 <div class="center_block">
  <div class="block1 fl">
   <h1 class="gtitle">Job Center</h1>
    <ul class="fblock">
	 <li><a href="#">About Us</a></li>
	 <li><a href="#">Contact Us</a></li>
	 <li><a href="#">Sitemap</a></li>
	 <li><a href="#">Terms of Use</a></li>
	 <li><a href="#">Privacy Policy</a></li>
	</ul>
  </div>
  <div class="block1 fl">
   <h1 class="gtitle">Job Seeker</h1>
    <ul class="fblock">
	 <li><a href="#">Why Job Centre?</a></li>
	 <li><a href="#">Login</a></li>
	 <li><a href="#">Resume Writing</a></li>
	 <li><a href="#">FAQ's</a></li>
	 </ul>
  </div>
   <div class="block1 fl">
   <h1 class="gtitle">Employers</h1>
    <ul class="fblock">
	 <li><a href="#">Why Job Center?</a></li>
	 <li><a href="#">Buy Job Postings</a></li>
	 <li><a href="#">Employer/Recruiter Login</a></li>
	 <li><a href="#">FAQ's</a></li>
	 </ul>
  </div>
  <div class="block1 fl">
  <h1 class="gtitle">Follow Us</h1>
  <a href="#"><img src="images/fb.png" alt="fb" /></a>&nbsp;&nbsp;<a href="#"><img src="images/twitter.png" alt="twitter" /></a>&nbsp;&nbsp;<a href="#"><img src="images/in.png" alt="linkedin" /></a>
  </div>
  <div class="cl"></div>
 </div>
</div>

<div id="footer" class="ac">� 2012 Job Center. All rights reserved.</div>
