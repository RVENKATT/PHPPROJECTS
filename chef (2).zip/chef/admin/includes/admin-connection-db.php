<?php

/***************************************************************

* Author      : Anand

* Description : This is a DBFactory deals with model operations 

* Date        : 21-09-2011

****************************************************************/

error_reporting(0);

  
mysql_connect("localhost","root","") or die(mysql_error());       mysql_select_db("chef"); 
//mysql_connect("localhost","mytestwe_chef","mytestwe_chef") or die(mysql_error());       mysql_select_db("mytestwe_chef");  



 

?>