<?php



/***************************************************************



* Author      : Anand



* Description : This is a DBFactory deals with model operations 



* Date        : 21-09-2011



****************************************************************/



include('admin-connection-db.php');







class menu_db{







   /* This function connects to the database server and selects the database it deals with. */











 function query($str)



   {   



        $result=mysql_query($str);



		while($row=mysql_fetch_array($result))



		$output[]=$row;



		return $output;



   }







  function equery($str)



   {   



        mysql_query($str);



		



   }







//User functions



    function footer_add($FOOTER_IMG_NAME)



    {



	//regiter.php



    $que="INSERT INTO footer_img(FOOTER_IMG_NAME) VALUES('$FOOTER_IMG_NAME')";



	$this->equery($que);

	 return mysql_insert_id();



	}



	











    function footer_details($FOOTER_ID )



    {



	//checkout.php



    $que="select * from footer where FOOTER_ID='$FOOTER_ID'";



	return $this->query($que);



	}

function footer_details1($FOOTER_ID )



    {



	//checkout.php



    $que="select * from footer where FOOTER_ID='$FOOTER_ID'";



	return $this->query($que);



	}

	



	 function footer_update($FOOTER_CONTENT,$FOOTER_IMG_ID )



    {



	//checkout.php



    $que="update footer set FOOTER_CONTENT='$FOOTER_CONTENT' where FOOTER_ID=$FOOTER_IMG_ID ";

$this->equery($que);



	}







  function footer()



    {



	//checkout.php



    $que="select * from footer ";



	return $this->query($que);



	}

 function footers()



    {



	//checkout.php



    $que="select * from footer_img ";



	return $this->query($que);



	}



	

	



	//bannner images add



	function admin_banner_img_add($BANNER_ORDER)



    {



	
    $que="INSERT INTO banner(BANNER_ORDER) VALUES('$BANNER_ORDER')";



	$this->equery($que);


	   return mysql_insert_id();


	}



function banner_update($BANNER_ORDER,$BANNER_IMG_ID)



{



  $str="update banner set BANNER_ORDER='$BANNER_ORDER' where BANNER_IMG_ID='$BANNER_IMG_ID' ";



   $this->equery($str);



}

function gallery_update($CONTENT,$DATE,$GALLERY_IMG_ID)



{



 $str="update gallery set CONTENT=$CONTENT,DATE='$DATE' where GALLERY_IMG_ID=$GALLERY_IMG_ID";



   $this->equery($str);



}











  function admin_banner()



    {



	//checkout.php



    $que="select * from banner ORDER BY BANNER_IMG_ID DESC";



	return $this->query($que);



	}	



	  function banner_img_details($BANNER_IMG_ID)



	{



	  $que="select * from  banner where BANNER_IMG_ID='$BANNER_IMG_ID'";



	 $res=$this->query($que);



     return $res;



    }
	
	function banner_delete($BANNER_IMG_ID)



   {



    $str="delete from banner where BANNER_IMG_ID=$BANNER_IMG_ID ";


   $this->equery($str);  



   }


function gallery_delete($GALLERY_IMG_ID)



   {



    $str="delete from gallery where GALLERY_IMG_ID=$GALLERY_IMG_ID ";


   $this->equery($str);  



   }



	






	



	//MENU



	



	



	  function menu_update($MENU_TITLE,$MENU_DES,$EXTERNAL_LINK,$MENU_ID,$MENU_ORDER,$STYLE)



{



  $str="update menu set MENU_TITLE='$MENU_TITLE',MENU_DES='$MENU_DES',EXTERNAL_LINK='$EXTERNAL_LINK',MENU_ORDER=$MENU_ORDER,STYLE=$STYLE  where MENU_ID=$MENU_ID";



   $this->equery($str);



}




function menu_internal_update($MI_TITLE,$MI_DSE,$MI_ID)



{



 echo $str="update menu_internal set MI_TITLE='$MI_TITLE',MI_DSE='$MI_DSE' where MI_ID=$MI_ID";



   $this->equery($str);



}




function getImageCount(){

	 $que="select max(IMG_ID) from images";



	$res=$this->query($que);

	 return $res;





}



function menu_add($MENU_TITLE,$MENU_PARENT,$MENU_ORDER,$EXTERNAL_LINK,$MENU_DES,$MENU_OR_NOT)



    {



	   $que="INSERT INTO menu(MENU_TITLE,MENU_PARENT,MENU_ORDER,EXTERNAL_LINK,MENU_DES,MENU_OR_NOT) VALUES('$MENU_TITLE','$MENU_PARENT','$MENU_ORDER','$EXTERNAL_LINK','$MENU_DES','$MENU_OR_NOT')";



	$this->equery($que);


 return mysql_insert_id();




	}
	
	function menu_add_internal($MI_TITLE,$MI_DSE,$MI_ALIGHN,$MENU_ID)



    {



	 echo  $que="INSERT INTO menu_internal(MI_TITLE,MI_DSE,MI_ALIGHN,MENU_ID) VALUES('$MI_TITLE','$MI_DSE','$MI_ALIGHN','$MENU_ID')";



	$this->equery($que);


 return mysql_insert_id();




	}


function online_add($ONLINE_TITLE,$ONLINE_DES)



    {



	 $que="INSERT INTO online(ONLINE_TITLE,ONLINE_DES) VALUES('$ONLINE_TITLE','$ONLINE_DES')";



	$this->equery($que);







	}



  function menu_detail($MENU_ID)



	{



    $que="select * from menu where MENU_ID='$MENU_ID'";



	 $res=$this->query($que);



     return $res;



    }
	
	
	function menu_internal_detail($MI_ID)



	{



    $que="select * from menu_internal where MI_ID='$MI_ID'";



	 $res=$this->query($que);



     return $res;



    }
	
	
	
	function menu_internals($id)



	{



    $que="select * from menu_internal where MENU_ID='$id'  ";



	 $res=$this->query($que);



     return $res;



    }

 function gallery_detail($GALLERY_IMG_ID)



	{



    $que="select * from gallery where GALLERY_IMG_ID='$GALLERY_IMG_ID'";



	 $res=$this->query($que);



     return $res;



    }

	function online_detail($ONLINE_ID)



	{



    $que="select * from online where ONLINE_ID='$ONLINE_ID'";



	 $res=$this->query($que);



     return $res;



    }



	



	 function menu()



   {



    $str="select * from menu ORDER BY MENU_ID DESC ";



   $result=$this->query($str);



   return $result;



   }



   function online()



   {



    $str="select * from online ORDER BY ONLINE_ID DESC ";



   $result=$this->query($str);



   return $result;



   }









   function menu_delete($MENU_ID)



	{



	  $que="delete from menu where MENU_ID='$MENU_ID'";



	  $this->equery($que); 



    }
	 function menu_internal_delete($MI_ID)



	{



	 echo $que="delete from menu_internal where MI_ID='$MI_ID'";



	  $this->equery($que); 



    }




function stories_delete($STORIES_ID)



	{



	  $que="delete from stories where STORIES_ID='$STORIES_ID'";



	  $this->equery($que); 



    }

function aboutus_delete($ABOUTUS_ID)



	{



	  $que="delete from aboutus where ABOUTUS_ID='$ABOUTUS_ID'";



	  $this->equery($que); 



    }



 function gallery_img_delete($GALLERY_IMG_ID)



	{



	  $que="delete from product_gallery where GALLERY_IMG_ID='$GALLERY_IMG_ID'";



	  $this->equery($que); 



    }



	   function menu_parent_detail($MENU_PARENT)



	{



	  $que="select * from menu where MENU_ID='$MENU_PARENT'";



	  $res=$this->query($que); 



	    return $res;



    }	



	



	 function menu_menu($MENU_PARENT)



	   {



		$str="select * from menu where MENU_PARENT=$MENU_PARENT";



	   $result=$this->query($str);



	   return $result;



	   }	





function products_img_add($MENU_ID,$IMG_NAME)



    {



	 $que="INSERT INTO images(MENU_ID,IMG_NAME) VALUES('$MENU_ID','$IMG_NAME')";



	$this->equery($que);



	$product_img_id=mysql_insert_id();



	return $product_img_id;







	}

function products_img_add_update($IMG_ID,$IMG_NAME)



    {



	$que="UPDATE  images SET IMG_NAME='$IMG_NAME' where IMG_ID=$IMG_ID";



	$this->query($que);

	}





function gallery_img_add($CONTENT)



    {



	 $que="INSERT INTO gallery(CONTENT,DATE) VALUES('$CONTENT',CURDATE())";



	$this->equery($que);



	return mysql_insert_id();



	







	}

	

	function product_img_add($IMG_NAME,$VIDEO_NAME,$EXTERNAL_LINK)



    {



	 $que="INSERT INTO product_gallery(PIC_NAME,VIDEO_NAME,EXTERNAL_LINK) VALUES('$IMG_NAME','$VIDEO_NAME','$EXTERNAL_LINK')";



	$this->equery($que);



	return mysql_insert_id();



	







	}

function gallery_img_add_update($IMG_ID,$IMG_NAME)



    {



	$que="UPDATE  gallery SET PIC_NAME='$IMG_NAME' where GALLERY_IMG_ID=$IMG_ID";



	$this->query($que);







	







	}



function product_img_add_update($IMG_ID,$IMG_NAME)



    {



	$que="UPDATE  product_gallery SET PIC_NAME='$IMG_NAME' where GALLERY_IMG_ID=$IMG_ID";



	$this->query($que);







	







	}

	

	function admin_gallery_img_add($IMG_NAME,$EXTERNAL_LINK,$IMG_ID)



    {



 $que="UPDATE  gallery SET VIDEO_NAME='$IMG_NAME',EXTERNAL_LINK='$EXTERNAL_LINK' where GALLERY_IMG_ID=$IMG_ID";



	$this->query($que);







	







	}



function admin_product_img_add($IMG_NAME,$EXTERNAL_LINK,$IMG_ID)



    {



 $que="UPDATE  product_gallery SET VIDEO_NAME='$IMG_NAME',EXTERNAL_LINK='$EXTERNAL_LINK' where GALLERY_IMG_ID=$IMG_ID";



	$this->query($que);







	







	}

	

	   function gallery_img_details($GALLERY_IMG_ID)



	{



	  $str="select * from gallery where GALLERY_IMG_ID='$GALLERY_IMG_ID' ";



	   $result=$this->query($str);



	   return $result;


    }	







	 



	//MENU



	function img_details($MENU_ID)



	   {



		 $str="select * from images where PRODUCT_ID=$MENU_ID ";



	   $result=$this->query($str);



	   return $result;



	   }





   	  	 function product_img_delete_detail($IMG_ID)



   {



    $str="select * from images where IMG_ID=$IMG_ID ";



   $result=$this->query($str);



   return $result;



   }



   	  	  	 function product_img_delete_edit($IMG_ID)



   {



    $str="delete  from images where IMG_ID=$IMG_ID ";



   $result=$this->query($str);



   return $result;



   }

   

   

   

   // footer

   

   

   function footer1_details($MENU_ID)



	   {



		 $str="select * from footer1 where MENU_ID=$MENU_ID ";



	   $result=$this->query($str);



	   return $result;



	   }





   	  	

   

   

	  function footer1_update($FOOTER_NAME,$FOOTER_DES,$FOOTER_ID)



{



  $str="update footer set FOOTER_NAME='$FOOTER_NAME',FOOTER_DES='$FOOTER_DES' where FOOTER_ID=$FOOTER_ID";



   $this->equery($str);



}



function footer1_add($FOOTER_NAME,$FOOTER_DES)



    {



	 $que="INSERT INTO footer(FOOTER_NAME,FOOTER_DES) VALUES('$FOOTER_NAME','$FOOTER_DES')";



	$this->equery($que);



return mysql_insert_id();



	}



  function footer1_detail($FOOTER_ID)



	{



    $que="select * from footer where FOOTER_ID='$FOOTER_ID'";



	 $res=$this->query($que);



     return $res;



    }



	



	 function footer1()



   {



    $str="select * from footer ORDER BY FOOTER_ID DESC ";



   $result=$this->query($str);



   return $result;



   }



   







   function footer1_delete($FOOTER_ID)



	{



	  $que="delete from footer where FOOTER_ID='$FOOTER_ID'";



	  $this->equery($que); 



    }



	   function footer1_parent_detail($MENU_PARENT)



	{



	  $que="select * from footer1 where MENU_ID='$MENU_PARENT'";



	  $res=$this->query($que); 



	    return $res;



    }	



	



	 function footer1_menu($MENU_PARENT)



	   {



		$str="select * from footer1 where MENU_PARENT=$MENU_PARENT";



	   $result=$this->query($str);



	   return $result;



	   }	





// gallery



 function gallery()



	   {



		$str="select * from gallery";



	   $result=$this->query($str);



	   return $result;



	   }	



function product_gallery()



	   {



		$str="select * from product_gallery";



	   $result=$this->query($str);



	   return $result;



	   }	





function product_add($PRODUCT_TITLE,$PRODUCT_DES)



	   {



 $que="INSERT INTO product(PRODUCT_TITLE,PRODUCT_DES) VALUES('$PRODUCT_TITLE','$PRODUCT_DES')";



	$this->equery($que);

	

	return mysql_insert_id();







	}

	function product_update($PRODUCT_TITLE,$PRODUCT_DES,$PRODUCT_ID)



    {



  $que="UPDATE  product SET PRODUCT_TITLE='$PRODUCT_TITLE',PRODUCT_DES='$PRODUCT_DES' where PRODUCT_ID=$PRODUCT_ID";



	$this->query($que);



	}

	

	
function popular_add($POPULAR_TITLE,$POPULAR_DES)



	   {



 $que="INSERT INTO popular(POPULAR_TITLE,POPULAR_DES) VALUES('$POPULAR_TITLE','$POPULAR_DES')";



	$this->equery($que);

	

	return mysql_insert_id();







	}

	function popular_update($POPULAR_TITLE,$POPULAR_DES,$POPULAR_ID)



    {



  $que="UPDATE  popular SET POPULAR_TITLE='$POPULAR_TITLE',POPULAR_DES='$POPULAR_DES' where POPULAR_ID=$POPULAR_ID";



	$this->query($que);



	}


	

	function products1()



	   {



		 $str="select * from product";



	   $result=$this->query($str);



	   return $result;



	   }	
	   
	   function popular()



	   {



		 $str="select * from popular";



	   $result=$this->query($str);



	   return $result;



	   }	

	function stories_details($STORIES_ID)



	   {



		 $str="select * from stories where STORIES_ID=$STORIES_ID ";



	   $result=$this->query($str);



	   return $result;



	   }



function aboutus_add($ABOUTUS_TITLE,$ABOUTUS_DES)



	   {



		$que="INSERT INTO aboutus(ABOUTUS_TITLE,ABOUTUS_DES) VALUES('$ABOUTUS_TITLE','$ABOUTUS_DES')";



	$this->equery($que);







	}

	function aboutus_update($ABOUTUS_TITLE,$ABOUTUS_DES,$ABOUTUS_ID)



    {



 $que="UPDATE  aboutus SET ABOUTUS_TITLE='$ABOUTUS_TITLE',ABOUTUS_DES='$ABOUTUS_DES' where ABOUTUS_ID=$ABOUTUS_ID";



	$this->query($que);




	}

	

	

	

	function aboutus()



	   {



		$str="select * from aboutus";



	   $result=$this->query($str);



	   return $result;



	   }	

	function aboutus_details($ABOUTUS_ID)



	   {



		 $str="select * from aboutus where ABOUTUS_ID=$ABOUTUS_ID ";



	   $result=$this->query($str);



	   return $result;



	   }

	    function product_delete($PRODUCT_ID)



   {



    $str="delete from product where PRODUCT_ID=$PRODUCT_ID ";


   $this->equery($str);




   }
   
   
   

	  	

 function footer_delete($FOOTER_ID)



   {



    $str="delete from footer where FOOTER_ID=$FOOTER_ID ";



	



   $this->equery($str);



    



   }



	  	

 function footer_img_delete($FOOTER_IMG_ID)



   {



    $str="delete from footer_img where FOOTER_IMG_ID=$FOOTER_IMG_ID ";



	



   $this->equery($str);



    



   }



function footer_img_details($FOOTER_IMG_ID)



	   {



		 $str="select * from footer_img where FOOTER_IMG_ID=$FOOTER_IMG_ID ";



	   $result=$this->query($str);



	   return $result;



	   }
	   
	   
	   function menu_internal($IMG_NAME,$DAYS,$COST,$PRODUCT_ID)
	       {
	
    $que="INSERT INTO images(IMG_NAME,DAYS,COST,PRODUCT_ID) VALUES('$IMG_NAME','$DAYS','$COST','$PRODUCT_ID')";
	
	$this->equery($que);
	
	   return mysql_insert_id();


	}



 function menu_internals_details($PRODUCT_ID)



	   {



		 $str="select * from images where PRODUCT_ID=$PRODUCT_ID ";



	   $result=$this->query($str);



	   return $result;



	   }


  function internal_delete($IMG_ID)
   {

    $str="delete from images where PIC_ID=$IMG_ID ";



   $this->equery($str);  



   }
   
    function products_internal($PIC_ID)



	   {



		 $str="select * from images where PIC_ID=$PIC_ID ";



	   $result=$this->query($str);



	   return $result;



	   }
	    function internal_update($IMG_NAME,$DAYS,$COST,$PIC_ID)



    {



echo $que="UPDATE  images SET IMG_NAME='$IMG_NAME',DAYS='$DAYS',COST='$COST' where PIC_ID=$PIC_ID";



	$this->query($que);




	}




}







 



?>