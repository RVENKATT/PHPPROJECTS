<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
  <div class="navbar-header">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
    <a class="navbar-brand" href="users.php"></a> </div>
  <div class="collapse navbar-collapse navbar-ex1-collapse">
    <ul id="active" class="nav navbar-nav side-nav">
      
      <li><a href="admin-users.php"><i class="fa fa-tasks"></i> Users </a></li>
     <li ><a href="admin-aboutus.php"><i class="fa fa-tasks"></i> About us </a></li>
      <li><a href="admin-popular.php"><i class="fa fa-tasks"></i> Popular </a></li>
   <li><a href="admin-banner.php"><i class="fa fa-tasks"></i> Banner </a></li>
    <li ><a href="admin-menu.php"><i class="fa fa-tasks"></i> menu </a></li>  
      <li ><a href="admin-product_content.php"><i class="fa fa-tasks"></i> Content </a></li>
      <li ><a href="admin-gallery.php"><i class="fa fa-tasks"></i> Picture Gallery </a></li>
      <li><a href="admin-footer.php"><i class="fa fa-tasks"></i> Footer </a></li>
      <li><a href="admin-logout.php"><i class="fa fa-tasks"></i> Logout</a></li>
      </li>
    </ul>
  </div>
</nav>
