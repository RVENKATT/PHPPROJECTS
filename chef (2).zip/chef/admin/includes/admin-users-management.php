<?php
/***************************************************************
* Author      : Anand
* Description : This is a DBFactory deals with model operations 
* Date        : 21-09-2011
****************************************************************/
include('admin-connection-db.php');

class UsersManagement{

   /* This function connects to the database server and selects the database it deals with. */

  function query($str)
   {   
        $result=mysql_query($str);
		while($row=mysql_fetch_array($result))
		$output[]=$row;
		return $output;
   }

function offers_admin($s)

   {

   $str="select * from adminuser where username ='$s'";

   $result=$this->query($str);

   return $result;

   }
   function equery($str)
   {   
        mysql_query($str);
   }
 
   function count_query($str)
   {
   		$result=mysql_query($str);
		$row=mysql_num_rows($result);
		return $row;
   }
   function registeruser_check($name,$password)
	 {

     $str="select * from adminuser where ADMIN_NAME='$name' and PASSWORD='$password'";
     $result=$this->query($str);
     return $result;
	 } 
	    function registeruser_check1($name,$password)
	 {
	 "select * from adminuser where admin='$name' and password='$password'";
     $str="select * from adminuser where ADMIN_NAME='$name' and PASSWORD='$password'";
     $result=$this->query($str);
     return $result;
	 } 
	     function registeruser_forget($ADMIN_EMAIL)
	 {
	
     $str="select * from adminuser where ADMIN_EMAIL='$ADMIN_EMAIL' ";
     $result=$this->query($str);
     return $result;
	 }
	      function registeruser_reset($PASSWORD,$ADMIN_ID)
	 {
	
     $str="update  adminuser set PASSWORD='$PASSWORD' where ADMIN_ID=$ADMIN_ID ";
     $result=$this->query($str);
     return $result;
	 }
	 
	 
	 //USERS
function user_update($FIELD1,$FIELD2,$FIELD4,$POST_ID)
{
echo  $str="update users set USER_NAME='$FIELD1',USER_EMAIL='$FIELD2',USER_MOBILE='$FIELD4' where USER_ID=$POST_ID";
   $this->equery($str);
}
function user_add($FIELD1,$FIELD2,$FIELD3,$FIELD4,$FIELD5)
    {
echo	 $que="INSERT INTO users(USERNAME,EMAIL,PASSWORD,PHONE,USER_TYPE) VALUES('$FIELD1','$FIELD2','$FIELD3','$FIELD4','$FIELD5')";
	$this->equery($que);

	}
  function user_detail($s)
	{
    $que="select * from users where USER_ID='$s'";
	 $res=$this->query($que);
     return $res;
    }
	
	 function userss()
   {
    $str="select * from users ORDER BY USER_ID DESC ";
   $result=$this->query($str);
   return $result;
   }
   	 function vendors()
   {
    $str="select * from user  where USER_TYPE=1 ORDER BY USER_ID DESC ";
   $result=$this->query($str);
   return $result;
   }
   function user_delete($s1)
	{
	  $que="delete from users where USER_ID='$s1'";
	  $this->equery($que); 
    }	
	function img_add($FIELD1,$FIELD2)
    {
	 $que="INSERT INTO images(post_id,img_name) VALUES('$FIELD1','$FIELD2')";
	$this->equery($que);
	}
	
//USERS

//STATUS

 	    	  	     function user_status_update1($USER_ID)
	  {
	   $str="update user set USER_STATUS='1' where USER_ID=$USER_ID";
       $this->query($str);
       
      }
	    	    	  	     function user_status_update2($USER_ID)
	  {
	   $str="update user set USER_STATUS='0' where USER_ID=$USER_ID";
       $this->query($str);
       
      }
//STATUS
	 
	
	
}

 
?>