<?php

session_start();

ob_start();
error_reporting(0);

?>






<?php

if($_REQUEST[MENU_ID]!="")

{

include('../includes/admin-menu-db.php');

$dbFactory= new menu_db();

?>

 <div class="modal-dialog">

    <div class="modal-content">

      <div class="modal-header">

        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>

        <h4 class="modal-title" id="myModalLabel">Edit</h4>

      </div>

      <div class="modal-body">

  <form   class="cmxform1" id="kiran" method="post" enctype="multipart/form-data"> 

  <div class="container-fluid">

  <div class="row">

   <?php 



    $d=$dbFactory->menu_detail($_REQUEST['MENU_ID']);	?>
    
       <div  class="col-sm-4 pad">MENU_TITLE:</div>

     
     
	
     <div class="col-sm-8 pad"> <input type="text" name="MENU_TITLE" value="<?php echo $d[0][MENU_TITLE];?>"/> </div>
     
     <div  class="col-sm-4 pad">MENU DES:</div>
     
     <div class="col-sm-8 pad"> <textarea  name="MENU_DES"><?php echo $d[0][MENU_DES];?></textarea> </div>
     
     <div  class="col-sm-4 pad">EXTERNAL LINK</div>
     <div class="col-sm-8 pad"> <input type="text"  name="EXTERNAL_LINK" value="<?php echo $d[0][EXTERNAL_LINK];?>"> </div>
     
     
	<div  class="col-sm-4 pad">GALLERY</div>	
     <div class="col-sm-8 pad"> <input type="file" name="files[]" multiple  id="file" /> 

     <input  type="hidden" name="MENU_ID" value="<?php echo $d[0][MENU_ID];?>"  /></div>

     <div  class="col-sm-4 pad">ORDER</div>
     <div class="col-sm-8 pad"> <input type="text"  name="MENU ORDER" value="<?php echo $d[0][MENU_ORDER];?>"> </div>
     <div  class="col-sm-4 pad">STYLE</div>
     <div class="col-sm-8 pad"> <input type="text"  name="STYLE" value="<?php echo $d[0][STYLE];?>"> </div>
     

   

       <div  class="col-sm-12 pad">  <input type="submit" class="btn btn-primary pull-right" name="update" value="Update" /></div></div></div>
       </form>

      </div>      

      

    </div>
   

  </div>
 


<?php }?>




<?php

if($_REQUEST[MI_ID]!="")

{

include('../includes/admin-menu-db.php');

$dbFactory= new menu_db();

?>

 <div class="modal-dialog">

    <div class="modal-content">

      <div class="modal-header">

        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>

        <h4 class="modal-title" id="myModalLabel">Edit</h4>

      </div>

      <div class="modal-body">

  <form   class="cmxform1" id="kiran" method="post" enctype="multipart/form-data"> 

  <div class="container-fluid">

  <div class="row">

   <?php 



    $d=$dbFactory->menu_internal_detail($_REQUEST['MI_ID']);	?>
    
       <div  class="col-sm-4 pad">MI_TITLE:</div>

     
     
	
     <div class="col-sm-8 pad"> <input type="text" name="MI_TITLE" value="<?php echo $d[0][MI_TITLE];?>"/> </div>
     
     <div  class="col-sm-4 pad">MENU DES:</div>
     
     <div class="col-sm-8 pad"> <textarea  name="MI_DSE"><?php echo $d[0][MI_DSE];?></textarea> </div>
     
    
     
     
	<div  class="col-sm-4 pad">IMAGE</div>	
     <div class="col-sm-8 pad"> <input type="file" name="files[]" multiple  id="file" /> 

     <input  type="hidden" name="MI_ID" value="<?php echo $d[0][MI_ID];?>"  /></div>

    
     

   

       <div  class="col-sm-12 pad">  <input type="submit" class="btn btn-primary pull-right" name="update" value="Update" /></div></div></div>
       </form>

      </div>      

      

    </div>
   

  </div>
 


<?php }?>






<?php //PRODUCT EDIT START?>

<?php 

if($_REQUEST[PRODUCT_ID]!="")

{

include('../includes/admin-products-management.php');

$dbFactory= new ProductsManagement();


?>



 <div class="modal-dialog" >

    <div class="modal-content">

      <div class="modal-header">

        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>

        <h4 class="modal-title" id="myModalLabel">Edit</h4>

      </div>

      <div class="modal-body">

  <form   class="editform" id="kiran" method="post" enctype="multipart/form-data"> 

  <div class="container-fluid">

  <div class="row">

  	<?php

$product_info=$dbFactory->products_detail($_REQUEST[PRODUCT_ID]);?>

   <div  class="col-sm-4 pad"> PRODUCT TITLE:</div><div class="col-sm-8 pad"> <input  type="text" name="PRODUCT_TITLE" value="<?php echo $product_info[0][PRODUCT_TITLE];?>" /></div>

     <div  class="col-sm-4 pad"> DESCRIPTION:</div><div class="col-sm-8 pad"><textarea  name="PRODUCT_DES" ><?php echo $product_info[0][PRODUCT_DES];?></textarea></div>

 
     
			<div  class="col-sm-4 pad"><img src="../admin/product/<?php $product_info[0][PRODUCT_ID];?>"  width="30" height="30"/></div>


             <div  class="col-sm-4 pad">UPLOAD IMAGES:</div><div class="col-sm-8 pad"> 
             <input type="file" name="files[]"  id="file" multiple /> 
<input type="hidden"  name="PRODUCT_ID" value="<?php echo $product_info[0][PRODUCT_ID]; ?>" /></div>
       <div  class="col-sm-12 pad"> 
         <input type="submit" class="btn btn-primary pull-right" name="update" value="UPDATE" /></div></div></div></form>

      </div>

    

      

     

    </div>

  </div>

<?php }?>


<?php 

if($_REQUEST[PRODUCT_ID]!="")

{

include('../includes/admin-products-management.php');

$dbFactory= new ProductsManagement();


?>



 <div class="modal-dialog" >

    <div class="modal-content">

      <div class="modal-header">

        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>

        <h4 class="modal-title" id="myModalLabel">Edit</h4>

      </div>

      <div class="modal-body">

  <form   class="editform" id="kiran" method="post" enctype="multipart/form-data"> 

  <div class="container-fluid">

  <div class="row">

  	<?php

$product_info=$dbFactory->products_detail($_REQUEST[PRODUCT_ID]);?>

   <div  class="col-sm-4 pad"> PRODUCT TITLE:</div><div class="col-sm-8 pad"> <input  type="text" name="PRODUCT_TITLE" value="<?php echo $product_info[0][PRODUCT_TITLE];?>" /></div>

     <div  class="col-sm-4 pad"> DESCRIPTION:</div><div class="col-sm-8 pad"><textarea  name="PRODUCT_DES" ><?php echo $product_info[0][PRODUCT_DES];?></textarea></div>

 
     
			<div  class="col-sm-4 pad"><img src="../admin/product/<?php $product_info[0][PRODUCT_ID];?>"  width="30" height="30"/></div>


             <div  class="col-sm-4 pad">UPLOAD IMAGES:</div><div class="col-sm-8 pad"> 
             <input type="file" name="files[]"  id="file" multiple /> 
<input type="hidden"  name="PRODUCT_ID" value="<?php echo $product_info[0][PRODUCT_ID]; ?>" /></div>
       <div  class="col-sm-12 pad"> 
         <input type="submit" class="btn btn-primary pull-right" name="update" value="UPDATE" /></div></div></div></form>

      </div>

    

      

     

    </div>

  </div>

<?php }?>



<?php //PRODUCT EDIT END?>
<?php //PRODUCT-INTERNAL EDIT END?>

<?php 

if($_REQUEST[PIC_ID]!="")

{

include('../includes/admin-menu-db.php');

$dbFactory= new menu_db();


?>



 <div class="modal-dialog" >

    <div class="modal-content">

      <div class="modal-header">

        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>

        <h4 class="modal-title" id="myModalLabel">Edit</h4>

      </div>

      <div class="modal-body">

  <form   class="editform" id="kiran" method="post" enctype="multipart/form-data"> 

  <div class="container-fluid">

  <div class="row">

  	<?php

$d=$dbFactory->products_internal($_REQUEST[PIC_ID]);?>

   <div  class="col-sm-4 pad"> PRODUCT TITLE:</div><div class="col-sm-8 pad"> <input  type="text" name="IMG_NAME" value="<?php echo $d[0][IMG_NAME];?>" /></div>

    

 
     
			<div  class="col-sm-4 pad"><img src="images/<?php echo $d[0][PIC_ID];?>.jpg" width="60" height="60"></div>


             <div  class="col-sm-4 pad">UPLOAD IMAGES:</div><div class="col-sm-8 pad"> 
             <input type="file" name="file"  id="file" multiple /> 
<input type="hidden"  name="PIC_ID" value="<?php echo $d[0][PIC_ID]; ?>" /></div>
       <div  class="col-sm-12 pad"> 
         <input type="submit" class="btn btn-primary pull-right" name="update" value="UPDATE" /></div></div></div></form>

      </div>

    

      

     

    </div>

  </div>

<?php }?>



<?php // PRODUCT IMAGE DELETE START ?>





<?php 

if($_REQUEST[IMG_ID]!="")

{

	

include('../includes/admin-menu-db.php');

$dbFactory= new menu_db();



$ss=$dbFactory->product_img_delete_detail($_REQUEST[IMG_ID]);

	//echo "../product_images/".$ss[0][IMG_NAME];

	  @unlink("../product/".$ss[0][IMG_NAME]);
	    @unlink("../product/temp/".$ss[0][IMG_NAME]);

$s=$dbFactory->product_img_delete_edit($_REQUEST[IMG_ID]);





?>



<div  class="col-sm-12 pad" ><?php  $f=$dbFactory->img_details($_REQUEST[PRODUCT_ID]);

    for($i=0;$i<count($f);$i++) {?> <img  src="product/<?php echo $f[$i][IMG_NAME];?>" onClick="product_img(<?php echo $_REQUEST[PRODUCT_ID];?>,<?php echo $f[$i][IMG_ID];?>)" height="50" width="50"/>&nbsp;&nbsp;<?php }?>

</div>

	<?php }?>



<?php // PRODUCT IMAGE DELETE START ?>

<?php //ABOUTUS EDIT START?>

<?php 

if($_REQUEST[ABOUTUS_ID]!="")

{

include('../includes/admin-products-management.php');

$dbFactory= new ProductsManagement();

?>



 <div class="modal-dialog" >

    <div class="modal-content">

      <div class="modal-header">

        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>

        <h4 class="modal-title" id="myModalLabel">Edit</h4>

      </div>

      <div class="modal-body">

  <form   class="editform" id="kiran" method="post" enctype="multipart/form-data"> 

  <div class="container-fluid">

  <div class="row">

  	<?php

$product_info=$dbFactory->aboutus_detail($_REQUEST[ABOUTUS_ID]);?>

   <div  class="col-sm-4 pad">  ABOUT US TITLE:</div><div class="col-sm-8 pad"> <input  type="text" name="ABOUTUS_TITLE" value="<?php echo $product_info[0][ABOUTUS_TITLE];?>" /></div>

     <div  class="col-sm-4 pad"> DESCRIPTION:</div><div class="col-sm-8 pad"><textarea  name="ABOUTUS_DES" ><?php echo $product_info[0][ABOUTUS_DES];?></textarea></div>

     

     

       <div  class="col-sm-12 pad"> <input type="hidden"  name="ABOUTUS_ID" value="<?php echo $_REQUEST[ABOUTUS_ID]; ?>" />  <input type="submit" class="btn btn-primary pull-right" name="update" value="UPDATE" /></div></div></div></form>

      </div>

    

      

     

    </div>

  </div>

<?php }?>



<?php //ABOUTUS EDIT END?>










<?php //DELEVERY EDIT START?>

<?php 

if($_REQUEST[DELEVERY_ID]!="")

{

include('../includes/admin-products-management.php');

$dbFactory= new ProductsManagement();

?>

 <div class="modal-dialog">

    <div class="modal-content">

      <div class="modal-header">

        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>

        <h4 class="modal-title" id="myModalLabel">Edit</h4>

      </div>

      <div class="modal-body">

  <form   class="editform" id="kiran" method="post"> 

  <div class="container-fluid">

  <div class="row">

   <div  class="col-sm-4 pad">



    DELEVERY STATUS: </div><div class="col-sm-8 pad"><input  type="text" name="DELIVARY_STATUS"  /></div>

          



  



   

    

     <input  type="hidden" name="TRANSACTION_ID" value="<?php echo $_REQUEST[DELEVERY_ID];?>"  />

       <div  class="col-sm-12 pad">  <input type="submit" class="btn btn-primary pull-right" name="update" value="Update" /></div></div></div></form>

      </div>

    

      

     

    </div>

  </div>

<?php }?>



<?php //DELEVERY EDIT END?>





<?php //BANNER EDIT START?>

<?php

if($_REQUEST[BANNER_IMG_ID]!="")

{

include('../includes/admin-menu-db.php');

$dbFactory= new menu_db();

?>

 <div class="modal-dialog">

    <div class="modal-content">

      <div class="modal-header">

        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>

        <h4 class="modal-title" id="myModalLabel">Edit</h4>

      </div>

      <div class="modal-body">

  <form   class="cmxform1" id="kiran" method="post" enctype="multipart/form-data"> 

  <div class="container-fluid">

  <div class="row">

   <?php 



    $d=$dbFactory->banner_img_details($_REQUEST['BANNER_IMG_ID']);	?>
    
       <div  class="col-sm-4 pad">ORDER:</div>

     
     
	
     <div class="col-sm-8 pad"> <input type="text" name="BANNER_ORDER" value="<?php echo $d[0][BANNER_ORDER];?>"/> </div>
     
     
     <div class="col-sm-8 pad"> <img src="banner_images/<?php echo $d[0][BANNER_IMG_ID];?>.png" width="30" height="30"/></div>
     
		
     <div class="col-sm-8 pad"> <input type="file" name="file"  id="file" /> 

     <input  type="hidden" name="BANNER_IMG_ID" value="<?php echo $d[0][BANNER_IMG_ID];?>"  /></div>

     

   

       <div  class="col-sm-12 pad">  <input type="submit" class="btn btn-primary pull-right" name="update" value="Update" /></div></div></div>
       </form>

      </div>
   

    

      

      

    </div>
   

  </div>
 


<?php }?>





<?php //BANNER EDIT END?>











<?php //GALLERY EDIT START?>

<?php

if($_REQUEST[GALLERY_IMG_ID]!="")

{

include('../includes/admin-menu-db.php');

$dbFactory= new menu_db();


?>

 <div class="modal-dialog">

    <div class="modal-content">

      <div class="modal-header">

        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>

        <h4 class="modal-title" id="myModalLabel">hereEdit</h4>

      </div>

      <div class="modal-body">

  <form   class="cmxform1" id="kiran" method="post"> 

  <div class="container-fluid">
  
<?php     $s=$dbFactory->gallery_img_details($_REQUEST[GALLERY_IMG_ID]);	   ?>
  <div class="row">

   
    
   
     
    <div  class="col-sm-5 pad">DATE</div>

     <div class="col-sm-7 pad"> <input type="text" name="DATE" id="datepicker" value="<?php echo $s[0][DATE];?>"/> </div>
     
     <div  class="col-sm-5 pad">CONTENT</div>

     <div class="col-sm-7 pad"> <textarea name="CONTENT" value=""><?php echo $s[0][CONTENT];?></textarea></div>
    

     <input  type="hidden" name="GALLERY_IMG_ID" value="<?php echo $s[0][GALLERY_IMG_ID];?>"  />

     

   

       <div  class="col-sm-12 pad">  <input type="submit" class="btn btn-primary pull-right" name="update" value="Update" /></div></div></div></form>

      </div>

    

      

      

    </div>

  </div>



<?php }?>





<?php //GALLERY EDIT END?>



<?php //FOOTER EDIT START?>

<?php

if($_REQUEST[FOOTER_ID]!="")

{

include('../includes/admin-menu-db.php');

$dbFactory= new menu_db();

?>

 <div class="modal-dialog">

    <div class="modal-content">

      <div class="modal-header">

        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>

        <h4 class="modal-title" id="myModalLabel">Edit</h4>

      </div>

      <div class="modal-body">

  <form   class="cmxform1" id="kiran" method="post"> 

  <div class="container-fluid">

  <div class="row">

   <?php 



    $d=$dbFactory->footer_details($_REQUEST[FOOTER_ID]);?>
    
		

     <div  class="col-sm-5 pad">DESCRIPTION:</div>
     

     <div class="col-sm-7 pad"> <textarea  name="FOOTER_CONTENT" ><?php echo stripslashes($d[0][FOOTER_CONTENT]);?></textarea>

     

     
 

     <input  type="hidden" name="FOOTER_ID" value="<?php echo $d[0][FOOTER_ID];?>"  /></div>

     

   

       <div  class="col-sm-12 pad">  <input type="submit" class="btn btn-primary pull-right" name="update" value="Update" />
       </div></div></div>
       </form>

      </div>

    

      

      

    </div>

  </div>



<?php }?>





<?php //FOOTER EDIT END?>



<?php //FOOTER_img EDIT START?>

<?php

if($_REQUEST[FOOTER_IMG_ID]!="")

{

include('../includes/admin-menu-db.php');

$dbFactory= new menu_db();

?>

 <div class="modal-dialog">

    <div class="modal-content">

      <div class="modal-header">

        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>

        <h4 class="modal-title" id="myModalLabel">Edit</h4>

      </div>

      <div class="modal-body">

  <form   class="cmxform1" id="kiran" method="post"> 

  <div class="container-fluid">

  <div class="row">

   <?php 



    $d=$dbFactory->footer_img_details($_REQUEST[FOOTER_IMG_ID]);?>

         <div  class="col-sm-5 pad">FOOTER NAME:</div>

     <div class="col-sm-7 pad"> <input type="text" name="FOOTER_IMG_NAME" value="<?php echo $d[0][FOOTER_IMG_NAME];?>"  /></div>

     

     

     

     <div  class="col-sm-5 pad">UPLOAD IMAGE:</div>

     <div class="col-sm-7 pad"> <input type="file" name="file"  id="file" /></div>

 

     <input  type="hidden" name="FOOTER_IMG_ID" value="<?php echo $d[0][FOOTER_IMG_ID];?>"  /></div>

     

   

       <div  class="col-sm-12 pad">  <input type="submit" class="btn btn-primary pull-right" name="update" value="Update" /></div></div></form>

      </div>

    

      

      

    </div>

  </div>



<?php }?>





<?php //FOOTER_img EDIT END?>


<?php //USER EDIT START?>
<?php
if($_REQUEST[USER_ID]!="")
{
include('../includes/admin-users-management.php');
$dbFactory= new UsersManagement();
?>
 <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel">Edit</h4>
      </div>
      <div class="modal-body">
  <form   class="cmxform1" id="kiran" method="post"> 
  <div class="container-fluid">
  <div class="row">
   <div  class="col-sm-3 pad">
     <?php 
    $d=$dbFactory->user_detail($_REQUEST[USER_ID]);?>
    User Name: </div><div class="col-sm-9 pad"><input  type="text" name="USERNAME" value="<?php echo $d[0][USER_NAME];?>"  /></div>
         <div  class="col-sm-3 pad"> Email:</div> <div  class="col-sm-9 pad"> <input  type="text" name="EMAIL" value="<?php echo $d[0][USER_EMAIL];?>"  /> </div>
     
  

   
   
     
     <div  class="col-sm-3 pad">  Phone: </div><div  class="col-sm-9 pad"> <input  type="text" name="PHONE" value="<?php echo $d[0][USER_MOBILE];?>"  /> 
     <input  type="hidden" name="USER_ID" value="<?php echo $d[0][USER_ID];?>"  /></div>
       <div  class="col-sm-12 pad">  <input type="submit" class="btn btn-primary pull-right" name="update" value="Update" /></div></div></div></form>
      </div>
    
      
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>

      </div>
    </div>
  </div>

<?php }?>


<?php //USER EDIT END?>











