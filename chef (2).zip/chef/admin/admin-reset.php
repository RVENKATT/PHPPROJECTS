<?php
session_start();
ob_start();
//error_reporting(0);
include('includes/admin-users-management.php');
$dbFactory= new UsersManagement();
if(isset($_POST[reset]))
{
	

$check=$dbFactory->registeruser_reset($_POST['ADMIN_PASSWORD'],$_POST['ADMIN_ID']);

   

 header("location:admin-reset.php?mes=1");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Dark Admin</title>

    <link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.min.css" />
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
    <link rel="stylesheet" type="text/css" href="css/style.css" />
		<link href="http://cdn.datatables.net/plug-ins/725b2a2115b/integration/bootstrap/3/dataTables.bootstrap.css" rel="stylesheet">

<script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.js"></script>
	<script src="js/scripts.js"></script>

	<script src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js"></script>
<script src="http://cdn.datatables.net/plug-ins/725b2a2115b/integration/bootstrap/3/dataTables.bootstrap.js"></script>
    <script type="text/javascript">
	function  pop_function(CATEGORY)
	{
	//menu loading
$.post("ajax/popup.php?prasad="+CATEGORY,function(data){

document.getElementById('myModal1').innerHTML=data;

});
	}
	</script>
     <script type="text/javascript">
function delid(id)
{
	
i=confirm("Are you sure to delete the user");
if(i)
window.location="index.php?did="+id;
}

</script>
<script src="jquery.js"></script>
	<script src="jquery.validate.js"></script>
	<script>
	

	$().ready(function() {
		// validate the comment form when it is submitted
		

		// validate signup form on keyup and submit
		$("#commentForm").validate({
			rules: {
			
				
				admin: {
					required: true,
					
					
				},
				password: {
					required: true,
					
				},
	

			
		
				
			},
			messages: {

					admin: {
					required: "please enter adminusername",
					
					
				},
			
			
				password: {
					required: "Please provide a password",
				
				},

				
			
			}
		});

		// propose username by combining first- and lastname
		$("#username").focus(function() {
			var firstname = $("#firstname").val();
			var lastname = $("#lastname").val();
			if (firstname && lastname && !this.value) {
				this.value = firstname + "." + lastname;
			}
		});

		//code to hide topic selection, disable for demo
		var newsletter = $("#newsletter");
		// newsletter topics are optional, hide at first
		var inital = newsletter.is(":checked");
		var topics = $("#newsletter_topics")[inital ? "removeClass" : "addClass"]("gray");
		var topicInputs = topics.find("input").attr("disabled", !inital);
		// show when newsletter is checked
		newsletter.click(function() {
			topics[this.checked ? "removeClass" : "addClass"]("gray");
			topicInputs.attr("disabled", !this.checked);
		});
	});
	</script>
    
<style type="text/css">
.gap{ margin-top:1em;}


</style>
 
</head>
<body >

<div  class="container">
         
<div class="row" style=" margin-top:50px">
        <div   class="col-md-4 col-md-offset-4" style="background:white">
		
		<legend class="topgap">RESET PASSWORD</legend>


<!-- Modal -->

 <form class="cmxform" id="commentForm"  method="post"> 
  <div class="container-fluid">
  <div class="row">
 <?php if($_GET[mes]==1) {?><p style="color:green; font-size:18px"> Reset Password Success</p><?php } ?>
         
         
         <div  class="col-sm-5 pad"> Enter New Password:</div> <div  class="col-sm-7 pad"> <input  type="password" class="form-control"  name="ADMIN_PASSWORD" />
         <input  type="hidden" class="form-control"  name="ADMIN_ID"  value="<?php echo $_REQUEST[id];?>"/> </div>
  
  

   
   
     

       <div  class="col-sm-6 pad">  <input type="submit" class="btn btn-primary " name="reset" value="submit" /></div> 
          <div  class="col-sm-6 pad"><p><a href="index.php">Login</a></p></div>
     </div></div></form>
		
		
		
		</div></div>

    </div>
    
    

    <!-- /#wrapper -->
    
</body>
</html>
