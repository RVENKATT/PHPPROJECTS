$(document).ready(function() {
  $('[data-toggle=offcanvas]').click(function() {
    $('.row-offcanvas').toggleClass('active');
  });
});



function visible_lg(){ return (jQuery("#visible-lg").css("display") === "block") ? true : false; }
			function visible_md(){ return (jQuery("#visible-md").css("display") === "block") ? true : false; }
			function visible_sm(){ return (jQuery("#visible-sm").css("display") === "block") ? true : false; }
			function visible_xs(){ return (jQuery("#visible-xs").css("display") === "block") ? true : false; }
			
			// http://remysharp.com/2010/07/21/throttling-function-calls/
			function throttle(d,a,h){a||(a=250);var b,e;return function(){var f=h||this,c=+new Date,g=arguments;b&&c<b+a?(clearTimeout(e),e=setTimeout(function(){b=c;d.apply(f,g)},a)):(b=c,d.apply(f,g))}};




(function ($) {
							function firmasite_hover_nav() {
			var $hover_nav_style = "<style id='hover-nav' type='text/css'> ul.nav li.dropdown:hover > ul.dropdown-menu{ display: block; } .nav-tabs .dropdown-menu, .nav-pills .dropdown-menu, .navbar .dropdown-menu { margin-top: 0; margin-bottom: 0; } </style>";
			var $hover_style_inserted = $("style#hover-nav");
            if (visible_md() || visible_lg()){
				if(!$hover_style_inserted.length) {
                	$("link#bootstrap-css").after($hover_nav_style);
                    $('a.dropdown-toggle').each(function(){
                        var data_toggle = $(this).attr('data-toggle');
                        $(this).attr('data-toggle-removed',data_toggle).removeAttr('data-toggle');
                    });
                }						
			} else {
				$hover_style_inserted.remove();
				$('[data-toggle-removed]').each(function(){
					var data_toggle_removed = $(this).attr('data-toggle-removed');
					$(this).attr('data-toggle',data_toggle_removed).removeAttr('data-toggle-removed');
				});						
			}
		}
		$(window).resize(throttle(function(){
        	firmasite_hover_nav();
		},250));
				})(jQuery);







(function ($) {
	  $(window).load().trigger("resize");
  })(jQuery);
  
  
  
  
  