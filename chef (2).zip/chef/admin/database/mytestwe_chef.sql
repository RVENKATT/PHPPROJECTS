-- phpMyAdmin SQL Dump
-- version 4.3.8
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 09, 2016 at 01:14 AM
-- Server version: 5.5.42-37.1
-- PHP Version: 5.4.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mytestwe_chef`
--

-- --------------------------------------------------------

--
-- Table structure for table `aboutus`
--

CREATE TABLE IF NOT EXISTS `aboutus` (
  `ABOUTUS_ID` int(11) NOT NULL,
  `ABOUTUS_DES` text NOT NULL,
  `ABOUTUS_TITLE` varchar(30) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `aboutus`
--

INSERT INTO `aboutus` (`ABOUTUS_ID`, `ABOUTUS_DES`, `ABOUTUS_TITLE`) VALUES
(10, '<p>&nbsp;</p>\r\n<p style="font-size: 18px;">Hi Guys..</p>\r\n<p>&nbsp;</p>\r\n<p style="font-size: 17px;">This is Naveen, I am a software developer. I visited so many places on job purpose. when that time I didn&rsquo;t get proper Andhra food anywhere and some hotels and restaurants providing Andhra food but in name boards only not in the plates.</p>\r\n<p style="font-size: 17px;">So I started a branch in the name of &ldquo;Delicious Andhra&rdquo; in Hyderabad. we are successfully offering delicious Andhra food to employees in very low price there.</p>\r\n<p style="font-size: 17px;">Now I am planning to start my &ldquo;Delicious Andhra&rdquo; branch in Bangalore on some friend&rsquo;s request, I am looking for opinion polls for how many members looking here for delicious Andhra food?</p>\r\n<p style="font-size: 17px;">In Hyderabad nearby companies only using our services and remaining employees suffering to travel in small lunch break for our food, so I started direct delivery to employee&rsquo;s cabin before the lunch break.</p>\r\n<p style="font-size: 17px;">Our packing is very easy handle to eat anywhere. Every item with box packing Spoons and forks will be in packing included</p>', 'WELCOME');

-- --------------------------------------------------------

--
-- Table structure for table `addressdetails`
--

CREATE TABLE IF NOT EXISTS `addressdetails` (
  `ADDRESS_ID` int(11) NOT NULL,
  `SHIPP_NAME` varchar(255) NOT NULL,
  `SHIPP_ADDRESS` text NOT NULL,
  `SHIPP_CITY` varchar(255) NOT NULL,
  `SHIPP_STATE` varchar(255) NOT NULL,
  `SHIPP_POSTAL_CODE` varchar(255) NOT NULL,
  `SHIPP_COUNTRY` varchar(255) NOT NULL,
  `SHIPP_PHONE` varchar(255) NOT NULL,
  `TRANSACTION_ID` int(11) NOT NULL,
  `USER_ID` int(255) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `addressdetails`
--

INSERT INTO `addressdetails` (`ADDRESS_ID`, `SHIPP_NAME`, `SHIPP_ADDRESS`, `SHIPP_CITY`, `SHIPP_STATE`, `SHIPP_POSTAL_CODE`, `SHIPP_COUNTRY`, `SHIPP_PHONE`, `TRANSACTION_ID`, `USER_ID`) VALUES
(1, 'Naveen', '2-183,shapuram,pedapudi mandal', 'vizag', 'AP', '533462', 'IND', '9177868481', 1, 5),
(2, 'Kiran', '7-155,oppsit hanumantemple,Ameerpet.', 'Hyderabad', 'TS', '500082', 'IND', '9177868481', 2, 5),
(3, 'Prasad', '2-553', 'Hyderabad', 'TS', '500072', 'IND', '9177868481', 8, 5),
(4, 'Satya', '5-5532', 'hyderabad', 'ts', '500092', 'IND', '9177868481', 9, 5),
(5, 'prasadd', 'hyd', 'hyderabad', 'ap', '500082', 'IND', '9177868481', 12, 35),
(6, 'mahesh', 'Eden Apatments, Balkampet, sr nagar', 'Hyderabad', 'TS', '500001', 'IND', '8099617565', 14, 24),
(7, 'Suryam', 'Ameerpet', 'Hyderabad', 'Andhra Pradesh', '500040', 'IND', '09014413351', 15, 27);

-- --------------------------------------------------------

--
-- Table structure for table `adminuser`
--

CREATE TABLE IF NOT EXISTS `adminuser` (
  `ADMIN_ID` int(11) NOT NULL,
  `ADMIN_NAME` varchar(500) NOT NULL,
  `ADMIN_EMAIL` text NOT NULL,
  `PASSWORD` varchar(500) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adminuser`
--

INSERT INTO `adminuser` (`ADMIN_ID`, `ADMIN_NAME`, `ADMIN_EMAIL`, `PASSWORD`) VALUES
(4, 'admin', 'admin@gmail.com', '123456');

-- --------------------------------------------------------

--
-- Table structure for table `banner`
--

CREATE TABLE IF NOT EXISTS `banner` (
  `BANNER_IMG_ID` int(11) NOT NULL,
  `BANNER_ORDER` int(11) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=111 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `banner`
--

INSERT INTO `banner` (`BANNER_IMG_ID`, `BANNER_ORDER`) VALUES
(93, 10),
(85, 2),
(86, 3),
(87, 4),
(88, 5),
(89, 6),
(90, 7),
(91, 8),
(92, 9),
(94, 11),
(95, 12),
(96, 13),
(97, 14),
(98, 0),
(99, 16),
(100, 17),
(101, 18),
(102, 20),
(103, 21),
(104, 22),
(105, 23),
(106, 24),
(107, 25),
(108, 26),
(109, 27);

-- --------------------------------------------------------

--
-- Table structure for table `footer`
--

CREATE TABLE IF NOT EXISTS `footer` (
  `FOOTER_ID` int(11) NOT NULL,
  `FOOTER_CONTENT` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `footer`
--

INSERT INTO `footer` (`FOOTER_ID`, `FOOTER_CONTENT`) VALUES
(1, '<div class="col-sm-4 col-md-4 col-lg-4">\r\n<div class="footer-brand">\r\n<h4 class="brand_name">Delicious Andhra</h4>\r\n</div>\r\n</div>'),
(2, '<div class="address col-sm-3 col-md-3 col-lg-3"><address>Hyderabad,<br />Banglore</address></div>');

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE IF NOT EXISTS `gallery` (
  `GALLERY_IMG_ID` int(11) NOT NULL,
  `CONTENT` varchar(200) NOT NULL,
  `DATE` date NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=109 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`GALLERY_IMG_ID`, `CONTENT`, `DATE`) VALUES
(105, '<p>ASDFASDF</p>', '2015-06-02'),
(106, '<p>DDFGDFG HDFGH</p>', '2015-06-02'),
(107, '<p>SDFGDSGHDFGHDG</p>', '2015-06-02'),
(108, '<p>ASDFSADFASDF</p>', '2015-06-02');

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE IF NOT EXISTS `images` (
  `PIC_ID` int(11) NOT NULL,
  `IMG_NAME` varchar(20) NOT NULL,
  `PRODUCT_ID` int(11) NOT NULL,
  `DAYS` text NOT NULL,
  `COST` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`PIC_ID`, `IMG_NAME`, `PRODUCT_ID`, `DAYS`, `COST`) VALUES
(17, 'SPL1', 59, 'Monday,Tuesday,Wednesday', 100),
(18, 'SPL2', 59, 'Thursday,Friday,Saturday', 200),
(19, 'SPL3', 59, 'Sunday,Friday', 300),
(20, 'VEG1', 60, 'All', 200),
(21, 'VEG2', 60, 'Thursday,Friday,Saturday', 150),
(22, 'VEG3', 60, 'Thursday,Friday', 120),
(23, 'NONVEG1', 61, 'Thursday,Friday,Saturday', 100),
(24, 'NONVEG2', 61, 'Monday,Tuesday,Wednesday', 300),
(25, 'NONVEG3', 61, 'Monday,Tuesday,Wednesday', 500);

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE IF NOT EXISTS `menu` (
  `MENU_ID` int(11) NOT NULL,
  `MENU_TITLE` text NOT NULL,
  `MENU_DES` text NOT NULL,
  `MENU_PARENT` int(11) NOT NULL,
  `MENU_ORDER` int(11) NOT NULL,
  `EXTERNAL_LINK` text NOT NULL,
  `MENU_OR_NOT` varchar(50) NOT NULL,
  `STYLE` int(11) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=83 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`MENU_ID`, `MENU_TITLE`, `MENU_DES`, `MENU_PARENT`, `MENU_ORDER`, `EXTERNAL_LINK`, `MENU_OR_NOT`, `STYLE`) VALUES
(79, 'About Us', '<p>Hi Guys..</p>\r\n<p>This is Naveen, I am a software developer. I visited so many places on job purpose. when that time I didn&rsquo;t get proper Andhra food anywhere and some hotels and restaurants providing Andhra food but in name boards only not in the plates.</p>\r\n<p>So I started a branch in the name of &ldquo;Delicious Andhra&rdquo; in Hyderabad. we are successfully offering delicious Andhra food to employees in very low price there.</p>\r\n<p>Now I am planning to start my &ldquo;Delicious Andhra&rdquo; branch in Bangalore on some friend&rsquo;s request, I am looking for opinion polls for how many members looking here for delicious Andhra food?</p>\r\n<p>In Hyderabad nearby companies only using our services and remaining employees suffering to travel in small lunch break for our food, so I started direct delivery to employee&rsquo;s cabin before the lunch break.</p>\r\n<p>Our packing is very easy handle to eat anywhere. Every item with box packing Spoons and forks will be in packing included</p>\r\n', 0, 1, '', '0', 0),
(80, 'Recipes', '', 0, 2, 'http://mytestwebsite.in/chef/recipes.php', '0', 0),
(82, 'Contact Us', '<p>hyderabad</p>', 0, 4, 'contact.php', '0', 0);

-- --------------------------------------------------------

--
-- Table structure for table `popular`
--

CREATE TABLE IF NOT EXISTS `popular` (
  `POPULAR_ID` int(11) NOT NULL,
  `POPULAR_TITLE` varchar(50) NOT NULL,
  `POPULAR_DES` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `popular`
--

INSERT INTO `popular` (`POPULAR_ID`, `POPULAR_TITLE`, `POPULAR_DES`) VALUES
(1, 'most popular', '<p>Ceaertrsa vaesar rafaes setyeras ertyao lasec vasptai aoertayse squrem ipsum quia dolor. Vsanamet, consect amodi tempora incidunt.</p>'),
(2, 'special offer', '<p>Daesarfaes setyera krscaertrsa aoertayse squrem ipsum quiertyaodeas laseceras vasptai a dolor. Vsanamet, consect di tempora miaser.</p>');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE IF NOT EXISTS `product` (
  `PRODUCT_ID` int(11) NOT NULL,
  `PRODUCT_TITLE` varchar(50) NOT NULL,
  `PRODUCT_DES` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`PRODUCT_ID`, `PRODUCT_TITLE`, `PRODUCT_DES`) VALUES
(59, 'Andhra Special', '<p>Andhra Special Items...Paravannam, Pulihora, Avakayi pickle,magayi pickle, garelu, curd rice,payasam, thepi garelu, perugu garelu, gummadi vadiyalu, perugu miragayalu...</p>'),
(60, 'Andhra Veg Items', '<p>Potato curry, Guthhi vankaya Curry, bendakaya pulusu, potato fry,pappu tamoto, mudda pappu, Rasam, Sambar,califlower,mulakada tamoto, chikkudi kaya tamota,thota kura pappu,dondakaya curry, dondakaya fry,cabbage curry,aratikaya fry, aratikaya curry...etc</p>'),
(61, 'Andhra Non veg Items', '<p>Andha Chicken Curry, Chicken fry, Chicken corn fry, Gongura chicken,mulakada chicken,chicken potato curry,Mutton curry, Gongura mutton,Mutton fry,Mutton head pulusu,Royyala curry, Royyala vepudu,vankaya Reyyalu, Potato Royyalu,Egg Royyalu,bendakaya royyalu pulusu,Fish curry,Fish Pulusu,Fish Iguru,Fish fry,Pithala pulusu,Pithalu iguru,Pithalu fry</p>');

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE IF NOT EXISTS `transaction` (
  `TRANSACTION_ID` int(11) NOT NULL,
  `TRANSACTION_KEY` text NOT NULL,
  `USER_ID` int(11) NOT NULL,
  `AMOUT` varchar(100) NOT NULL,
  `PRODUCT` int(11) NOT NULL,
  `ON_DATE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `PAYMENT_STATUS` int(11) NOT NULL,
  `DELIVARY_STATUS` text NOT NULL,
  `ADDRESS_ID` int(255) NOT NULL,
  `SHIPP_DELIVERY_DATE` date NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`TRANSACTION_ID`, `TRANSACTION_KEY`, `USER_ID`, `AMOUT`, `PRODUCT`, `ON_DATE`, `PAYMENT_STATUS`, `DELIVARY_STATUS`, `ADDRESS_ID`, `SHIPP_DELIVERY_DATE`) VALUES
(14, 'ogIuS6hyk1', 24, '300', 1, '2015-08-19 12:16:54', 0, '', 0, '2015-08-24'),
(15, '1iQU47J1yB', 27, '500', 2, '2015-08-19 12:45:44', 0, '', 0, '2015-08-20'),
(16, 'q8ArHi6mFG', 27, '1000', 1, '2015-08-19 12:49:35', 0, '', 7, '2015-08-21'),
(17, '1NyMxcFtph', 27, '920', 4, '2015-08-19 12:51:47', 0, '', 7, '2015-08-22');

-- --------------------------------------------------------

--
-- Table structure for table `transaction_details`
--

CREATE TABLE IF NOT EXISTS `transaction_details` (
  `TRANSACTION_DETAILS_ID` int(11) NOT NULL,
  `TRANSACTION_ID` int(11) NOT NULL,
  `PRODCUT_ID` int(11) NOT NULL,
  `QUANTITY` int(11) NOT NULL,
  `VENDOR_ID` int(11) NOT NULL,
  `INFO` text NOT NULL,
  `DELIVARY_STATUS` int(11) NOT NULL,
  `MESSAGE` text NOT NULL,
  `CITY` varchar(255) NOT NULL,
  `FIELD3` int(11) NOT NULL,
  `FIELD4` int(11) NOT NULL,
  `FIELD5` int(11) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaction_details`
--

INSERT INTO `transaction_details` (`TRANSACTION_DETAILS_ID`, `TRANSACTION_ID`, `PRODCUT_ID`, `QUANTITY`, `VENDOR_ID`, `INFO`, `DELIVARY_STATUS`, `MESSAGE`, `CITY`, `FIELD3`, `FIELD4`, `FIELD5`) VALUES
(15, 14, 18, 1, 0, '', 0, '', '', 0, 0, 0),
(16, 15, 17, 2, 0, '', 0, '', '', 0, 0, 0),
(17, 15, 18, 1, 0, '', 0, '', '', 0, 0, 0),
(18, 16, 19, 3, 0, '', 0, '', '', 0, 0, 0),
(19, 17, 17, 4, 0, '', 0, '', '', 0, 0, 0),
(20, 17, 20, 1, 0, '', 0, '', '', 0, 0, 0),
(21, 17, 22, 1, 0, '', 0, '', '', 0, 0, 0),
(22, 17, 23, 1, 0, '', 0, '', '', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `USER_ID` int(11) NOT NULL,
  `USER_NAME` text COLLATE utf8_unicode_ci NOT NULL,
  `USER_EMAIL` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `USER_MOBILE` text COLLATE utf8_unicode_ci NOT NULL,
  `USER_COMPANY` text COLLATE utf8_unicode_ci NOT NULL,
  `USER_PASSWORD` text COLLATE utf8_unicode_ci NOT NULL,
  `USER_ADDRESS` text COLLATE utf8_unicode_ci NOT NULL,
  `FOOD_TYPE` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`USER_ID`, `USER_NAME`, `USER_EMAIL`, `USER_MOBILE`, `USER_COMPANY`, `USER_PASSWORD`, `USER_ADDRESS`, `FOOD_TYPE`) VALUES
(16, 'Anand', 'anand@friendsfocus.in', '9701010109', '', '123456', 'Hyderababd ', ''),
(11, 'naveen', 'nazeer1331@gmail.com', '9035671888', '', '6109', 'whitefeild ', ''),
(5, 'Gopi Krishna', 'kushalp77@gmail.com', '9090909090', '', '5543', 'rrrrrrrrrrrrrrrrrrrr ', ''),
(12, 'Suryam', 'suryam7786@gmail.com', '9014413351', '', '123456', 'Hyd ', ''),
(7, 'vinod', 'kvnvk82@live.com', '9848184540', '', '2967', 'coooll ', ''),
(8, 'NAZEER', 'CITYSEVA2@GMAIL.COM', '9160668382', '', '8099', 'BANGALORE ', ''),
(9, 'Asha Begum', 'sheikashabegum@gmail.com', '8867852640', '', '8952', 'Bangalore ', ''),
(14, 'Anand', 'hi.anandv@gmail.com', '9090909090', '', '', '1111111 ', ''),
(24, 'mahesh', 'mahesh@palvs.com', '8099617565', '', '12345', 'asdf', ''),
(27, 'Suryam', 'ramasuryam.r@gmail.com', '9014413351', 'GWS', '123456', 'ABC Colony', 'Both');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `aboutus`
--
ALTER TABLE `aboutus`
  ADD PRIMARY KEY (`ABOUTUS_ID`);

--
-- Indexes for table `addressdetails`
--
ALTER TABLE `addressdetails`
  ADD PRIMARY KEY (`ADDRESS_ID`);

--
-- Indexes for table `adminuser`
--
ALTER TABLE `adminuser`
  ADD PRIMARY KEY (`ADMIN_ID`);

--
-- Indexes for table `banner`
--
ALTER TABLE `banner`
  ADD PRIMARY KEY (`BANNER_IMG_ID`);

--
-- Indexes for table `footer`
--
ALTER TABLE `footer`
  ADD PRIMARY KEY (`FOOTER_ID`);

--
-- Indexes for table `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`GALLERY_IMG_ID`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`PIC_ID`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`MENU_ID`);

--
-- Indexes for table `popular`
--
ALTER TABLE `popular`
  ADD PRIMARY KEY (`POPULAR_ID`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`PRODUCT_ID`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`TRANSACTION_ID`);

--
-- Indexes for table `transaction_details`
--
ALTER TABLE `transaction_details`
  ADD PRIMARY KEY (`TRANSACTION_DETAILS_ID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`USER_ID`), ADD UNIQUE KEY `USER_EMAIL` (`USER_EMAIL`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `aboutus`
--
ALTER TABLE `aboutus`
  MODIFY `ABOUTUS_ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `addressdetails`
--
ALTER TABLE `addressdetails`
  MODIFY `ADDRESS_ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `adminuser`
--
ALTER TABLE `adminuser`
  MODIFY `ADMIN_ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `banner`
--
ALTER TABLE `banner`
  MODIFY `BANNER_IMG_ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=111;
--
-- AUTO_INCREMENT for table `footer`
--
ALTER TABLE `footer`
  MODIFY `FOOTER_ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `gallery`
--
ALTER TABLE `gallery`
  MODIFY `GALLERY_IMG_ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=109;
--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `PIC_ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `MENU_ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=83;
--
-- AUTO_INCREMENT for table `popular`
--
ALTER TABLE `popular`
  MODIFY `POPULAR_ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `PRODUCT_ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=62;
--
-- AUTO_INCREMENT for table `transaction`
--
ALTER TABLE `transaction`
  MODIFY `TRANSACTION_ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `transaction_details`
--
ALTER TABLE `transaction_details`
  MODIFY `TRANSACTION_DETAILS_ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `USER_ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=28;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
