<?php

session_start();

ob_start();

error_reporting(0);

if($_SESSION[ADMIN_ID]=='')

{



	

	header("location:index.php");

}



if(isset($_REQUEST[add]))

{





if(isset($_FILES['file']))

	{

     move_uploaded_file($_FILES["file"]["tmp_name"],"images/logo.jpg");    

          

				// make_thumb("product_images/".$product_img.".jpg","product_images/temp/".$product_img.".jpg",500,400);		

	}



header("location:admin-logo.php");

}	





?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="utf-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Dashboard - Dark Admin</title>



    <link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.min.css" />

    <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />

    <link rel="stylesheet" type="text/css" href="css/style.css" />

		<link href="http://cdn.datatables.net/plug-ins/725b2a2115b/integration/bootstrap/3/dataTables.bootstrap.css" rel="stylesheet">



<script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>

    <script type="text/javascript" src="js/bootstrap.js"></script>

	<script src="js/scripts.js"></script>



	<script src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js"></script>

<script src="http://cdn.datatables.net/plug-ins/725b2a2115b/integration/bootstrap/3/dataTables.bootstrap.js"></script>

    <script type="text/javascript">

	function  pop_function(user_id)

	{

	//menu loading

$.post("ajax/admin-edit.php?USER_ID="+user_id,function(data){



document.getElementById('myModal1').innerHTML=data;



});

	}

	</script>

     <script type="text/javascript">

function delid(user_id)

{

	

i=confirm("Are you sure to delete the user");

if(i)

	{

$.post("ajax/admin-delete.php?USER_ID="+user_id,function(data){



document.getElementById('cat_tab_id').innerHTML=data;



});

	}

}



</script>





<script src="jquery.js"></script>

	<script src="jquery.validate.js"></script>

	<script>

	



	$().ready(function() {

		// validate the comment form when it is submitted

		



		// validate signup form on keyup and submit

		$("#commentForm").validate({

			rules: {

				USERNAME: "required",

				

				EMAIL: {

					required: true,

					email: true

					

				},

				PASSWORD: {

					required: true,

					minlength: 5

				},

	

			PHONE: {

				required: true,

                            number: true,

							minlength:10,

							maxlength:10

			},

			

		

				

			},

			messages: {

				USERNAME: "Please enter your USERNAME",

					EMAIL: {

					required: "please enter email",

					email: "please enter a valide email address"

					

				},

			

			

				PASSWORD: {

					required: "Please provide a password",

					minlength: "Your password must be at least 5 characters long"

				},

				PHONE: {

				required: "Please enter your phone number",

                            number: "enter digits only",

							minlength:"enter 10 digits mobile number",

							maxlength:"enter 10 digits mobile number"

			},

				

			

			}

		});



	





	});

	</script>

    	<style>



	form.cmxform label.error, label.error {

	/* remove the next line when you have trouble in IE6 with labels in list */

	color: red;

	font-style: italic

}



	</style>

    



    



<style type="text/css">

.gap{ margin-top:1em;}

</style>

 

</head>

<body>



    <div id="wrapper">



            <?php include('includes/admin-header.php')?>



        <div id="page-wrapper">

		

		<legend>logo

		<span class="pull-right"><button class="btn btn-primary" data-toggle="modal" data-target="#myModal">UPDATE LOGO IMAGE</button></span></legend>

        <hr style="color: #303">



<!-- Modal -->

<div class="modal fade bs-example-modal-lg" id="myModal" tablogo="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">

  <div class="modal-dialog">

    <div class="modal-content">

      <div class="modal-header">

        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>

        <h4 class="modal-title" id="myModalLabel">LOGO IMAGE</h4>

      </div> 

      <div class="modal-body">

  <form  class="cmxform" id="commentForm"  enctype="multipart/form-data" method="post"> 

  <div class="container-fluid">

  <div class="row">

  <div  class="col-sm-4 pad">UPLOAD IMAGE:</div><div class="col-sm-8 pad"> <input type="file" name="file"  id="file"/> </div>

       <div  class="col-sm-12 pad">  <input type="submit" class="btn btn-primary pull-right" name="add" value="Upload" /></div></div></div></form>

      </div>

      <div class="modal-footer">

        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>

      

      </div>

    </div>

  </div>



		



		

		

		</div>

        	<img src="images/logo.jpg">	

		</div>

        <div class="clearfix"></div>



   </div> 

    

    <div class="modal fade bs-example-modal-lg" id="myModal1" tablogo="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">

  

</div>



    <!-- /#wrapper -->

    

</body>

</html>

