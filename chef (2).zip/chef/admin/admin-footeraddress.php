<?php

session_start();

ob_start();

//error_reporting(0);

if($_SESSION[ADMIN_ID]=='')

{



	

	header("location:index.php");

}

include('includes/admin-menu-db.php');

$dbFactory= new menu_db();

if(isset($_REQUEST[add]))

{

	$CONTENT_DESCRIPTION=mysql_escape_string($_REQUEST[FOOTER_CONTENT]);

	$f=$dbFactory->footer_add($CONTENT_DESCRIPTION);

	header("location:admin-footeraddress.php");

}

if(isset($_REQUEST[update]))

{

	$CONTENT_DESCRIPTION=mysql_escape_string($_REQUEST[FOOTER_CONTENT]);

		$f=$dbFactory->footer_update($CONTENT_DESCRIPTION,1);

	header("location:admin-footeraddress.php");

}



?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="utf-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Dashboard - Dark Admin</title>



    <link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.min.css" />

    <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />

    <link rel="stylesheet" type="text/css" href="css/style.css" />

	<script src="http://tinymce.cachefly.net/4.1/tinymce.min.js"></script>

<script>

tinymce.init({

plugins: [

"code"

],

toolbar: "code",

selector:'textarea'

});</script>

    	<link href="http://cdn.datatables.net/plug-ins/725b2a2115b/integration/bootstrap/3/dataTables.bootstrap.css" rel="stylesheet">



<script src="ckeditor.js"></script>

<script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>

    <script type="text/javascript" src="js/bootstrap.js"></script>

	<script src="js/scripts.js"></script>



	<script src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js"></script>

<script src="http://cdn.datatables.net/plug-ins/725b2a2115b/integration/bootstrap/3/dataTables.bootstrap.js"></script>

    <script type="text/javascript">

	function  pop_function(footer_id)

	{

	//menu loading

$.post("ajax/admin-edit.php?FOOTER_ID="+footer_id,function(data){
tinymce.init({

plugins: [

"code"

],

toolbar: "code",

selector:'textarea'

});



document.getElementById('myModal1').innerHTML=data;



});

	}

	</script>

     <script type="text/javascript">

function delid(FOOTER_ID)

{

	

i=confirm("Are you sure to delete the footer");

if(i)

	{

$.post("ajax/admin-delete.php?FOOTER_ID="+FOOTER_ID,function(data){



document.getElementById('cat_tab_id').innerHTML=data;



});

	}

}



</script>





<script src="jquery.js"></script>

	<script src="jquery.validate.js"></script>

	<script>

	



	$().ready(function() {

		// validate the comment form when it is submitted

		



		// validate signup form on keyup and submit

		$("#commentForm").validate({

			rules: {

				FOOTER_CONTENT: "required",

				

				EMAIL: {

					required: true,

					email: true

					

				},

				PASSWORD: {

					required: true,

					minlength: 5

				},

	

			PHONE: {

				required: true,

                            number: true,

							minlength:10,

							maxlength:10

			},

			

		

				

			},

			messages: {

				FOOTER_CONTENT: "Please enter your FOOTER_CONTENT",

					EMAIL: {

					required: "please enter email",

					email: "please enter a valide email address"

					

				},

			

			

				PASSWORD: {

					required: "Please provide a password",

					minlength: "Your password must be at least 5 characters long"

				},

				PHONE: {

				required: "Please enter your phone number",

                            number: "enter digits only",

							minlength:"enter 10 digits mobile number",

							maxlength:"enter 10 digits mobile number"

			},

				

			

			}

		});



	





	});

	</script>

    	<style>



	form.cmxform label.error, label.error {

	/* remove the next line when you have trouble in IE6 with labels in list */

	color: red;

	font-style: italic

}



	</style>

    



    



<style type="text/css">

.gap{ margin-top:1em;}

</style>

 

</head>

<body>



    <div id="wrapper">



            <?php include('includes/admin-header.php')?>



        <div id="page-wrapper">

		

		<legend>footers
    <button class="btn btn-primary" data-toggle="modal" data-target="#myModal">Add</button>
</legend>

        <hr style="color: #303">



<!-- Modal -->

<div class="modal fade bs-example-modal-lg" id="myModal" tabfooters="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">

  <div class="modal-dialog">

    <div class="modal-content">

      <div class="modal-header">

        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>

        <h4 class="modal-title" id="myModalLabel">ADD</h4>

      </div> 

      <div class="modal-body">

  <form  class="cmxform" id="commentForm"  method="post"> 

  <div class="container-fluid">

  <div class="row">

   <div  class="col-sm-3 pad">

    footer Name: </div><div class="col-sm-9 pad"><input  type="text" name="FOOTER_CONTENT" /></div>



       <div  class="col-sm-12 pad">  <input type="submit" class="btn btn-primary pull-right" name="add" value="Add" /></div></div></div></form>

      </div>

      <div class="modal-">

        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>

      

      </div>

    </div>

  </div>

</div>

		

		<div class="clearfix"></div>

		<div class="table-responsive">

		<table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">

         <tbody id="cat_tab_id">

		  <form   class="editform" id="kiran" method="post"> 

	<?php

$s=$dbFactory->footer();



//if($d[$i][person]=='')continue;

?>	

  <tr height="50px">

    <td>

     <textarea  name="FOOTER_CONTENT"><?php echo stripslashes($s[0][FOOTER_CONTENT]);?></textarea>

   

    </td>

    <td>  <input type="submit" class="btn btn-primary pull-right" name="update" value="Update" /></td>

    

  </tr>



		</form>

		

           

		</tbody>

    </table>

      

      </div>

		

		</div>

		</div>



    

    

    <div class="modal fade bs-example-modal-lg" id="myModal1" tabfooters="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">

  

</div>

    <!-- /#wrapper -->

    

</body>

</html>

