<?php

session_start();

ob_start();

error_reporting(0);

if($_SESSION[ADMIN_ID]=='')

{



	

	header("location:index.php");

}

include('includes/admin-users-management.php');

$dbFactory= new UsersManagement();

if(isset($_REQUEST[add]))

{

	$f=$dbFactory->user_add($_REQUEST[USERNAME],$_REQUEST[EMAIL],$_REQUEST[PASSWORD],$_REQUEST[PHONE],$_REQUEST[USER_TYPE]);

	header("location:admin-users.php");

}

if(isset($_REQUEST[update]))

{

	echo 'r';

	$f=$dbFactory->user_update($_REQUEST[USERNAME],$_REQUEST[EMAIL],$_REQUEST[PASSWORD],$_REQUEST[PHONE],$_REQUEST[USER_TYPE],$_REQUEST[USER_ID]);

	header("location:admin-users.php");

}

if(isset($_REQUEST[inactive]))

{

	 $s=$dbFactory->user_status_update1($_REQUEST[USER_ID]);

	   header("location:admin-users.php");

}

if(isset($_REQUEST[active]))

{

	 $s=$dbFactory->user_status_update2($_REQUEST[USER_ID]);

	   header("location:admin-users.php");

}

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="utf-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Dashboard - Dark Admin</title>



    <link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.min.css" />

    <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />

    <link rel="stylesheet" type="text/css" href="css/style.css" />

		<link href="http://cdn.datatables.net/plug-ins/725b2a2115b/integration/bootstrap/3/dataTables.bootstrap.css" rel="stylesheet">



<script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>

    <script type="text/javascript" src="js/bootstrap.js"></script>

	<script src="js/scripts.js"></script>



	<script src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js"></script>

<script src="http://cdn.datatables.net/plug-ins/725b2a2115b/integration/bootstrap/3/dataTables.bootstrap.js"></script>

    <script type="text/javascript">

	function  pop_function(user_id)

	{

	//menu loading

$.post("ajax/admin-edit.php?USER_ID="+user_id,function(data){



document.getElementById('myModal1').innerHTML=data;



});

	}

	</script>

     <script type="text/javascript">

function delid(user_id)

{

	

i=confirm("Are you sure to delete the user");

if(i)

	{

$.post("ajax/admin-delete.php?USER_ID="+user_id,function(data){



document.getElementById('cat_tab_id').innerHTML=data;



});

	}

}



</script>





<script src="jquery.js"></script>

	<script src="jquery.validate.js"></script>

	<script>

	



	$().ready(function() {

		// validate the comment form when it is submitted

		



		// validate signup form on keyup and submit

		$("#commentForm").validate({

			rules: {

				USERNAME: "required",

				

				EMAIL: {

					required: true,

					email: true

					

				},

				PASSWORD: {

					required: true,

					minlength: 5

				},

	

			PHONE: {

				required: true,

                            number: true,

							minlength:10,

							maxlength:10

			},

			

		

				

			},

			messages: {

				USERNAME: "Please enter your USERNAME",

					EMAIL: {

					required: "please enter email",

					email: "please enter a valide email address"

					

				},

			

			

				PASSWORD: {

					required: "Please provide a password",

					minlength: "Your password must be at least 5 characters long"

				},

				PHONE: {

				required: "Please enter your phone number",

                            number: "enter digits only",

							minlength:"enter 10 digits mobile number",

							maxlength:"enter 10 digits mobile number"

			},

				

			

			}

		});



	





	});

	</script>

    	<style>



	form.cmxform label.error, label.error {

	/* remove the next line when you have trouble in IE6 with labels in list */

	color: red;

	font-style: italic

}



	</style>

    



    



<style type="text/css">

.gap{ margin-top:1em;}

</style>

 

</head>

<body>



    <div id="wrapper">



            <?php include('includes/admin-header.php')?>



        <div id="page-wrapper">

		

		<legend>Users

		<span class="pull-right"><button class="btn btn-primary" data-toggle="modal" data-target="#myModal">Add</button></span></legend>

        <hr style="color: #303">



<!-- Modal -->

<div class="modal fade bs-example-modal-lg" id="myModal" tabusers="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">

  <div class="modal-dialog">

    <div class="modal-content">

      <div class="modal-header">

        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>

        <h4 class="modal-title" id="myModalLabel">ADD</h4>

      </div> 

      <div class="modal-body">

  <form  class="cmxform" id="commentForm"  method="post"> 

  <div class="container-fluid">

  <div class="row">

   <div  class="col-sm-3 pad">

    User Name: </div><div class="col-sm-9 pad"><input  type="text" name="USERNAME" /></div>

         

         

         <div  class="col-sm-3 pad"> Email:</div> <div  class="col-sm-9 pad"> <input  type="text" name="EMAIL" /> </div>

     <div  class="col-sm-3 pad"> Passoword:</div><div class="col-sm-9 pad"> <input  type="password" name="PASSWORD" /></div>

  



   

   

     

     <div  class="col-sm-3 pad">  Phone: </div><div  class="col-sm-9 pad"> <input  type="text" name="PHONE"  /></div>

         <div  class="col-sm-3 pad">  User Type: </div><div  class="col-sm-9 pad">  <select  name="USER_TYPE" style="width:158px">

        <option value="">-Select-</option>

    



     

	

	<option value="0">User</option>

    	<option value="1">Merchant</option>



      </select></div></div>

       <div  class="col-sm-12 pad">  <input type="submit" class="btn btn-primary pull-right" name="add" value="Add" /></div></div></div></form>

      </div>

  

    </div>

  </div>



		

		<div class="clearfix"></div>

		<div class="table-responsive">

		<table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">

        <thead>

            <tr>

			 <th>SNO</th>

                <th>USER NAME</th>

                <th>EMAIL</th>

               <!-- <th>PASSWORD</th>
-->
                <th>PHONE</th>

                     <!--  <th>TYPE</th>

                       <th>PERMISSION</th>-->

                <th>EDIT</th>

               <th>DELETE</th>

            </tr>

        </thead>

 

        

 

        <tbody id="cat_tab_id">

		

	<?php

$s=$dbFactory->userss();

for($i=0; $i<count($s); $i++){

//if($d[$i][person]=='')continue;

?>	

  <tr height="50px">

    <td><?php echo $i+1 ?></td>

    <td><?php echo $s[$i][USER_NAME];?></td>

    <td><?php echo $s[$i][USER_EMAIL];?></td>

	   <!-- <td><?php echo $s[$i][PASSWORD];?></td>-->

    <td><?php echo $s[$i][USER_MOBILE];?></td>

    <!-- <td><?php if($s[$i][USER_TYPE]==0)echo User;if($s[$i][USER_TYPE]==1)echo Merchant;?></td>

     <?php if($s[$i][USER_STATUS]==0){?>

<td> <form  method="post"><input type="hidden" name="USER_ID" value="<?php echo $s[$i][USER_ID]; ?>" /><input type="submit" name="inactive" value="inactive" /></form></td><?php }else{?>

<td><form  method="post"><input type="hidden" name="USER_ID" value="<?php echo $s[$i][USER_ID]; ?>" /><input type="submit" name="active" value="active" /></form></td><?php }?>
-->
    <td><span class="btn btn-primary btn-xs" data-toggle="modal" data-target="#myModal1" onClick="pop_function(<?php echo $s[$i][USER_ID];?>)">EDIT</span></td>

    <td><span onClick="delid(<?php echo $s[$i][USER_ID]; ?>)">DELETE</span></td>



  </tr>

<?php }?>

		

		

           

		</tbody>

    </table>

      

      </div>

		

		</div>

		</div>



    

    

    <div class="modal fade bs-example-modal-lg" id="myModal1" tabusers="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">

  

</div>

    <!-- /#wrapper -->

    

</body>

</html>

