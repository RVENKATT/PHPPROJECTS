<?php

session_start();

ob_start();

error_reporting();



include('includes/admin-menu-db.php');

$dbFactory= new menu_db();

//echo $_REQUEST[id];

if(isset($_REQUEST[add]))

{
   

	

	

$s=$dbFactory->menu_internal($_REQUEST[IMG_NAME],$_REQUEST[DAYS],$_REQUEST[COST],$_REQUEST[id]);

if($_FILES["file"]["name"]!='')
{
echo "images/" . $s.".jpg";
move_uploaded_file($_FILES["file"]["tmp_name"],"images/".$s.".jpg");
}

if($_FILES['pdffile']['name'][0]!='')
{
$errors= array();
foreach($_FILES['pdffile']['tmp_name'] as $key => $tmp_name )
{
$file_name = $_FILES['pdffile']['name'][$key];
$file_size =$_FILES['pdffile']['size'][$key];
$file_tmp =$_FILES['pdffile']['tmp_name'][$key];
$file_type=$_FILES['pdffile']['type'][$key];	
if($_FILES['pdffile']['type'][$key]=="image/png")
$x="png";
if($_FILES['pdffile']['type'][$key]=="image/jpeg")
$x="jpeg";
if($_FILES['pdffile']['type'][$key]=="image/jpg")
$x="jpg";
if($_FILES['pdffile']['type'][$key]=="image/gif")
$x="gif";
if($_FILES['pdffile']['type'][$key]=="application/pdf")

	$x="pdf";
	

	$product_img=$dbFactory->products_img_add($_REQUEST[id],$s,$img_name);

$img_name=$product_img.".".$x;

  

			$product_img_update=$dbFactory->products_img_add_update($product_img,$img_name);

        $desired_dir="images";

       


                move_uploaded_file($file_tmp,"images/".$product_img.".".$x);

				echo "images/".$product_img.".".$x;

				

      }





	}

header("location:admin-internal.php?id=$_REQUEST[id]");

}

if(isset($_REQUEST[update]))

{


	

 $f=$dbFactory->internal_update($_REQUEST[IMG_NAME],$_REQUEST[DAYS],$_REQUEST[COST],$_REQUEST[PIC_ID]);
 
$temp=$_REQUEST[PIC_ID];

 if($_FILES["file"]["name"]!='')
{
echo "images/" . $temp.".jpg";
move_uploaded_file($_FILES["file"]["tmp_name"],"images/".$temp.".jpg");
}

	//header("location:admin-internal.php?id=$_REQUEST[id]");

}


if(isset($_REQUEST[did]))

{

 $s=$dbFactory->internal_delete($_REQUEST[did]);



   header("location:admin-internal.php?id=".$_REQUEST[id]."");



}


?>
<?php

function make_thumb($img_name,$filename,$new_w,$new_h)

{

$ext=getExtension($img_name);

if(!strcmp("jpg",$ext) || !strcmp("JPG",$ext) || !strcmp("jpeg",$ext) || !strcmp("JPEG",$ext))

$src_img=imagecreatefromjpeg($img_name);

if(!strcmp("gif",$ext) || !strcmp("GIF",$ext))

$src_img=imagecreatefromgif($img_name);

if(!strcmp("png",$ext) || !strcmp("PNG",$ext))

$src_img=imagecreatefrompng($img_name);

$old_x=imagesx($src_img);

$old_y=imagesy($src_img);

$ratio1=$old_x/$new_w;

$ratio2=$old_y/$new_h;

if($ratio1>$ratio2) {

$thumb_w=$new_w;

$thumb_h=$old_y/$ratio1;

}

else {

$thumb_h=$new_h;

$thumb_w=$old_x/$ratio2;

}

$dst_img=ImageCreateTrueColor($thumb_w,$thumb_h);

imagecopyresampled($dst_img,$src_img,0,0,0,0,$thumb_w,$thumb_h,$old_x,$old_y);

if(!strcmp("png",$ext))

imagepng($dst_img,$filename);

if(!strcmp("gif",$ext))

imagegif($dst_img,$filename);

else

imagejpeg($dst_img,$filename);

imagedestroy($dst_img);

imagedestroy($src_img);

}

function getExtension($str) {

$i = strrpos($str,".");

if (!$i) { return ""; }

$l = strlen($str) - $i;

$ext = substr($str,$i+1,$l);

return $ext;

}

 ?>

<!DOCTYPE html>

<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard - Dark Admin</title>
<link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.min.css" />
<link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
<link rel="stylesheet" type="text/css" href="css/style.css" />
<link href="http://cdn.datatables.net/plug-ins/725b2a2115b/integration/bootstrap/3/dataTables.bootstrap.css" rel="stylesheet">
<script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
<script type="text/javascript" src="js/bootstrap.js"></script>
<script src="js/scripts.js"></script>
<script src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js"></script>
<script src="http://cdn.datatables.net/plug-ins/725b2a2115b/integration/bootstrap/3/dataTables.bootstrap.js"></script>
<script type="text/javascript">

	function  pop_function(PIC_ID)

	{

	//menu loading

$.post("ajax/admin-edit.php?PIC_ID="+PIC_ID,function(data){



document.getElementById('myModal1').innerHTML=data;

tinymce.init({
plugins: [
"code"
],
toolbar: "code",
selector:'textarea'
});


});

	}
</script>
<script type="text/javascript">

function delid(IMG_ID)

{

i=confirm("Are you sure to delete the item");

if(i)

window.location="admin-internal.php?id=<?php echo $_REQUEST[id];?>&did="+IMG_ID;

}



</script>
<script src="http://tinymce.cachefly.net/4.1/tinymce.min.js"></script>
<script>

tinymce.init({

plugins: [

"code"

],

toolbar: "code",

selector:'textarea'

});</script>
<script src="jquery.js"></script>
<script src="jquery.validate.js"></script>
<script>

	



	$().ready(function() {

		// validate the comment form when it is submitted

		



		// validate signup form on keyup and submit

		$("#commentForm").validate({

			rules: {

				MI_TITLE: "required",

				

				MENU_PARENT: "required",

				MENU_ORDER: "required"

	

		

		

				

			},

			messages: {

				MI_TITLE: "Please enter your category title",

					MENU_PARENT: "Please select  parent ",

			

			

				MENU_ORDER: "Please enter your category order"

		

			

			}

		});



			});

	</script>
<style>
form.addform label.error, label.error {
	/* remove the next line when you have trouble in IE6 with labels in list */

	color: red;
	font-style: italic
}
</style>
</head>

<body>
<div id="wrapper">
  <?php include('includes/admin-header.php')?>
  <div id="page-wrapper">
    <legend>menu <span class="pull-right">
    <button class="btn btn-primary" data-toggle="modal" data-target="#myModal">Add</button>
    </span></legend>
    <hr style="color: #303">
    
    <!-- Modal -->
    
    <div class="modal fade bs-example-modal-lg" id="myModal" tabmenu="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            <h4 class="modal-title" id="myModalLabel">ADD</h4>
          </div>
          <div class="modal-body">
            <form enctype="multipart/form-data"  class="addform" id="commentForm" method="post">
              <div class="container-fluid">
                <div class="row">
                  <div  class="col-sm-4 pad"> IMG NAME: </div>
                  <div class="col-sm-8 pad">
                    <input  type="text" name="IMG_NAME"   />
                  </div>
                   <div  class="col-sm-4 pad"> DAYS: </div>
                  <div class="col-sm-8 pad">
                    <input  type="text" name="DAYS"   />
                  </div>
                   <div  class="col-sm-4 pad"> COST: </div>
                  <div class="col-sm-8 pad">
                    <input  type="text" name="COST"   />
                  </div>
                  <div  class="col-sm-4 pad">Upload Image:</div>
                  <div class="col-sm-8 pad">
                    <input type="file" name="file"  id="file" multiple/>
                  </div>
                  <div  class="col-sm-12 pad">
                    <input type="submit" class="btn btn-primary pull-right" name="add" value="ADD" />
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
    <div class="clearfix"></div>
    <div class="table-responsive">
      <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
        <thead>
          <tr>
            <th>SNO</th>
            <th>IMAGE NAME</th>
            <th>IMAGE</th>
            <th></th>
             <th></th>
          </tr>
        </thead>
        <tbody id="cat_tab_id">
          <?php

$s=$dbFactory->menu_internals_details($_REQUEST[id]);

for($i=0; $i<count($s); $i++){



?>
          <tr height="50px">
            <td><?php echo $i+1 ?></td>
            <td><?php echo $s[$i][IMG_NAME];?></td>
            <td><img src="images/<?php echo $s[$i][PIC_ID];?>.jpg" width="60" height="60"></td>
            <td><span class="btn btn-primary btn-xs" data-toggle="modal" data-target="#myModal1" onClick="pop_function(<?php echo $s[$i][PIC_ID];?>)">EDIT</span></td>
           <td><a  onclick="delid(<?php echo $s[$i][PIC_ID]; ?>)" style="cursor:pointer" >Delete</a></td>
          </tr>
          <?php }?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<div class="modal fade bs-example-modal-lg" id="myModal1" tabmenu="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true"> </div>

<!-- /#wrapper -->

<style type='text/css'>
body {
    font-family: sans-serif;
}
</style>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script> 
<script>
$(document).ready(function () {
	
	
$('input[type=file]').change(function () {
var val = $(this).val().toLowerCase();
var regex = new RegExp("(.*?)\.(jpg|jpeg|pdf|png)$");
 
if(!(regex.test(val))) {
$(this).val('');
alert('.jpg,.jpeg,.png,.pdf  files are existing only');
} }); });
</script>
</body>
</html>
