<?php

	session_start();
	ob_start();

	error_reporting(0);

	include('includes/products-management.php');

	$dbFactory= new ProductsManagement();

  
 if(isset($_REQUEST[login]))
 {
	 $user=$dbFactory->registeruser_check($_REQUEST[EMAIL],$_REQUEST[PASSWORD]);
	 if(count($user)==1)

	{

	echo $_SESSION[user_id]=$user[0][USER_ID];

	echo $_SESSION[user_name]=$user[0][USER_NAME];

	$_SESSION[user_email]=$user[0][USER_EMAIL];

	

	header("location:shipping.php");



	}

	else

    {
$_SESSION[mes]=5;
	header("location:login.php");
exit(0);
    } 
	 
	 
 }
 
 

?>
<!DOCTYPE  html>
<html lang="en">

<head>
  <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>DeleciousAndhra</title>


    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="css/animate.css" type="text/css">
	<link rel="stylesheet" href="font-awesome-4.2.0/css/font-awesome.min.css" type="text/css">
    
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script> 
    <script src="js/bootstrap.min.js"></script> 
    <script src="js/scripts.js"></script>
    <!-- Just include this Js file -->
	<script src="./js/jquery.carousel.fullscreen.js"></script>
    <style>
#map-canvas {
	width: 100%;
	height: 320px;
}
</style>
</head>


<body>
<?php if($_SESSION[mes]==5){ ?>
 <div class="alert alert-success" style="margin:10px">
        <a href="#" class="close" data-dismiss="alert">&times;</a>
        <strong>Invalid Credentials .</strong>
    </div>
<?php $_SESSION[mes]=0;}?>

	<?php include("includes/login-menu.php"); ?>
    
    <div class="container">
      <h3 class="page-header">Login</h3>
      <!-- Content Row -->
      <div class="row"> 
    <!-- Contact Details Column -->

              <div class="modal-body">
                <form class="form-horizontal iiiiiiiii" role="form" method="post" id="login" onsubmit="check_login()"  >
                  <div class="form-group">
                    <label for="inputEmail3" class="col-sm-2 control-label">Email</label>
                    <div class="col-sm-10">
                      <input type="text"  name="EMAIL" class="form-control" id="email" placeholder="Email">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputPassword3" class="col-sm-2 control-label">Password</label>
                    <div class="col-sm-10">
                      <input type="password"  name="PASSWORD"  class="form-control" id="password" placeholder="Password"       onkeyup="check_loginprasad()">
                      <input type="hidden" class="form-control"  name="EMAIL_MES"   id="email_mes">
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-sm-2"> </div>
                    <div class="col-sm-2">
                      <input type="submit" class="btn btn-primary" name="login"      value="Login"  />
                    </div>
                    <div class=" col-sm-3"> <a href="forget.php"> Forgot Password</a> </div>
                    
                  </div>
                </form>
              </div>
            </div>
    <!-- Map Column -->
    
  </div>
    
</div>
    
	    <?php include("includes/footer.php"); ?>


	
    
</body>
</html>
<script src="js/wow.js"></script>
<script>
new WOW().init();
</script>