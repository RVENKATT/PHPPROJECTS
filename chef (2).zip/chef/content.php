<?php
session_start();
ob_start();
error_reporting(0);
include('includes/products-management.php');

$dbFactory= new ProductsManagement();
echo $_SESSION[user_id];
 ?>


<!DOCTYPE  html>
<html lang="en">

<head>
  <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>DeleciousAndhra</title>


    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="css/animate.css" type="text/css">
	<link rel="stylesheet" href="font-awesome-4.2.0/css/font-awesome.min.css" type="text/css">
    
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script> 
    <script src="js/bootstrap.min.js"></script> 
    <script src="js/scripts.js"></script>
    <!-- Just include this Js file -->
	<script src="./js/jquery.carousel.fullscreen.js"></script>
</head>


<body>
<?php if($_REQUEST[mes]==1){ ?>
 <div class="alert alert-success" style="margin:10px">
        <a href="#" class="close" data-dismiss="alert">&times;</a>
        <strong>Success!</strong> Check your mail and complete the registration get free Delicious meal on first day. and get more offers..
    </div>
<?php }?>
	<?php /*?><div class="mani_slide">
    <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
		<!-- Indicators -->
		<ol class="carousel-indicators">
			<li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
			<li data-target="#carousel-example-generic" data-slide-to="1"></li>
			<li data-target="#carousel-example-generic" data-slide-to="2"></li>
		</ol>

		<!-- Wrapper for slides -->
		<div class="carousel-inner">
         <?php $s=$dbFactory->banner_image();
 // echo count($s);
	for($i=0;$i<count($s);$i++)
	{?>
			<div class="item <?php  if($i==0){?>active <?php }?>">
				<img src="admin/banner_images/<?php echo $s[$i][BANNER_IMG_ID];?>.png" alt="" />
				<div class="container">
					<div class="carousel-caption wow pulse">
						<h1 class="brand_name " style="visibility: visible;">
						<a href="./">DeleciousAndhra</a>
						</h1>
						<p class="brand_slogan">premium cuisine </p>
					</div>
				</div>
			</div>
<?php }?>
			
		</div>

		<!-- Controls -->
		<a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
			<span class="glyphicon glyphicon-chevron-left"></span>
		</a>
		<a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
			<span class="glyphicon glyphicon-chevron-right"></span>
		</a>
	</div>
    </div><?php */?>
	<?php include("includes/menu.php"); ?>
	<section class="well bg-section slideInLeft wow">
    <?php $a=$dbFactory->content($_REQUEST[id]);
	?>
	<div class="container ac">
	<h2 class="h2__mod1"><?php echo $a[0][MENU_TITLE]?></h2>
	<p class="p__mod">
	<?php echo $a[0][MENU_DES]?>
	</p>
	<!--<a class="btn" href="#">More</a>-->
	</div>
	</section>
    


    <?php include("includes/footer.php"); ?>

	
    
</body>
</html>
<script src="js/wow.js"></script>
<script>
new WOW().init();
</script>