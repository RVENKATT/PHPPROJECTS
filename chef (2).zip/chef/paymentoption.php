<?php

	session_start();
	ob_start();

	error_reporting(0);

	include('includes/products-management.php');

	$dbFactory= new ProductsManagement();
	?><div class="tab-pane fade" id="settings" >
              <h2>Payment Options</h2>
              <div style="color:#F36E2B; font-weight:bold">Hello <?php echo $_SESSION[user_name];?>, Total Amount to be Paid: RS.<?php echo $_SESSION[total]; ?></div>
              <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6" style="text-align:center;">
                <form action="usertransactions.php" method="post" id="cash">
                
          
                  <input name="oldaddress" type="hidden" placeholder="name *"  id="oldaddress" />
                  
                  <input name="newship_name" type="hidden" placeholder="name *"  id="newship_name" />
                  <input name="newshippingaddress" type="hidden" placeholder="name *"  id="newshippingaddress" />
                  <input name="newship_city" type="hidden"  placeholder="City *"  id="newship_city"/>
                  <input name="newship_state" type="hidden"  placeholder="State/Province *"  id="newship_state"/>
                  <input name="newship_postal_code" type="hidden" placeholder="Postal Code *"  id="newship_postal_code"/>
                  <input name="newship_country" type="hidden" placeholder="name *"  id="newship_country" />
                     <input name="newdelivery_date" type="hidden" placeholder="name *"  id="newdelivery_date" />
                  <input name="newship_phone" type="hidden" placeholder="Telephone *" id="newship_phone"/>
                  <button type="submit" name="confirm" value="" style="border:none; background:none"> <img src="images/Cash-on-Delivery-Icon1.png" class="img-responsive" ></button>
                </form>
              </div>
              <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6" style="text-align:center; border-left:1px solid #ddd;"> 
			  
			         <form action="ebs/secure.php" method="post" id="cash">
                 
                  <input name="oldaddress1" type="hidden" placeholder="name *"  id="oldaddress1" />
                     
                     
                     
                   <input name="newship_name1" type="hidden" placeholder="name *"  id="newship_name1" />
                  <input name="newshippingaddress1" type="hidden" placeholder="name *"  id="newshippingaddress1" />
                  <input name="newship_city1" type="hidden"  placeholder="City *"  id="newship_city1"/>
                  <input name="newship_state1" type="hidden"  placeholder="State/Province *"  id="newship_state1"/>
                  <input name="newship_postal_code1" type="hidden" placeholder="Postal Code *"  id="newship_postal_code1"/>
                  <input name="newship_country1" type="hidden" placeholder="name *"  id="newship_country1" />
                     <input name="newdelivery_date1" type="hidden" placeholder="name *"  id="newdelivery_date1" />
                  <input name="newship_phone1" type="hidden" placeholder="Telephone *" id="newship_phone1"/>
                  <button type="submit" name="confirm" value="" style="border:none; background:none"> <img src="images/onlinepayment.jpg" class="img-responsive" ></button>
                </form>
                <!--<p>For EBS Online payment Click on EBS Payment </p>--> 
              </div>
            </div>