<?php
session_start();
ob_start();
error_reporting(0);
include('includes/products-management.php');

$dbFactory= new ProductsManagement();

$var="home";


 ?>


<!DOCTYPE  html>
<html lang="en">

<head>
  <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>DeleciousAndhra</title>


    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="css/animate.css" type="text/css">
	<link rel="stylesheet" href="font-awesome-4.2.0/css/font-awesome.min.css" type="text/css">
    
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script> 
    <script src="js/bootstrap.min.js"></script> 
    <script src="js/scripts.js"></script>
    <!-- Just include this Js file -->
	<script src="./js/jquery.carousel.fullscreen.js"></script>
</head>


<body onLoad="checkpopup(<?php echo $_REQUEST[d]; ?>)">
<?php if($_SESSION[mes]==1){ ?>
 <div class="alert alert-success" style="margin:10px">
        <a href="#" class="close" data-dismiss="alert">&times;</a>
        <strong>Success!</strong> Check your mail and complete the registration get free Delicious meal on first day. and get more offers..
    </div>
<?php $_SESSION[mes]=0;}?>
<?php if($_SESSION[mes]==2){ ?>
 <div class="alert alert-success" style="margin:10px">
        <a href="#" class="close" data-dismiss="alert">&times;</a>
        <strong>Invalid Credentials</strong> 
    </div>
<?php $_SESSION[mes]=0;}?>
	<div class="mani_slide">
    <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
		<!-- Indicators -->
		<ol class="carousel-indicators">
			<li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
			<li data-target="#carousel-example-generic" data-slide-to="1"></li>
			<li data-target="#carousel-example-generic" data-slide-to="2"></li>
		</ol>

		<!-- Wrapper for slides -->
		<div class="carousel-inner">
         <?php $s=$dbFactory->banner_image();
 // echo count($s);
	for($i=0;$i<count($s);$i++)
	{?>
			<div class="item <?php  if($i==0){?>active <?php }?>">
				<img src="admin/banner_images/<?php echo $s[$i][BANNER_IMG_ID];?>.png" alt="" />
				<div class="container">
					<div class="carousel-caption wow pulse">
						<h1 class="brand_name " style="visibility: visible;">
						<img src="images/logo.png" style=" padding:20px 0px;"><br><a href="./">DeleciousAndhra</a>
						</h1>
						<p class="brand_slogan">premium cuisine </p>
					</div>
				</div>
			</div>
<?php }?>
			
		</div>

		<!-- Controls -->
		<a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
			<span class="glyphicon glyphicon-chevron-left"></span>
		</a>
		<a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
			<span class="glyphicon glyphicon-chevron-right"></span>
		</a>
	</div>
    </div>
	
	<?php include("includes/menu.php"); ?>
    
        
    <section class="well bg-section slideInLeft wow">
    <?php $a=$dbFactory->aboutus();
	?>
	<div class="container ac">
	<h2 class="h2__mod1"><?php echo $a[0][ABOUTUS_TITLE]?></h2>
	<div class="p__mod">
	<?php echo $a[0][ABOUTUS_DES]?>
	</div>
	<a class="btn" href="content.php?id=79">More</a>
	</div>
	</section>
    
    <section class="well2"  id="recipes">
    <div class="container">
	<div class="row">
    <?PHP $p=$dbFactory->product();
 // echo count($s);
	for($i=0;$i<count($p);$i++)
	{?>
	<div class="col-sm-4 col-md-4 col-lg-4 rollIn wow" style="visibility: visible;">
		<article class="article-info border1" data-equal-group="1">
		<div class="box_inner">
		<h3><a href="recipes.php?part=<?php echo $i+1?>" style="cursor:pointer"><?php echo $p[$i][PRODUCT_TITLE];?></a></h3>
		<!--<img alt="" src="admin/product/<?php echo $p[$i][PRODUCT_ID];?>.jpeg" class="img-responsive">-->
		<div class="mani_slide">
    
	<div id="carousel-example-generic<?php echo $i?>" class="carousel slide" data-ride="carousel">
		<!-- Wrapper for slides -->
		<div class="carousel-inner">
         <?php $t=59+$i; 
		 $s=$dbFactory->internal_item($t);
 // echo count($s);
	for($j=0;$j<count($s);$j++)
	{?>
			<div class="item <?php  if($j==0){?>active <?php }?>">
				<img src="admin/images/<?php echo $s[$j][PIC_ID];?>.jpg">
			</div>
<?php }?>
			
		</div>

		<!-- Controls -->
		<a class="left carousel-control" href="#carousel-example-generic<?php echo $i?>" data-slide="prev">
			<span class="glyphicon glyphicon-chevron-left"></span>
		</a>
		<a class="right carousel-control" href="#carousel-example-generic<?php echo $i?>" data-slide="next">
			<span class="glyphicon glyphicon-chevron-right"></span>
		</a>
	</div>
    </div>
	
		
		
<!--		<h6 class="mar_top">Seius modi tempora incidunut labore et dolore.</h6>-->
		<div class="mar_top" style="height:160px; text-align:justify"><?php echo $p[$i][PRODUCT_DES];?></div>
		<!--<a class="btn btn__mod1 mar_top" href="#">More</a>-->
			<a class="btn" href="recipes.php?part=<?php echo $i+1?>">&nbsp;>>&nbsp;More</a>
		</div>
		</article>
	</div>
    <?php }?>
	
	</div>
	</div>
	</section>
    <section class="well3 bg-section ">
	<div class="container">
	<div class="box box__mod1">
	<h3 class="fl">Newsletter Sign Up</h3>
		<form id="subscribe-form" class="subscribe-form">
		<label class="email" >
		<input type="email" class="fl" value="enter your e-mail">
		
		</label>
		<a href="#" class="fr" data-type="submit">Subscribe</a>
		</form>
	</div>
	<!--<div class="row mr_top">
		<?php $p=$dbFactory->gallery();
 // echo count($s);
	for($i=0;$i<count($p);$i++)
	{?><ul class="post-list col-sm-6 col-md-6 col-lg-6 wow bounceInRight">
      
			  <li class="box">
			<div class="fl">
			<time datetime="2015-03-23">
			<span><?php $today=date_create($p[$i][DATE]); 
							echo date_format($today,"j");?></span>
            <br>
			<em><?PHP echo date_format($today,"F");?></em>
			</time>
			</div>
			<div class="box_cnt__no-flow">
			<h4><?php echo $p[$i][CONTENT];?></h4>
			<a class="btn2" href="#">Read more</a>
			</div>
			</li><BR><BR><BR><BR><BR><BR>
			
		</ul><?php }?>
            
		
        
        
	</div>-->
	</div>
	</section>
    
    <section class="well4 bg-section2">
	<div class="container">
	<div class="row">
    <?php $f=$dbFactory->popular();
	for($i=0;$i<count($f);$i++)
	{?>
		<div class="col-sm-3 col-md-3 col-lg-3 block3 wow fadeIn fadeInLeft animated" style="visibility: visible; animation-name: fadeInLeft;">
		<h3><?php echo $f[$i][POPULAR_TITLE];?></h3>
		<?php echo $f[$i][POPULAR_DES];?>
		<?php if($i==0){?>
		<a class="btn btn__ins4" href="recipes.php#1">More</a>
		<?php }?>
		<?php if($i==1){?>
		<a class="btn btn__ins4" href="contact.php">More</a>
		<?php }?>
		
		</div>
		<div class="img__mod col-sm-3 col-md-3 col-lg-3">
		<img alt="" src="admin/product/<?php echo $f[$i][POPULAR_ID];?>.jpeg">
		</div>
        <?php }?>
		<!--<div class="col-sm-3 col-md-3 col-lg-3 block3 wow fadeIn fadeInRight animated" style="visibility: visible; animation-name: fadeInRight;">
		<h3>special offer</h3>
		<p>Daesarfaes setyera krscaertrsa aoertayse squrem ipsum quiertyaodeas laseceras vasptai a dolor. Vsanamet, consect di tempora miaser.</p>
		<a class="btn btn__mod4" href="#">More</a>
		</div>
		<div class="img__mod col-sm-3 col-md-3 col-lg-3">
		<img alt="" src="images/page-1_img05.jpg">
		</div>-->
	</div>
	</div>
	</section>
    
    
    <!--<section class="well5 parallax" data-mobile="true" data-url="images/page-1_parallax1.jpg" style="visibility: visible; animation-name: fadeInUp;">
	<div class="parallax_image" style="background:url(images/page-1_parallax1.jpg); height: 500px; transform: translate3d(0px, -18.5438px, 0px);"></div>
	<div class="parallax_cnt">
	<div class="container center">
	<h2>Top<br><span>Desserts</span></h2>
	<p class="p__skin color__mod1">Ceplicaboserde miuas nerafae kertyerauas vitaesa eniptaiad esertyatya nemo </p>
	<a class="btn3" href="#">More</a>
	</div>
	</div>
 	</section>
    
    -->
    <?php include("includes/footer.php"); ?>




	
    
</body>
</html>


					
			    </div> 
      </div>
      <div class="modal-footer" style="color:#666666">
	  </div>
    </div>
  </div>
</div>
      



      


<script src="js/wow.js"></script>
<script>
new WOW().init();
</script>


