<?php
session_start();
ob_start();
error_reporting(0);
include('includes/products-management.php');

$dbFactory= new ProductsManagement();
echo $_SESSION[user_id];
if(isset($_REQUEST[submit]))
{

$x="andhradeliciouscontactus@gmail.com,anand@friendsfocus.in";

   $link='
   <p> User Contact Details </p>

<table width="800" cellspacing="5" cellpadding="5"  bgcolor="#f2f2f">

          <tr  bgcolor="#fff">

 <td>User Name:</td><td>'.$_REQUEST[USERNAME].'</td>

          </tr>
               <tr  bgcolor="#fff">

 <td>Email:</td><td>'.$_REQUEST[EMAIL].'</td>

          </tr>
		   <tr  bgcolor="#fff">

 <td>Phone:</td><td>'.$_REQUEST[PHONE].'</td>

          </tr>
		  
		   <tr  bgcolor="#fff">

 <td>Country:</td><td>'.$_REQUEST[country].'</td>

          </tr>
		   <tr  bgcolor="#fff">

 <td>Message:</td><td>'.$_REQUEST[MESSAGE].'</td>

          </tr>
		  
		  <table>';
   
   
   

       $from="WebContact";

   $msg = wordwrap($link,70);
   $headers ='MIME-Version: 1.0' . "\r\n";

$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

$headers .= "From: $from";



// send email

mail("$x","$x",$link,$headers);

$_SESSION[mes]=1;
 header("location:contact.php?mes=1");   
exit(0);

 


}


 ?>


<!DOCTYPE  html>
<html lang="en">

<head>
  <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>DeleciousAndhra</title>


    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="css/animate.css" type="text/css">
	<link rel="stylesheet" href="font-awesome-4.2.0/css/font-awesome.min.css" type="text/css">
    
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script> 
    <script src="js/bootstrap.min.js"></script> 
    <script src="js/scripts.js"></script>
    <!-- Just include this Js file -->
	<script src="./js/jquery.carousel.fullscreen.js"></script>
    <style>
#map-canvas {
	width: 100%;
	height: 320px;
}
</style>
</head>


<body>
<?php if($_REQUEST[mes]==1){ ?>
 <div class="alert alert-success" style="margin:10px">
        <a href="#" class="close" data-dismiss="alert">&times;</a>
        <strong>Success!</strong> Check your mail and complete the registration get free Delicious meal on first day. and get more offers..
    </div>
<?php }?>
	<?php /*?><div class="mani_slide">
    <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
		<!-- Indicators -->
		<ol class="carousel-indicators">
			<li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
			<li data-target="#carousel-example-generic" data-slide-to="1"></li>
			<li data-target="#carousel-example-generic" data-slide-to="2"></li>
		</ol>

		<!-- Wrapper for slides -->
		<div class="carousel-inner">
         <?php $s=$dbFactory->banner_image();
 // echo count($s);
	for($i=0;$i<count($s);$i++)
	{?>
			<div class="item <?php  if($i==0){?>active <?php }?>">
				<img src="admin/banner_images/<?php echo $s[$i][BANNER_IMG_ID];?>.png" alt="" />
				<div class="container">
					<div class="carousel-caption wow pulse">
						<h1 class="brand_name " style="visibility: visible;">
						<a href="./">DeleciousAndhra</a>
						</h1>
						<p class="brand_slogan">premium cuisine </p>
					</div>
				</div>
			</div>
<?php }?>
			
		</div>

		<!-- Controls -->
		<a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
			<span class="glyphicon glyphicon-chevron-left"></span>
		</a>
		<a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
			<span class="glyphicon glyphicon-chevron-right"></span>
		</a>
	</div>
    </div><?php */?>
	
	<?php include("includes/menu.php"); ?>
    
    <div class="container">
      <h3 class="page-header">Get In Touch</h3>
      <!-- Content Row -->
      <div class="row"> 
    <!-- Contact Details Column -->
    <div class="col-md-4"> 
          
          <!-- Contact Form -->

<h5>Contact us any requests, complaints, suggestions and for Corporate parties and functions</h5>

          <form  id="register" class="righteous-box"  method="post"  novalidate>
        <div class="control-group form-group">
              <div class="controls">
           
            <input type="text" class="form-control" placeholder="Full Name" name="USERNAME" required data-validation-required-message="Please enter your name.">
            <p class="help-block"></p>
          </div>
            </div>
        <div class="control-group form-group">
              <div class="controls">
           
            <input type="text" class="form-control"  name="COMPANY" placeholder="Company Name" required data-validation-required-message="Please enter your company name.">
            <p class="help-block"></p>
          </div>
            </div>
        <div class="control-group form-group">
              <div class="controls">
           
            <input type="email" class="form-control"  name="EMAIL" placeholder="Email Address" required data-validation-required-message="Please enter your email address.">
          </div>
            </div>
        <div class="control-group form-group">
              <div class="controls">
           
            <input type="tel" class="form-control"  name="PHONE" placeholder="Phone Number" required data-validation-required-message="Please enter your phone number.">
          </div>
            </div>
            
              <div class="control-group form-group">
              <!--<div class="controls">
           
  <select name="COUNTRY" class="form-control">
        <option value="91" selected="selected">India</option>
		</select>
</div>-->
            </div>
        <div class="control-group form-group">
              <div class="controls">
           
            <select  class="form-control"  name="SUBJECT">
			<option value="Request">Request</option>
			<option value="Compliant">Compliant</option>
			<option value="Suggestion">Suggestion</option>
			<option value="Corporate parties or functions">Corporate parties or functions</option>
			<option value="Message">Message</option>
			</select>
			<p class="help-block"></p>
          </div>
            </div>
        <div class="control-group form-group">
              <div class="controls">
          
            <textarea  class="form-control"  name="MESSAGE" placeholder="Message" required data-validation-required-message="Please enter your message" style="resize:vertical;" ></textarea>
          </div>
            </div>
            
        <div id="success"></div>
        <!-- For success/fail messages -->
        <button type="submit" name="submit" class="btn btn-success pull-right">Submit</button>
      </form>
          <br />
          <br />
        </div>
    <!-- Map Column -->
    <div class="col-md-8"> 
<h3>for Corporate parties, functions please visit our available  menu items <a href="recipes.php"> <strong>Recipes</strong></a>.</h3>
          <!-- Embedded Google Map --> 
          <script src="https://maps.googleapis.com/maps/api/js"></script> 
          <script>
      function initialize() {

		var mapCanvas = document.getElementById('map-canvas');
        var mapOptions = {
          center: new google.maps.LatLng(17.379288100600064,78.47877502441406),
          zoom: 13,
          mapTypeId: google.maps.MapTypeId.ROADMAP
        }
        var map = new google.maps.Map(mapCanvas, mapOptions)
      }
      google.maps.event.addDomListener(window, 'load', initialize);
 function step2() {
		var mapCanvas = document.getElementById('map-canvas');
        var mapOptions = {
          center: new google.maps.LatLng(12.965371521548716,77.5909423828125),
          zoom: 13,
          mapTypeId: google.maps.MapTypeId.ROADMAP
        }
        var map = new google.maps.Map(mapCanvas, mapOptions)
      }
     
    </script>
          <div id="map-canvas" class="righteous-box"></div>
          
        <div class="col-md-6 righteous-address" onClick="initialize()">
              <p  style="background:#f2f2f2; padding:15px; margin:15px 0 0 -15px;"><strong>Delecious Andhra</strong> <br />
            <br />
			Hyderabad
           </p>
            </div> 
        <div class="col-md-6 righteous-address" onClick="step2()" >
              <p  style="background:#f2f2f2; padding:15px; margin:15px -15px; 0 0"><strong>Delecious Andhra</strong> <br />
            <br />
            Banglore</p>
            </div>
        </div>
  </div>
    
</div>
    
	    <?php include("includes/footer.php"); ?>


	
    
</body>
</html>
<script src="js/wow.js"></script>
<script>
new WOW().init();
</script>