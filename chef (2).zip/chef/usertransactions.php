<?php
	session_start();
	ob_start();
	error_reporting(0);
	include('includes/products-management.php');
	
	$dbFactory= new ProductsManagement();
		
	
	unset($_SESSION[processs_fim]);
	?>
    <?php
	

   for($i=0;$i<count($_SESSION[products]);$i++){
  $product_val=$dbFactory->details_item($_SESSION[products][$i]);
 // $title=$dbFactory->admin_material($product_val[0][PRODUCT_TITLE]);
  
   $product_val[0][USER_ID];
  $vendor_ids[]=$product_val[0][USER_ID];
  
  
 // $product_img_del=$dbFactory->product_images($_SESSION[products][$i]);

 
$t=$t.' <tr><td>'.($i+1).'</td><td>PID'.$product_val[0][PIC_ID].'</td>
          
            <td><img width="50" src="http://mytestwebsite.in/chef/admin/images/'. $product_val[0][PIC_ID].'.jpg"  class="img-responsive"/>
			</td>
            <td>'.$product_val[0][IMG_NAME].'<br>'.$_SESSION[fieldvalues][$i].'</td>
            <td>'.$product_val[0][COST].'</td>
            
			
          </tr>';
	   }
		//   print_r($vendor_ids);
		   $vendor_ids=array_unique($vendor_ids);
		      $vendor_ids=array_values($vendor_ids);
		   
		  // print_r($vendor_ids);
		   
     // print_r($_SESSION[products]);

$s='<table width="800" cellspacing="5" cellpadding="5"  bgcolor="#f2f2f">
          <tr  bgcolor="#fff">
            <th>Sl No</th>
            <th>Product ID</th>
            <th>Preview</th>
            <th>Title</th>
          
           
            <th>Cost <br/ > (Rs)</th>
          </tr>'.$t.'
          <tr>
            <td colspan="5" align="right">
      <strong></strong>
	  </td>
            <td colspan="3" align="right" style="font-size:16px; text-align:right;"> Total Amount='. $_SESSION[total].'</td>
          </tr>
		            <tr>
            
            <td colspan="3" align="right" style="font-size:16px; text-align:right;"></td>
          </tr>

		  </table>

';
 $to = $_SESSION[user_email];
 
 $subject="Invoice ";
 $message= $s;
$from = "transaction@deliciousandhra.com";
$headers ='MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= "From: $from";


mail($to,$subject,$message,$headers);
mail('mahesh@palvs.com',$subject,$message,$headers);

//transation

//set the random id length 
$random_id_length = 10; 
//generate a random id encrypt it and store it in $rnd_id 
$rnd_id = crypt(uniqid(rand(),1)); 
//to remove any slashes that might have come 
$rnd_id = strip_tags(stripslashes($rnd_id)); 
//Removing any . or / and reversing the string 
$rnd_id = str_replace(".","",$rnd_id); 
$rnd_id = strrev(str_replace("/","",$rnd_id)); 
//finally I take the first 10 characters from the $rnd_id 
$rnd_id = substr($rnd_id,0,$random_id_length); 
 $rnd_id; 


	if($_REQUEST[oldaddress]!='')
{
	 $t=$dbFactory->transaction_add($rnd_id,$_SESSION[user_id],$_SESSION[total],count($_SESSION[products]),$_REQUEST[oldaddress],$_REQUEST[newdelivery_date]);


 
	 
	 
   for($i=0;$i<count($_SESSION[products]);$i++)
   {
	   
	      $ss=$dbFactory->details_item($_SESSION[products][$i]);
		   
	$dbFactory->transaction_detail_add($t,$_SESSION[products][$i],$_SESSION[qnty][$i],$_SESSION[fieldvalues][$i],$_SESSION[messag][$i],$_SESSION[cities][$i],$ss[0][VENDOR_ID]);
	
	
   }
   
}
else
{
	
		 $t=$dbFactory->transaction_add($rnd_id,$_SESSION[user_id],$_SESSION[total],count($_SESSION[products]),0,$_REQUEST[newdelivery_date]);
	$newshippingaddress=mysql_escape_string($_REQUEST[newshippingaddress]);

	 $shipp=$dbFactory->ship_add($_REQUEST[newship_name],$newshippingaddress,$_REQUEST[newship_city],$_REQUEST[newship_state],$_REQUEST[newship_postal_code],$_REQUEST[newship_country],$_REQUEST[newship_phone],$t,$_SESSION[user_id]);
	 
	 
	 
   for($i=0;$i<count($_SESSION[products]);$i++)
   {
	   
	      $ss=$dbFactory->details_item($_SESSION[products][$i]);
		    
	$dbFactory->transaction_detail_add($t,$_SESSION[products][$i],$_SESSION[qnty][$i],$_SESSION[fieldvalues][$i],$_SESSION[messag][$i],$_SESSION[cities][$i],$ss[0][VENDOR_ID]);
	
	
	
   }
	
	
	}


     for($i=0;$i<count($vendor_ids);$i++)
   {
	     if($vendor_ids[$i]==0)continue;
		  $sss=$dbFactory->user_details($vendor_ids[$i]);
		   $to=$sss[0][EMAIL];
	mail($to,$subject,$message,$headers);
	
   }
   
$_SESSION[products] = '';
$_SESSION[qnty] = '';
$_SESSION[messag] = '';
$_SESSION[cities] = '';
$_SESSION[fieldvalues] = '';
$_SESSION[total]=0;
$_SESSION[price_details]='';
$_SESSION[price_id]='';
$_SESSION[price_title]='';

?>
<?php unset($_SESSION[products]);
header("location:thanks.php");?>


