<?php

	session_start();

	ob_start();

	error_reporting(0);



	include('includes/products-management.php');

	$dbFactory= new ProductsManagement();

if(isset($_POST[reset]))

{



$check=$dbFactory->registeruser_reset($_POST['PASSWORD'],$_POST['USER_ID']);



   


$_SESSION[mes]=1;
 header("location:reset.php");
exit(0);
}

?>
<!DOCTYPE  html>
<html lang="en">

<head>
  <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>DeleciousAndhra</title>


    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="css/animate.css" type="text/css">
	<link rel="stylesheet" href="font-awesome-4.2.0/css/font-awesome.min.css" type="text/css">
    
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script> 
    <script src="js/bootstrap.min.js"></script> 
    <script src="js/scripts.js"></script>
    <!-- Just include this Js file -->
	<script src="./js/jquery.carousel.fullscreen.js"></script>
    <style>
#map-canvas {
	width: 100%;
	height: 320px;
}
</style>
</head>


<body>
<div style="display:none;<?php if($_SESSION[mes]==1){?>display:block<?php $_SESSION[mes]=0;}?>">

      <div class="alert alert-dismissable alert-success">

        <button type="button" class="close" data-dismiss="alert">&#x2715;</button>

        <strong>Password  Successfully Updated Please Login.</strong> </div>

    </div>

	<?php /*?><div class="mani_slide">
    <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
		<!-- Indicators -->
		<ol class="carousel-indicators">
			<li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
			<li data-target="#carousel-example-generic" data-slide-to="1"></li>
			<li data-target="#carousel-example-generic" data-slide-to="2"></li>
		</ol>

		<!-- Wrapper for slides -->
		<div class="carousel-inner">
         <?php $s=$dbFactory->banner_image();
 // echo count($s);
	for($i=0;$i<count($s);$i++)
	{?>
			<div class="item <?php  if($i==0){?>active <?php }?>">
				<img src="admin/banner_images/<?php echo $s[$i][BANNER_IMG_ID];?>.png" alt="" />
				<div class="container">
					<div class="carousel-caption wow pulse">
						<h1 class="brand_name " style="visibility: visible;">
						<a href="./">DeleciousAndhra</a>
						</h1>
						<p class="brand_slogan">premium cuisine </p>
					</div>
				</div>
			</div>
<?php }?>
			
		</div>

		<!-- Controls -->
		<a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
			<span class="glyphicon glyphicon-chevron-left"></span>
		</a>
		<a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
			<span class="glyphicon glyphicon-chevron-right"></span>
		</a>
	</div>
    </div><?php */?>
	
	<?php include("includes/menu.php"); ?>
    
    <div class="container">
      <h3 class="page-header">Reset Password</h3>
      <!-- Content Row -->
      <div class="row"> 
    <!-- Contact Details Column -->
    <div class="col-md-4"> 
          
          <!-- Contact Form -->


         <form class="form1" id=""  method="post">
        <div class="control-group form-group">
              <div class="controls">
           
  <input type="password" name="PASSWORD" class="form-control" >


            <input type="hidden" name="USER_ID" class="form-control" id=""  value="<?php echo $_REQUEST[id];?>">
                       <p class="help-block"></p>
          </div>
            </div>
       
             
        <div id="success"></div>
        <!-- For success/fail messages -->
    <input name="reset" type="submit" class="btn btn-warning" id="button " value="Reset">
      </form>
          <br />
          <br />
        </div>
    <!-- Map Column -->
    
  </div>
    
</div>
    
	    <?php include("includes/footer.php"); ?>


	
    
</body>
</html>
<script src="js/wow.js"></script>
<script>
new WOW().init();
</script>