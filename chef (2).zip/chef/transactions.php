<?php

	session_start();
	ob_start();

	error_reporting(0);

	include('includes/products-management.php');

	$dbFactory= new ProductsManagement();



?>
<!DOCTYPE  html>
<html lang="en">

<head>
  <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>DeleciousAndhra</title>


    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="css/animate.css" type="text/css">
	<link rel="stylesheet" href="font-awesome-4.2.0/css/font-awesome.min.css" type="text/css">
    
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script> 
    <script src="js/bootstrap.min.js"></script> 
    <script src="js/scripts.js"></script>
    <!-- Just include this Js file -->
	<script src="./js/jquery.carousel.fullscreen.js"></script>
    <style>
#map-canvas {
	width: 100%;
	height: 320px;
}
</style>
</head>


<body>
<?php if($_REQUEST[mes]==1){ ?>
 <div class="alert alert-success" style="margin:10px">
        <a href="#" class="close" data-dismiss="alert">&times;</a>
        <strong>Invalid Email .</strong>
    </div>
<?php }?>
<?php if($_REQUEST[mes]==2){ ?>
 <div class="alert alert-success" style="margin:10px">
        <a href="#" class="close" data-dismiss="alert">&times;</a>
        <strong>Check your Email For Password .</strong>
    </div>
<?php }?>
	<?php /*?><div class="mani_slide">
    <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
		<!-- Indicators -->
		<ol class="carousel-indicators">
			<li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
			<li data-target="#carousel-example-generic" data-slide-to="1"></li>
			<li data-target="#carousel-example-generic" data-slide-to="2"></li>
		</ol>

		<!-- Wrapper for slides -->
		<div class="carousel-inner">
         <?php $s=$dbFactory->banner_image();
 // echo count($s);
	for($i=0;$i<count($s);$i++)
	{?>
			<div class="item <?php  if($i==0){?>active <?php }?>">
				<img src="admin/banner_images/<?php echo $s[$i][BANNER_IMG_ID];?>.png" alt="" />
				<div class="container">
					<div class="carousel-caption wow pulse">
						<h1 class="brand_name " style="visibility: visible;">
						<a href="./">DeleciousAndhra</a>
						</h1>
						<p class="brand_slogan">premium cuisine </p>
					</div>
				</div>
			</div>
<?php }?>
			
		</div>

		<!-- Controls -->
		<a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
			<span class="glyphicon glyphicon-chevron-left"></span>
		</a>
		<a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
			<span class="glyphicon glyphicon-chevron-right"></span>
		</a>
	</div>
    </div><?php */?>
	
	<?php include("includes/menu.php"); ?>
    
    <div class="container">
      <div class="table-responsive">
      <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%" style="background:#FFFFFF">
        <thead>
          <tr>
            <th>SNO</th>
            <th>KEY</th>
            <th>AMOUNT</th>
					<th>PAYMENT STATUS</th>
            <th>QUANTITY</th>
            <th>DATE</th>
            <th>STATUS</th> 
            <th></th>
          </tr>
        </thead>
        <tbody id="cat_tab_id">
          <?php

$s=$dbFactory->transaction($_SESSION[user_id]);

for($i=0; $i<count($s); $i++){

//if($d[$i][person]=='')continue;

?>
          <tr height="50px">
            <td><?php echo $i+1 ?></td>
            <td><?php echo $s[$i][TRANSACTION_KEY ];?></td>
            <td><?php echo $s[$i][AMOUT];?></td>
			
			<?php if($s[$i][PAYMENT_STATUS]==0){?><td>Not Paid</td><?php } else{?><td>Paid</td><?php }?>
			
			
            <td><?php echo $s[$i][PRODUCT];?></td>
            <?php 

	$tempDate =  $s[$i][ON_DATE ];

$day = date('l', strtotime( $tempDate));// will gives you the week day name 

$month = date('jS F Y',strtotime($tempDate));

	?>
            <td><?php echo $month;?></td>
                 <?php 
	   $alkd=$dbFactory->vendor_delevery_status_check($s[$i][TRANSACTION_ID]);
	   
	      $alkd1=$dbFactory->vendor_delevery_status_check_success($s[$i][TRANSACTION_ID]);
	   if($alkd==$alkd1){?> 
        <td><input type="button" class="btn btn-primary btn-xs" name="active" value="DELIVARY SUCCESS" /></form></td>
<?php } else{?>
        <td><form  method="post"><input type="hidden" name="TRANSACTION_ID" value="<?php echo $s[$i][TRANSACTION_ID]; ?>" />
<input type="hidden" name="VENDOR_ID" value="<?php echo $_SESSION[VENDOR_ID]; ?>" />
<input type="submit" class="btn btn-primary btn-xs" name="delevery_status" value="DELIVARY PENDING" /></form></td>
<?php }?>
            <td><span class="btn btn-primary btn-xs" data-toggle="modal" data-target="#myModal5" onClick="pop_function(<?php echo $s[$i][TRANSACTION_ID];?>)">View details</span></td>
          </tr>
          <?php }?>
        </tbody>
      </table>
      <?php if(count($s)==0){?><strong style="color:#F00">No Transactions<?php }?></strong>
      
    </div>
        <div class="modal fade bs-example-modal-lg" id="myModal5" tabusers="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true"> </div>

</div>
    
	    <?php include("includes/footer.php"); ?>


	<script type="text/javascript">

	function  pop_function(transation_id)

	{

	//menu loading

	//alert(transation_id);

$.post("ajax/view.php?TRANSACTION_ID="+transation_id,function(data){

//alert(data);



document.getElementById('myModal5').innerHTML=data;



});

	}

	</script>
    
</body>
</html>
<script src="js/wow.js"></script>
<script>
new WOW().init();
</script>