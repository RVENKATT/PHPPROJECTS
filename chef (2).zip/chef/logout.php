<?php

session_start();

//session_unset();



  unset($_SESSION['user_id']);

  unset($_SESSION[user_name]);

//  unset($_SESSION[products]);

//  unset($_SESSION[qnty]);

 // unset($_SESSION[practioner_id]);

  

ob_start();





header("location:./");

?>

