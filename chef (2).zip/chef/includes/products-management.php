<?php

/***************************************************************

* Author      : Anand

* Description : This is a DBFactory deals with model operations 

* Date        : 21-09-2011

****************************************************************/

include('connection-db.php');



class ProductsManagement

{

 

   /* This function connects to the database server and selects the database it deals with. */



	  function query($str)

	   {   

			$result=mysql_query($str);

			while($row=mysql_fetch_array($result))

			$output[]=$row;

			return $output;

	   }

	

	   function equery($str)

	   {   

			mysql_query($str);

	   }

	 

	   function count_query($str)

	   {

			$result=mysql_query($str);

			$row=mysql_num_rows($result);

			return $row;

	   }



		 //CATEGORIES

		 

	  function categories_detail($CATEGORY_ID)

		{

		$que="select * from categories where CATEGORY_ID='$CATEGORY_ID'";

		 $res=$this->query($que);

		 return $res;

		}

		

		 function categories()

	   {

		$str="select * from categories ";

	   $result=$this->query($str);

	   return $result;

	   }
	   
	   
	   
	   function content($MENU_ID)

	   {

		$str="select * from menu where MENU_ID='$MENU_ID' ";

	   $result=$this->query($str);

	   return $result;

	   }
	   
	   function image_gallery($MENU_ID)

	   {

		 $str="select * from images where MENU_ID=$MENU_ID  ";

	   $result=$this->query($str);

	   return $result;

	   }
	   
	    function banner_image()

	   {

		$que="select * from banner ORDER BY BANNER_ORDER";

	     return $this->query($que);

	   }



	    function featured_products()

	   {

		$str="select * from products where FEATURE=1  ";

	   $result=$this->query($str);

	   return $result;

	   }

		 function categories_menu($PARENT_ID)

	   {

		$str="select * from categories where PARENT_ID=$PARENT_ID";

	   $result=$this->query($str);

	   return $result;

	   }

	   

		   function parent_detail($PARENT_ID)

		{

		  $que="select * from categories where CATEGORY_ID='$PARENT_ID'";

		  $res=$this->query($que); 

			return $res;

		}		



	 //CATEGORIES

	
	//banner

	 function admin_banner()

    {

	//admin_banner.php

    $que="select * from banner ORDER BY BANNER_ORDER";

	return $this->query($que);

	}

	

	

	//MENU

	

	function menu_detail($MENU_ID)

	{

   $que="select * from menu where MENU_ID='$MENU_ID'";

	 $res=$this->query($que);

     return $res;

    }

	

	 function menu()

   {

    $str="select * from menu ";

   $result=$this->query($str);

   return $result;

   }

   



   function menu_delete($MENU_ID)

	{

	  $que="delete from menu where MENU_ID='$MENU_ID'";

	  $this->equery($que); 

    }

	   function menu_parent_detail($MENU_PARENT)

	{

	  $que="select * from menu where MENU_ID='$MENU_PARENT'";

	  $res=$this->query($que); 

	    return $res;

    }	

	

	 function menu_parent($MENU_PARENT)

	   {

	 $str="select * from menu where MENU_PARENT=$MENU_PARENT and MENU_OR_NOT=0 ORDER BY MENU_ORDER ";

	   $result=$this->query($str);

	   return $result;

	   }	




	//MENU

	
	
	
	function product_review($PRODUCT_ID)

	   {

		$str="select * from product_reviews where PRODUCT_ID=$PRODUCT_ID ";

	   $result=$this->query($str);

	   return $result;

	   }

 
    //SEARCH	
	function update_status($id,$state)
{
 $str="update products set status=$state where PRODUCT_ID=$id";
   $this->equery($str);
}

	
	 function banner()

    {

	//admin_banner.php

    $que="select * from banner ORDER BY BANNER_ORDER";

	return $this->query($que);

	}
function image()
   {
    $str="select * from menu ";
   $result=$this->query($str);
   return $result;
   }
function parent_detail1($MENU_ID)

		{

		  $que="select * from menu where MENU_TITLE='$MENU_ID'";

		  $res=$this->query($que); 

			return $res;

		}		
   function img_details($MENU_ID)

	   {

			 $str="select * from images where MENU_ID=$MENU_ID ";

	   $result=$this->query($str);

	   return $result;

	   }
	   
	   function product_details($PRODUCT_ID)

	   {

			  $str="select * from product where PRODUCT_ID=$PRODUCT_ID ";

	   $result=$this->query($str);

	   return $result;

	   }
	   
	   function gallery()

	   {

		$str="select * from gallery ";

	   $result=$this->query($str);

	   return $result;

	   }
	     
	   function popular()

	   {

		$str="select * from popular ";

	   $result=$this->query($str);

	   return $result;

	   }

function product_gallery()

	   {

		$str="select * from product_gallery  ";

	   $result=$this->query($str);

	   return $result;

	   }

	    function videos()

	   {

		 $str="select * from gallery where EXTERNAL_LINK!='' ";

	   $result=$this->query($str);

	   return $result;

	   }

function footer($FOOTER_ID)

	   {

		 $str="select * from footer where FOOTER_ID='$FOOTER_ID'  ";

	   $result=$this->query($str);

	   return $result;

	   }
function footers()

	   {

		 $str="select * from footer_img ";

	   $result=$this->query($str);

	   return $result;

	   }


	   function online()

	   {

		$str="select * from online ";

	   $result=$this->query($str);

	   return $result;

	   }
	   
	   
	 

function product()

	   {

		$str="select * from product ";

	   $result=$this->query($str);

	   return $result;

	   }
function aboutus()

	   {

		$str="select * from aboutus ";

	   $result=$this->query($str);

	   return $result;

	   }
	   
	   
	  
	
	 function menu_internal($id)

	   {

	$str="select * from menu_internal where MENU_ID='$id' ";

	   $result=$this->query($str);

	   return $result;

	   }

     function register($USER_NAME,$USER_EMAIL,$USER_MOBILE,$PASSWORD,$USER_ADDRESS,$FOODTYPE,$company )

    {
   //$pass=$_REQUEST[PASSWORD];
   $que="INSERT INTO users(`USER_NAME`, `USER_EMAIL`, `USER_MOBILE`, `USER_PASSWORD`, `USER_ADDRESS`, FOOD_TYPE,USER_COMPANY) VALUES ('$USER_NAME', '$USER_EMAIL', '$USER_MOBILE', '$PASSWORD', '$USER_ADDRESS','$FOODTYPE','$company')";

	$this->equery($que);

	return $pass;

	}
	
	 function registeruser_check($name,$password)

	 {

	//echo  "select * from register where EMAILID='$name' and PASSWORD='$password'";

     $str="select * from users where USER_EMAIL='$name' and USER_PASSWORD='$password'";

     $result=$this->query($str);

     return $result;

	 }



 function internal_item($PRODUCT_ID)

	 {
	
 $str="select * from images where PRODUCT_ID='$PRODUCT_ID'";

     $result=$this->query($str);

     return $result;

	 }
 function details_item($PIC_ID)

	 {
	
     $str="select * from images where PIC_ID='$PIC_ID'";

     $result=$this->query($str);

     return $result;

	 }
	 
	   function user_email_check($EMAIL)

	 {

     $str="select * from users where USER_EMAIL='$EMAIL'";



     $result=$this->query($str);



     return $result;



	 }
	 
	    function registeruser_forget($EMAIL)



	 {


    echo $str="select * from users where USER_EMAIL='$EMAIL' ";



     $result=$this->query($str);



     return $result;



	 }

	      function registeruser_reset($PASSWORD,$USER_ID)
	 {

     $str="update  users set USER_PASSWORD='$PASSWORD' where USER_ID=$USER_ID ";
     $result=$this->query($str);
     return $result;
	 }


	   function user_details($USER_ID )

    {

	//checkout.php

    $que="select * from users where USER_ID='$USER_ID'";

	return $this->query($que);

	}
	
	  function states_detail($STATE_ID)
	 {
		 
		     $str="select * from state_list where STATE_ID='$STATE_ID' ";



    $result=$this->query($str);


     return $result; 
		 
	 }
	   function state_country_id($country)
      {
     $str="select * from state_list where COUNTRY_ID='$country' order by STATE_NAME ASC";
       $result=$this->query($str);
       return $result;
      }
	  
	  
	  // TRANSACTIONS
	  
	  
	   function transaction_add($TRANSACTION_KEY,$USER_ID,$AMOUT,$PRODUCT,$ADDRESS_ID,$SHIPP_DELIVERY_DATE)

    {

  echo  $que="INSERT INTO transaction(TRANSACTION_KEY,USER_ID,AMOUT,PRODUCT,ADDRESS_ID,SHIPP_DELIVERY_DATE) VALUES('$TRANSACTION_KEY','$USER_ID','$AMOUT','$PRODUCT','$ADDRESS_ID','$SHIPP_DELIVERY_DATE')";
	$this->equery($que);
return mysql_insert_id();
}


 function ship_add($SHIPP_NAME,$SHIPP_ADDRESS,$SHIPP_CITY,$SHIPP_STATE,$SHIPP_POSTAL_CODE,$SHIPP_COUNTRY,$SHIPP_PHONE,$TRANSACTION_ID,$USER_ID)

    {

echo  $que="INSERT INTO addressdetails(SHIPP_NAME,SHIPP_ADDRESS,SHIPP_CITY,SHIPP_STATE,SHIPP_POSTAL_CODE,SHIPP_COUNTRY,SHIPP_PHONE,TRANSACTION_ID,USER_ID) VALUES('$SHIPP_NAME','$SHIPP_ADDRESS','$SHIPP_CITY','$SHIPP_STATE','$SHIPP_POSTAL_CODE','$SHIPP_COUNTRY','$SHIPP_PHONE','$TRANSACTION_ID','$USER_ID')";
	$this->equery($que);

}

 function transaction_add_online($TRANSACTION_KEY,$USER_ID,$AMOUT,$PRODUCT,$ADDRESS_ID,$SHIPP_DELIVERY_DATE)

    {

    $que="INSERT INTO transaction(TRANSACTION_KEY,USER_ID,AMOUT,PRODUCT,ADDRESS_ID,SHIPP_DELIVERY_DATE,PAYMENT_STATUS) VALUES('$TRANSACTION_KEY','$USER_ID','$AMOUT','$PRODUCT','$ADDRESS_ID','$SHIPP_DELIVERY_DATE',1)";
	$this->equery($que);
return mysql_insert_id();
}

   function transaction_detail_add($TRANSACTION_ID,$PRODCUT_ID,$QUANTITY,$INFO,$MESSAGE,$CITY,$VENDOR_ID)


    {


 echo  $que="INSERT INTO transaction_details(TRANSACTION_ID,PRODCUT_ID,QUANTITY,INFO,MESSAGE,CITY,VENDOR_ID) VALUES('$TRANSACTION_ID','$PRODCUT_ID','$QUANTITY','$INFO','$MESSAGE','$CITY','$VENDOR_ID')";

	$this->equery($que);

	return mysql_insert_id();

	}

     function transaction($USER_ID)
    {
    $que="select * from transaction where USER_ID=$USER_ID";
	return $this->query($que);
	}
	
     function transaction_detail($TRANSACTION_ID)
    {
    $que="select * from transaction_details where TRANSACTION_ID=$TRANSACTION_ID";
	return $this->query($que);
	}
	
	 function vendor_delevery_status_check($TRANSACTION_ID)
   {
    $str="select * from transaction_details where TRANSACTION_ID=$TRANSACTION_ID ";
   $result=$this->count_query($str);
   return $result;
   }
       	  	 function vendor_delevery_status_check_success($TRANSACTION_ID)
   {
    $str="select * from transaction_details where TRANSACTION_ID=$TRANSACTION_ID  and DELIVARY_STATUS=1";
   $result=$this->count_query($str);
   return $result;
   }

 function transaction_shipping($TRANSACTION_ID)

    {



   $que="select * from transaction where TRANSACTION_ID=$TRANSACTION_ID";

	return $this->query($que);

	}
	
	    function transaction_shipping_address($TRANSACTION_ID)

    {



   $que="select * from addressdetails where TRANSACTION_ID=$TRANSACTION_ID";

	return $this->query($que);

	}
 function address_old_details($USER_ID)

	   {

		$str="select * from addressdetails  where USER_ID=$USER_ID;";

	   $result=$this->query($str);

	   return $result;

	   }
	   
	   
	   	   	 function address_old_details_id($ADDRESS_ID)

	   {

		$str="select * from addressdetails  where ADDRESS_ID=$ADDRESS_ID;";

	   $result=$this->query($str);

	   return $result;

	   }
	   
	   
	 



}

?>

