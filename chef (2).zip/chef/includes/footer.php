<footer>
	<section class="well6 wow fadeIn fadeInUp animated" style="visibility: visible; animation-name: fadeInDown;">
	<div class="container">
	<div class="row">
		 <?php $t=$dbFactory->footer(1);
	echo $t[0][FOOTER_CONTENT];?>
		<div class="col-sm-5 col-md-5 col-lg-5">
		<ul class="inline-list social">
		<li><a class="fa fa-twitter" target="_blank" href="https://twitter.com/DeliciousAndhra"></a></li>
		<li><a class="fa fa-facebook" target="_blank" href="https://www.facebook.com/DeliciousAndhra"></a></li>
		<li><a class="fa fa-google-plus" href="#"></a></li>
		</ul>
		</div>
		 <?php $t=$dbFactory->footer(2);
	echo $t[0][FOOTER_CONTENT];?>
		</div>
	</div>
	</section>
	</footer>

    <script src="jquery.js"></script>
 <script type="text/javascript" src="jquery.validate.js"></script>

<script type="text/javascript">
/**
  * Basic jQuery Validation Form Demo Code
  * Copyright Sam Deering 2012
  * Licence: http://www.jquery4u.com/license/
  */
$(document).ready(function(){
   $("#form").validate({
     
        	rules: {

                    uname: "required",
					accept: "required",

                     LAST_NAME: "required",
					 JOURNAL_ID: "required",
					 EMAIL_MES: "required",

                    EMAIL: {

                        required: true,

                        email: true,
						  equalTo:"#email_mess"

                    },

                    password: {

                        required: true,

                        minlength: 6

                    },
					 CONFIRM_PASSWORD: {
                        minlength: 6,
						equalTo: "#PASSWORD"
                    },

					mobile: {

		required: true,

		minlength: 10

	}
	},



			messages: {



               uname: "Please enter your  name",
			   accept: "Please accept terms and conditions",
			   CONFIRM_PASSWORD: {
				   
				   required: "Confirm Your Password", 
				   minlength: "Password do not match"
			   },

                    LAST_NAME: "Please enter your last name",

                    password: {

                        required: "Please provide a password",

                        minlength: "Your password must be at least 6 characters long"

                    },

                    EMAIL: {



					required: "please enter email",



					email: "please enter a valid email address",



					 equalTo:""



				},


					mobile: {

		required: "Please provide a phone no",

		minlength: "please enter minmum lenth 10 numbers"

	}


         }
     });
});
	
</script>
<style>

#form label.error {
color:red;
}

#form select.error {
border:1px solid red;
}
 .myErrors {
  color:red;
 }




</style>
<script>
function check_email(s)
{
path="ajax/email-check.php?email="+s;
//alert(path);
x=document.getElementById('emailregister').value;
$.post( path,function( data ) {
//$( ".result" ).html( data );
//alert(data);

if(data==1)
{
	//alert("prasad");
document.getElementById('email_mess').value='';

document.getElementById('email_status').innerHTML="Email Already Exists";

}
if(data==0)
{
document.getElementById('email_mess').value=x;
document.getElementById('email_status').innerHTML="";
}
});
//alert(y);
}</script>
<SCRIPT language=Javascript>
<!--
function isNumberKey(evt)
{
var charCode = (evt.which) ? evt.which : event.keyCode
//alert(charCode);
if (charCode > 31 && (charCode < 48 || charCode > 57))
return false;

return true;
}
//-->
</SCRIPT>

<script>

	$().ready(function() {

		// validate the comment form when it is submitted

		// validate signup form on keyup and submit

 

		$("#login").validate({

			rules: {
			EMAIL: {

					required: true,
					email: true
                   
					

				},

				PASSWORD: {

					required: true,
					 equalTo:"#email_mes"
					
				},

			},
			messages: {
					EMAIL: {

					required: "please enter email",

					email: "please enter a valide email address"

				

				},
				PASSWORD: {

					required: "Please provide a password",
						  equalTo:""
				}
		}

		});
		
	});

	</script>
<style>
	form.iiiiiiiii label.error, label.error {

	/* remove the next line when you have trouble in IE6 with labels in list */

	color: red;

	font-style: italic

}
</style>
<script>
var MyApp = {}; 
function check_loginprasad()
{	
	x=document.getElementById('email').value;
		y=document.getElementById('password').value;
		if(x!=''&&y!=''){
path="ajax/login-check.php?EMAIL="+x+"&PASSWORD="+y;
//alert(path);
//z=document.getElementById('email').value;
$.post( path,function( data ) {
//$( ".result" ).html( data );
//alert(data);
if(data==0)
{
		//alert("prasad");
	MyApp.data=0;
document.getElementById('email_mes').value='';
}
if(data==1)
{
	MyApp.data=1;
document.getElementById('email_mes').value=y;
}

});
		}
//alert(y);
}
function check_login()
{
	
if(MyApp.data==0)
{
document.getElementById('invalid').innerHTML="Invalid Credentials";
}
}
</script> 
               <div class="modal fade bs-example-modal-lg" id="myModal3" tabadmin_banner="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true"></div>
<?php
 $PIC_ID=$_REQUEST[id];
 $day=str_replace(",","",$_REQUEST[day]);
 $date = date('Y-m-d');
 $date=date('Y-m-d', strtotime('next '.$day.'', strtotime($date)));
?>
<script>
function  pop_function_checkout(ID)
	{
		
	//menu loading
/**/$.post("ajax/admin-edit.php?CHECKOUT_ID="+ID,
function(data){
//alert(data);
document.getElementById('myModal3').innerHTML=data;

});
	}
	
	
	
function  calItemm(day,ID)
	{
		
	//menu loading
/**/$.post("ajax/admin-edit.php?PIC_ID="+ID+"&day="+day,
function(data){
//alert(data);
document.getElementById('myModal').innerHTML=data;

});
	}
	
    
    function cartajax(productid,qty)
{
path="ajax/cartajax.php?PRODUCT_ID="+productid+"&QTY="+qty;
//alert(productid);

$.post(path,function( data ) {
//$( ".result" ).html( data );
//alert("Item added Cart");


document.getElementById('cartajax').innerHTML=data;


});
}

function checkpopup(s)
{
	if(s==1)
	{
		pop_function_checkout();
//	$("#myModal3").show();
//	alert(s);
$('#myModal3').modal('show'); 	
	}
}
</script>    <?php

if($pid!='')

		{

 $inid=in_array($pid,$_SESSION[products]);

 $key = array_search($pid,$_SESSION[products]);



			for($i=0;$i<count($_REQUEST[FIELD_NAME]);$i++)

			$str=$str.$_REQUEST[FIELD_NAME][$i].":".$_REQUEST[$_REQUEST[FIELD_NAME][$i]].",";

//search for multiple entry of ket ex size coclor..

			$keys=array_keys($_SESSION[products],$pid);

			for($i=0;$i<count($keys);$i++)

			{

			 $test_key=$keys[$i];

			if($_SESSION[fieldvalues][$test_key]==$str)

		    $key=$test_key;

			}

			

				if($inid=='')

				{

						$_SESSION[products][]=$pid;

						$_SESSION[qnty][]=$_REQUEST[QTY];

		        		$_SESSION[fieldvalues][]=$str;

				}

				else

				{

			            echo "--".$_SESSION[fieldvalues][$key].'---'.$str."--<br>";  

					    if($_SESSION[fieldvalues][$key]==$str)

						{ 

						echo "old repet";

						echo "--".$_SESSION[fieldvalues][$key].'---'.$str."--<br>";  

					    echo "old repet";

			             $_SESSION[qnty][$key]=$_SESSION[qnty][$key]+$_REQUEST[QTY];

						 }

				        else

						{

				    	echo "old New";	

						echo $_SESSION[fieldvalues][$key].'      '.$str."<br>";

						echo "old New";	

						$_SESSION[products][]=$pid;

						$_SESSION[qnty][]=$_REQUEST[QTY];

             			$_SESSION[fieldvalues][]=$str;

			        	}

				}

				

		header("location:index.php");		//$_SESSION[qnty][$key]++;

		}

?>

<?php 



if(isset($_REQUEST[quantity]))

{

//print_r($_REQUEST[quantity]);

// print_r($_SESSION[products]);

for($i=0;$i<count($_SESSION[products]);$i++)

{

if($_REQUEST[quantity][$i]>0&&$_REQUEST[quantity][$i]<11)

{

$_SESSION[qnty][$i]=$_REQUEST[quantity][$i]; //echo "updated";

header("location:index.php");



}

else

{

header("location:index.php?mes=1");

exit(0);

}



}

}

?>

<?php 

if(isset($_REQUEST[delete]))

{



$offset = array_search($_REQUEST[delete],$_SESSION[products]);



unset($_SESSION[products][$offset]);

$_SESSION[products] = array_values($_SESSION[products]);



unset($_SESSION[qnty][$offset]);

$_SESSION[qnty] = array_values($_SESSION[qnty]);



unset($_SESSION[fieldvalues][$offset]);

$_SESSION[fieldvalues] = array_values($_SESSION[fieldvalues]);



header("location:index.php?d=1");



}



?>

<?php if(isset($_REQUEST[clear])){

unset($_SESSION[products]);$_SESSION[qnty]='';$_SESSION[fieldvalues]='';$_SESSION[total]=0;

header("location:index.php");

}

?>