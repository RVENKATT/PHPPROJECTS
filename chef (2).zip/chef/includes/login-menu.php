<?php
if(isset($_REQUEST[uname]))
{
$pass=$dbFactory->register($_REQUEST[uname],$_REQUEST[EMAIL],$_REQUEST[mobile],$_REQUEST[password],$_REQUEST[address],$_REQUEST[foodtype],$_REQUEST[company]);
$message="Thanks for registering with DeleciousAnandhra.com<br>
<strong>Your Email</strong>: ".$_REQUEST[email]."<br>
<strong>Your password</strong>:  ".$_REQUEST[password]."";
$message2="New user registered in DeleciousAnandhra.com<br><strong>Name</strong> : $_REQUEST[uname]
<br><strong>Email</strong> : $_REQUEST[email]
<br><strong>Mobile</strong> : $_REQUEST[mobile]
<br><strong>Company</strong> : $_REQUEST[company]
<br><strong>Address</strong> : $_REQUEST[address]";

$to=$_REQUEST[email];
$subject="DeleciousAndhra";
$headers = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= "From: $from";


//latest

echo $message= <<<CAPS
<table>
<tr>
<td>Hello <strong style="text-transform:capitalize;">$_REQUEST[uname],</strong></td>
</tr>
<tr>
<td>

 $message
</td>
</tr>
<tr>
<td>
please click the link <a href="http://www.deleciousandhra.com/login.php"><strong>Login</strong></a> from here 
</td>
</tr>
</table>
CAPS;
$from = "admin@deleciousandhra.com";

$headers ='MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= "From: $from";


mail($to,$subject,$message,$headers);
$headers = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= "From: $from";


//latest
$to="hi.anandv@gmail.com,deliciousandhra@gmail.com";
//$to="mahesh@palvs.com";
$subject="New registration";
$headers = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= "From: $from";

echo $message= <<<CAPS
<table>
<tr>
<td>Hello <strong style="text-transform:capitalize;">Admin,</strong></td>
</tr>
<tr>
<td>

 $message2
</td>
</tr>
<tr>
<td>
----------------------------------
</td>
</tr>
</table>
CAPS;
$from = "deleciousandhra@deleciousandhra.com";
$headers ='MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= "From: $from";
mail($to,$subject,$message,$headers);

$_SESSION[mes]=1;
header("Location:index.php");
exit(0);

}
 ?>
 
<div class="menu1">
    <div class="navbar-header">
 	 <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
  	</button>
  	<a class="navbar-brand hidden-sm hidden-md hidden-lg" href="#">Navgation</a>
  	</div>
  
  	<div class="container">
  	<nav class="col-sm-12 col-md-10 col-lg-12 col-lg-offset-1 col-md-offset-1">
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
    <ul class="menu">
        <li class="<?php if($var=="home"){?>select<?php }?>"><a href="index.php">Home <span class="sr-only">(current)</span></a></li>
        <?php $m=$dbFactory->menu();
 // echo count($s);
	for($i=0;$i<count($m);$i++)
	{
	if($m[$i][EXTERNAL_LINK]=='')
	{?> 
        <li ><a href="content.php?id=<?php echo $m[$i][MENU_ID];?>"><?php echo $m[$i][MENU_TITLE];?></a></li>
    	<?php }else{?>
       <li ><a href="<?php echo $m[$i][EXTERNAL_LINK];?>"><?php echo $m[$i][MENU_TITLE];?></a></li>
    	
		<?php }}?>
   
   <?php if($_SESSION[user_id]==0)
	{?>	
    <li ><a data-toggle="modal" data-target="#myModal" style="cursor:pointer">Register</a></li>
	<li ><a data-toggle="modal" data-target="#myModal2" style="cursor:pointer">Login</a></li>
<?php } else {?>
<li><a href="transactions.php">Transactions</a></li>
<li><a href="logout.php" style="cursor:pointer">Logout</a></li>
<?php }?>

<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel" style="color:#333333"><strong>Registration</strong></h4>
      </div>
      <div class="modal-body">
      <div class="panel-body">
			    	<form accept-charset="UTF-8" role="form"  style="color:#333333" id="form" autocomplete="off">
                    <fieldset>
			    	  	<div class="form-group">
			    		    <input class="form-control" placeholder="Your Name" name="uname" type="text" >
			    		</div>
			    	  	<div class="form-group">
			    		    <input type="text" name="EMAIL" class="form-control" placeholder="ex: anand@gmail.com" onKeyUp="check_email(this.value)" id="emailregister"  >
                      <input type="hidden" class="form-control"  name="EMAIL_MES"   id="email_mess">
            <label id="email_status" style="color:#FF0000"></label>
			    		</div>
			    	  	<div class="form-group">
			    		    <input class="form-control" placeholder="Mobile" name="mobile" type="text" onKeyPress="return isNumberKey(event)" maxlength="10">
			    		</div>
                        <div class="form-group">
			    		    <input class="form-control" placeholder="Company" name="company" type="text" required>
			    		</div>
                        <div class="form-group">
						    
			    		    <select class="form-control" name="foodtype">
							<option>Food Type:</option>
							<option value="Vegitarian">Vegitarian</option>
							<option value="Non-Vegitarian">Non-Vegitarian</option>
							<option value="Both" >Both</option>
							</select>
			    		</div>
                        <div class="form-group">
			    		    <input class="form-control" placeholder="Password" name="password" type="password" required>
			    		</div>


						<div class="form-group">
			    		   <textarea class="form-control" placeholder="Address" name="address"  required></textarea>
			    		</div>

			    		
			    		<input class="btn btn-lg btn-success btn-block" type="submit" value="Register">
			    	</fieldset>
			      	</form>
			   
			   
			    </div>
      </div>
      <div class="modal-footer" style="color:#14300a">
      We offer delivery for employees only not for homes.
      
	  </div>
    </div>
  </div>
</div>
	</li>	
    </ul>
    </div>
 	</nav>
    </div>
    </div>
    
<div class="modal fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close"  data-dismiss="modal" aria-hidden="true">&times;</button>
                <div style="display:none;<?php if($_REQUEST[mes]==2){?>display:block<?php }?>">
                  <div class="alert alert-dismissable alert-danger">
                    <button type="button" class="close" data-dismiss="alert">&#x2715;</button>
                    <strong>Invalid Credentials .</strong> </div>
                </div>
                <h3 id="invalid" align="center" style="color:#F00;"> </h3>
                <h4 class="modal-title" id="myModalLabel" align="center">LOGIN HERE</h4>
              </div>
              <div class="modal-body">
                <form class="form-horizontal iiiiiiiii" role="form" method="post" id="login" onsubmit="check_login()"  >
                  <div class="form-group">
                    <label for="inputEmail3" class="col-sm-2 control-label">Email</label>
                    <div class="col-sm-10">
                      <input type="text"  name="EMAIL" class="form-control" id="email" placeholder="Email">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputPassword3" class="col-sm-2 control-label">Password</label>
                    <div class="col-sm-10">
                      <input type="password"  name="PASSWORD"  class="form-control" id="password" placeholder="Password"       onkeyup="check_loginprasad()">
                      <input type="hidden" class="form-control"  name="EMAIL_MES"   id="email_mes">
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-sm-2"> </div>
                    <div class="col-sm-2">
                      <input type="submit" class="btn btn-primary" name="login"      value="Login"  />
                    </div>
                    <div class=" col-sm-3"> <a href="forget.php"> Forgot Password</a> </div>
                    
                  </div>
                </form>
              </div>
            </div>
  </div>
</div>
	</li>	
    </ul>
    </div>
 	</nav>
    </div>
    </div>
<!--model1 close-->

<div style=" background-color:#333;  width:100px; color:#CCC; bottom:2px; right:2px; position:fixed; z-index:9999; border:5px solid #666">
<table width="100%" border="1" style="text-align:center">
 <!-- <tr>
    <td>Items In Cart</td>
  </tr>
  <tr>
    <td><span id="items">0</span></td>
  </tr>
  <tr>
    <td>Amount</td>
  </tr>
  <tr>
    <td><span id="amount">0</span>/-</td>
  </tr>-->
  <tr>
    <td><span id="cartajax" class="btn btn-primary btn-xs" data-toggle="modal" data-target="#myModal3" onClick="pop_function_checkout(<?php echo $_REQUEST[CHECKOUT_ID];?>)" style="cursor:pointer;"><img src="images/checkout_icon.png" width="50" /> (<?php echo count($_SESSION[products])?>)</span></td>
  </tr>

</table>

</div>