<?php
if(isset($_REQUEST[uname]))
{
$pass=$dbFactory->register($_REQUEST[uname],$_REQUEST[email],$_REQUEST[mobile],$_REQUEST[address],$_REQUEST[company]);
$message="Thanks for registering with DeleciousAnandhra.com<br>You password $pass";
$message2="New user registered in DeleciousAnandhra.com<br><strong>Name</strong> : $_REQUEST[uname]
<br><strong>Email</strong> : $_REQUEST[email]
<br><strong>Mobile</strong> : $_REQUEST[mobile]
<br><strong>Company</strong> : $_REQUEST[company]
<br><strong>Address</strong> : $_REQUEST[address]";

$to=$_REQUEST[email];
$subject="DeleciousAndhra";
$headers = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= "From: $from";


//latest

echo $message= <<<CAPS
<table>
<tr>
<td>Hello <strong style="text-transform:capitalize;">$_REQUEST[uname],</strong></td>
</tr>
<tr>
<td>

 $message
</td>
</tr>
<tr>
<td>
please click the link <a href="http://www.deleciousandhra.com/login.php"><strong>Login</strong></a> from here 
</td>
</tr>
</table>
CAPS;
$from = "admin@deleciousandhra.com";

$headers ='MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= "From: $from";


mail($to,$subject,$message,$headers);
$headers = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= "From: $from";


//latest
$to="hi.anandv@gmail.com,deliciousandhra@gmail.com";
$subject="New registration";
$headers = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= "From: $from";

echo $message= <<<CAPS
<table>
<tr>
<td>Hello <strong style="text-transform:capitalize;">Admin,</strong></td>
</tr>
<tr>
<td>

 $message2
</td>
</tr>
<tr>
<td>
----------------------------------
</td>
</tr>
</table>
CAPS;
$from = "deleciousandhra@deleciousandhra.com";
$headers ='MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= "From: $from";
mail($to,$subject,$message,$headers);


header("Location:index.php?mes=1");

}
 ?>
 
 <?php 
 if(isset($_REQUEST[login]))
 {
	 $user=$dbFactory->registeruser_check($_REQUEST[email],$_REQUEST[pass]);
	 if(count($user)==1)

	{

	echo $_SESSION[user_id]=$user[0][USER_ID];

	$_SESSION[user_name]=$user[0][USER_NAME];

	$_SESSION[user_email]=$user[0][USER_EMAIL];

	

	header("location:index.php");



	}

	else

    {

	
$_SESSION[mes]=2;
	header("location:index.php");
exit(0);
    } 
	 
	 
 }
 
 

?>
<style type="text/css">
#custom-bootstrap-menu.navbar-default .navbar-brand {
    color: rgba(255, 255, 255, 1);
}
#custom-bootstrap-menu.navbar-default {
    font-size: 14px;
    background-color: rgba(44, 44, 46, 1);
    background: -webkit-linear-gradient(top, rgba(79, 79, 79, 1) 0%, rgba(44, 44, 46, 1) 100%);
    background: linear-gradient(to bottom, rgba(79, 79, 79, 1) 0%, rgba(44, 44, 46, 1) 100%);
    border-width: 1px;
}
#custom-bootstrap-menu.navbar-default .navbar-nav>li>a {
    color: rgba(255, 255, 255, 1);
    background-color: rgba(248, 248, 248, 0);
}
#custom-bootstrap-menu.navbar-default .navbar-nav>li>a:hover,
#custom-bootstrap-menu.navbar-default .navbar-nav>li>a:focus {
    color: rgba(255, 255, 255, 1);
    background-color: rgba(153, 199, 15, 1);
}
#custom-bootstrap-menu.navbar-default .navbar-nav>.active>a,
#custom-bootstrap-menu.navbar-default .navbar-nav>.active>a:hover,
#custom-bootstrap-menu.navbar-default .navbar-nav>.active>a:focus {
    color: rgba(255, 255, 255, 1);
    background-color: rgba(153, 199, 15, 1);
}
#custom-bootstrap-menu.navbar-default .navbar-toggle {
    border-color: #99c70f;
}
#custom-bootstrap-menu.navbar-default .navbar-toggle:hover,
#custom-bootstrap-menu.navbar-default .navbar-toggle:focus {
    background-color: #99c70f;
}
#custom-bootstrap-menu.navbar-default .navbar-toggle .icon-bar {
    background-color: #99c70f;
}
#custom-bootstrap-menu.navbar-default .navbar-toggle:hover .icon-bar,
#custom-bootstrap-menu.navbar-default .navbar-toggle:focus .icon-bar {
    background-color: #2c2c2e;
}
</style>
<div id="custom-bootstrap-menu" class="navbar navbar-default " role="navigation">
    <div class="container-fluid">
        <div class="navbar-header"><a class="navbar-brand" href="#">Brand</a>
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-menubuilder"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span>
            </button>
        </div>
        <div class="collapse navbar-collapse navbar-menubuilder">
            <ul class="nav navbar-nav navbar-left">
                <li><a href="/">Home</a>
                </li>
                <li><a href="/products">Products</a>
                </li>
                <li><a href="/about-us">About Us</a>
                </li>
                <li><a href="/contact">Contact Us</a>
                </li>
            </ul>
        </div>
    </div>
</div>
<!--<div class="menu1">
    <div class="navbar-header">
 	 <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
  	</button>
  	<a class="navbar-brand hidden-sm hidden-md hidden-lg" href="#">Navgation</a>
  	</div>
  
  	<div class="container">
  	<nav class="col-sm-12 col-md-10 col-lg-12 col-lg-offset-1 col-md-offset-1">
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
    <ul class="menu">
        <li class="select"><a href="index.php">Home <span class="sr-only">(current)</span></a></li>
        <?php $m=$dbFactory->menu();
 // echo count($s);
	for($i=0;$i<count($m);$i++)
	{
	if($m[$i][EXTERNAL_LINK]=='')
	{?> 
        <li ><a href="content.php?id=<?php echo $m[$i][MENU_ID];?>"><?php echo $m[$i][MENU_TITLE];?></a></li>
    	<?php }else{?>
       <li ><a href="<?php echo $m[$i][EXTERNAL_LINK];?>"><?php echo $m[$i][MENU_TITLE];?></a></li>
    	
		<?php }}?>
   
   <?php if($_SESSION[user_id]==0)
	{?>	
    <li><a data-toggle="modal" data-target="#myModal" style="cursor:pointer">Register</a></li>
	<li><a data-toggle="modal" data-target="#myModal2" style="cursor:pointer">Login</a></li>
<?php } else {?>
<li><a href="logout.php" style="cursor:pointer">Logout</a></li>
<?php }?>

<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel" style="color:#333333"><strong>Registration</strong></h4>
      </div>
      <div class="modal-body">
      <div class="panel-body">
			    	<form accept-charset="UTF-8" role="form"  style="color:#333333">
                    <fieldset>
			    	  	<div class="form-group">
			    		    <input class="form-control" placeholder="Your Name" name="uname" type="text" required>
			    		</div>
			    	  	<div class="form-group">
			    		    <input class="form-control" placeholder="Email" name="email" type="text" required>
			    		</div>
			    	  	<div class="form-group">
			    		    <input class="form-control" placeholder="Mobile" name="mobile" type="text" required>
			    		</div>
                        <div class="form-group">
			    		    <input class="form-control" placeholder="Company" name="company" type="text" required>
			    		</div>
                        <div class="form-group">
						    
			    		    <select class="form-control" name="company">
							<option>Food Type:</option>
							<option value="Vegitarian">Vegitarian</option>
							<option value="Non-Vegitarian">Non-Vegitarian</option>
							<option value="Both" >Both</option>
							</select>
			    		</div>
                        <div class="form-group">
			    		    <input class="form-control" placeholder="Password" name="password" type="password" required>
			    		</div>


						<div class="form-group">
			    		   <textarea class="form-control" placeholder="Address" name="address"  required></textarea>
			    		</div>

			    		
			    		<input class="btn btn-lg btn-success btn-block" type="submit" value="Register">
			    	</fieldset>
			      	</form>
			   
			   
			    </div>
      </div>
      <div class="modal-footer" style="color:#14300a">
      We offer delivery for employees only not for homes.
      
	  </div>
    </div>
  </div>
</div>
	</li>	
    </ul>
    </div>
 	</nav>
    </div>
    </div>
	-->
<div class="modal fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel" style="color:#333333"><strong>Login</strong></h4>
      </div>
      <div class="modal-body">
      <div class="panel-body">
			    	<form accept-charset="UTF-8" method="post" role="form"  style="color:#333333">
                    <fieldset>
			    	  	<div class="form-group">
			    		    <input class="form-control" placeholder="Email" name="email" type="text" required>
			    		</div>
			    	  	<div class="form-group">
			    		    <input class="form-control" placeholder="Password" name="pass" type="password" required>
			    		</div>

			    		
			    		<input class="btn btn-lg btn-success btn-block" type="submit" name="login" value="Login">
			    	</fieldset>
			      	</form>
			    </div>
      </div>
      <div class="modal-footer" style="color:#666666">
	  </div>
    </div>
  </div>
</div>
	</li>	
    </ul>
    </div>
 	</nav>
    </div>
    </div>
<!--model1 close-->