<div class="container">    	
                <a class="pull-left" href="./">
                	<img src="images/righteous-logo.jpg" class="img-responsive" alt="">
                </a>
                <button type="button" class="btn btn-success pull-right righteous-request-btn">Request For Information</button>
    </div>
    <nav class="navbar navbar-inverse" role="navigation">
  <div class="container"> 
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
      <!--<a class="navbar-brand hidden-lg hidden-sm- hidden-md" href="index.html"><img src="images/righteous-logo.jpg" class="img-responsive" alt=""></a>--> 
    </div>
    <!-- Collect the nav links, forms, and other content for toggling -->
    
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav navbar-left">
      <li><a href="./">Home</a></li>
       <?php

$s3=$dbFactory->menu_parent(0);
//echo count($s3);
for($i=0; $i<count($s3); $i++){
//if($d[$i][person]=='')continue;
?>
        

      
        <li class="dropdown"> <a href="<?php if($s3[$i][EXTERNAL_LINK]==""){?>content.php<?php }else{echo $s3[$i][EXTERNAL_LINK];}?>?id=<?php echo $s3[$i][MENU_ID];?>">
<?php echo $s3[$i][MENU_TITLE];?>
 <?php $s4=$dbFactory->menu_parent($s3[$i][MENU_ID]); if(count($s4)!=0){ ?><b class="caret"></b><?php }?></a>
 <?php $s4=$dbFactory->menu_parent($s3[$i][MENU_ID]); if(count($s4)!=0){ ?>
          <ul class="dropdown-menu">
            <?php
$s4=$dbFactory->menu_parent($s3[$i][MENU_ID]);
for($j=0; $j<count($s4); $j++){
//if($d[$i][person]=='')continue;
?>
            <li> 
            <a href="<?php if($s4[$j][EXTERNAL_LINK]==""){?>content.php<?php }else{echo $s4[$j][EXTERNAL_LINK];}?>?id=<?php echo $s4[$j][MENU_ID];?>">
			  <?php echo $s4[$j][MENU_TITLE];?></a></li>
              
             <?php } ?>

          </ul>
          <?php }?>
        </li>
     <?php }?>
    
        
      </ul>
    </div>
    <!-- /.navbar-collapse --> 
  </div>
  <!-- /.container --> 
</nav>