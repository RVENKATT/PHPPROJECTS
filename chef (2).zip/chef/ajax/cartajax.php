<?php
session_start();
error_reporting(0);
include('../includes/products-management.php');
$dbFactory= new ProductsManagement();
$pid=$_REQUEST[PRODUCT_ID];
?>              
<?php 
if($pid!='')
{
 $inid=in_array($pid,$_SESSION[products]);

 $key = array_search($pid,$_SESSION[products]);
			for($i=0;$i<count($_REQUEST[FIELD_NAME]);$i++)

			$str=$str.$_REQUEST[FIELD_NAME][$i].":".$_REQUEST[$_REQUEST[FIELD_NAME][$i]].",";

//search for multiple entry of ket ex size coclor..

			$keys=array_keys($_SESSION[products],$pid);

			for($i=0;$i<count($keys);$i++)

			{

			 $test_key=$keys[$i];

			if($_SESSION[fieldvalues][$test_key]==$str)

		    $key=$test_key;

			}

		if($inid=='')

				{

						$_SESSION[products][]=$pid;

						$_SESSION[qnty][]=$_REQUEST[QTY];

		        		$_SESSION[fieldvalues][]=$str;

				}

				else

				{

			           // echo "--".$_SESSION[fieldvalues][$key].'---'.$str."--<br>";  

					    if($_SESSION[fieldvalues][$key]==$str)

						{ 

						//echo "old repet";

						//echo "--".$_SESSION[fieldvalues][$key].'---'.$str."--<br>";  

					  //  echo "old repet";

			             $_SESSION[qnty][$key]=$_SESSION[qnty][$key]+$_REQUEST[QTY];

						 }

				        else

						{

				    	//echo "old New";	

						//echo $_SESSION[fieldvalues][$key].'      '.$str."<br>";

						//echo "old New";	

						$_SESSION[products][]=$pid;

						$_SESSION[qnty][]=$_REQUEST[QTY];

             			$_SESSION[fieldvalues][]=$str;

			        	}}
				

		}
		
		
?>
<?php
 if(count($_SESSION[products])==0){?>
       
              <?php }?>
              <?php

   $total=0;

  for($i=0;$i<count($_SESSION[products])&&$_SESSION[products][0]!='';$i++){

   $s=$dbFactory->details_item($_SESSION[products][$i]);

   ?>
   <?php  $_SESSION[qnty][$i]*$s[0][PRODUCT_COST];$total=$total+$_SESSION[qnty][$i]*$s[0][PRODUCT_COST];?>
   
   <?php  $_SESSION[total]=$total; }?>
   <div style=" background-color:#333;  width:100px; color:#CCC; bottom:2px; right:2px; position:fixed; z-index:9999; border:5px solid #666">
<table width="100%" border="1" style="text-align:center">
 <tr>
    <td>
     <span  class="btn btn-primary btn-xs" data-toggle="modal" data-target="#myModal4" onClick="pop_function_checkoutt(<?php echo $_REQUEST[CHECKOUT_IDD];?>)" style="cursor:pointer"><img src="images/checkout_icon.png" width="50" />(<?php echo count($_SESSION[products])?>)</span>
     </td>
  </tr>

</table>

</div>
<!-- <a href="checkout.php" class="sign-up">Checkout(<?php echo count($_SESSION[products]);?>)</a> -->
              