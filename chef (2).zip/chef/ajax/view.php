<?php


session_start();


ob_start();


error_reporting(0);


	include('../includes/products-management.php');


	$dbFactory= new ProductsManagement();


?>

<div class="modal-dialog">
<div class="modal-content">
  <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
    <h4 class="modal-title" id="myModalLabel">TRANSACTION DETAILS</h4>
  </div>
  <div class="modal-body">
    <div class="container-fluid">
      <div class="row">
        <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
          <thead>
            <tr>
              <th>SNO</th>
              <th>PRODUCT</th>
              <th>COST</th>
              <th>QUANTITY</th>
              <!-- <th>MESSAGE</th>
						<th>CITY</th>--> 
              
            </tr>
          </thead>
          <tbody id="cat_tab_id">
            <?php


$product_info=$dbFactory->transaction_detail($_REQUEST[TRANSACTION_ID]);





 for($i=0; $i<count($product_info); $i++){


//if($d[$i][person]=='')continue;


?>
            <tr height="50px">
              <td><?php echo $i+1 ?></td>
              <td><?php $product=$dbFactory->details_item($product_info[$i][PRODCUT_ID]);
	echo $product[0][IMG_NAME];?></td>
              <td><?php echo $product[0][COST];?></td>
              <td><?php echo $product_info[$i][QUANTITY];?></td>
              <!-- <td><?php echo $product_info[$i][MESSAGE];?></td>
						   <td><?php echo $product_info[$i][CITY];?></td>--> 
              
            </tr>
            <?php }?>
          </tbody>
        </table>
        
      <!-- <p><a href="reorder.php?TRANSACTION_ID=<?php echo $_REQUEST[TRANSACTION_ID];?>">Reorder</a> </p> 


  


  <p><strong>Note:</strong>It will clear the current selected order..</p>-->

<?php 
  $product_addr=$dbFactory->transaction_shipping($_REQUEST[TRANSACTION_ID]);
?>

<h3 align="center">SHIPPING ADDRESS DETAILS</h3>
<div  align="center">

<?php if($product_addr[0][ADDRESS_ID]==0){
	$address_detail=$dbFactory->transaction_shipping_address($_REQUEST[TRANSACTION_ID]);
	
	
	?>
  <p><strong>NAME:</strong><?php echo $address_detail[0][SHIPP_NAME];?></p>
    <p><strong>ADDRESS:</strong><?php echo $address_detail[0][SHIPP_ADDRESS];?></p>
      <p><strong>CITY:</strong><?php echo $address_detail[0][SHIPP_CITY];?></p>
        <p><strong>STATE:</strong><?php echo $address_detail[0][SHIPP_STATE];?></p>
          <p><strong>ZIPCODE:</strong><?php echo $address_detail[0][SHIPP_POSTAL_CODE];?></p>
            <p><strong>COUNTRY:</strong><?php echo $address_detail[0][SHIPP_COUNTRY];?></p>
              <p><strong>PHONE:</strong><?php echo $address_detail[0][SHIPP_PHONE];?></p>
                <p><strong>DELIVERY DATE:</strong><?php echo $product_addr[0][SHIPP_DELIVERY_DATE];?></p>
			<?php } else{
				$address_detail=$dbFactory->address_old_details_id($product_addr[0][ADDRESS_ID]);
				
				?>
              <p><strong>NAME:</strong><?php echo $address_detail[0][SHIPP_NAME];?></p>
    <p><strong>ADDRESS:</strong><?php echo $address_detail[0][SHIPP_ADDRESS];?></p>
      <p><strong>CITY:</strong><?php echo $address_detail[0][SHIPP_CITY];?></p>
        <p><strong>STATE:</strong><?php echo $address_detail[0][SHIPP_STATE];?></p>
          <p><strong>ZIPCODE:</strong><?php echo $address_detail[0][SHIPP_POSTAL_CODE];?></p>
            <p><strong>COUNTRY:</strong><?php echo $address_detail[0][SHIPP_COUNTRY];?></p>
              <p><strong>PHONE:</strong><?php echo $address_detail[0][SHIPP_PHONE];?></p>
                <p><strong>DELIVERY DATE:</strong><?php echo $product_addr[0][SHIPP_DELIVERY_DATE];?></p>
            
            
            <?php }?>

</div>
   

        
      </div>
    </div>
  </div>
</div>
