<?php
session_start();
ob_start();
error_reporting(0);
include('../includes/products-management.php');
$dbFactory= new ProductsManagement();
 ?>
<?php
 $id=$_REQUEST[id];
 $day=str_replace(",","",$_REQUEST[day]);
 $date = date('Y-m-d');
 $date=date('Y-m-d', strtotime('next '.$day.'', strtotime($date)));
?>

<table width="100%" border="0" cellspacing="5" cellpadding="5" style="background:#FFFFFF"  class=" table-hover table-bordered table-stripped">
	  <?php $s=$dbFactory->details_item($id);?>
  <tr> <td  valign="middle" colspan="6" style="line-height:50px;" align="center"><strong><?php echo $s[0][IMG_NAME];?> (<?php echo $s[0][COST];?>/-)</strong><input type="hidden" id="costofitem" value="<?php echo $s[0][COST];?>" /></td></tr>                
  <tr style="font-size:16px">
    <td width="20%" align="center"><img src="admin/images/<?php echo $s[0][PIC_ID];?>.jpg" width="100%"></td>
    <td  valign="middle" align="center" >Available date<br><strong><?php echo $day;?></strong><br><?php echo $date;?></td>
    <td  valign="middle" align="center" >
QTY:    <select name="qty" onChange="calcost(this.value,'<?php echo $s[0][COST];?>')" id="qty">
    <?php	for($i=1;$i<11;$i++){?>
   	 <option value="<?php  echo $i;?>"><?php echo $i;?></option>
    <?php }?>
    </select>
    </td>
    <td  valign="middle" align="center">Price:<strong  id="cost"><?php echo $s[0][COST];?></strong></td>
    <td  valign="middle" align="center" ><a class="btn btn-default"  onclick="cartajax('<?php echo $id;?>',1)">Order</a></td>
    <input  type="hidden" name="PIC_ID" value="<?php echo $id;?>"  />

  </tr> 
</table>









