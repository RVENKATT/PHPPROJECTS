<?php
session_start();
ob_start();
error_reporting(0);
?>


<?php 
if($_REQUEST[PIC_ID]!="")
{

		include('../includes/products-management.php');

	$dbFactory= new ProductsManagement();
?>

<div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel">Checkout Form</h4>
      </div>
      <div class="modal-body">
      <div class="container-fluid">
  <div class="row">
      <form id="myForm" method="post"><div class="wrap">
       
<table width="100%" border="0" cellspacing="5" cellpadding="5" style="background:#FFFFFF"  class=" table-hover table-bordered table-stripped">
	  <?php $s=$dbFactory->details_item($_REQUEST[PIC_ID]);?>
  <tr> <td  valign="middle" colspan="6" style="line-height:50px;" align="center"><strong><?php echo $s[0][IMG_NAME];?> (<?php echo $s[0][COST];?>/-)</strong><input type="hidden" id="costofitem" value="<?php echo $s[0][COST];?>" /></td></tr>                
  <tr style="font-size:16px">
    <td width="20%" align="center"><img src="admin/images/<?php echo $s[0][PIC_ID];?>.jpg" width="100%"></td>
    <td  valign="middle" align="center" >Available date<br><strong><?php echo $day;?></strong><br><?php echo $date;?></td>
    <td  valign="middle" align="center" >
QTY:    <select name="qty" onChange="calcost(this.value,'<?php echo $s[0][COST];?>')" id="qty">
    <?php	$_SESSION[qnty][$i]=$s[0][COST];
	for($i=1;$i<11;$i++){?>
   	 <option value="<?php  echo $i;?>"><?php echo $i;?></option>
    <?php }?>
    </select>
    </td>
    <td  valign="middle" align="center">Price:<strong  id="cost"><?php echo $s[0][COST];?></strong></td>
    <td  valign="middle" align="center" ><a class="btn btn-default"  onclick="cartajax('<?php echo $_REQUEST[PIC_ID];?>',1)">Order</a></td>
    <input  type="hidden" name="PIC_ID" value="<?php echo $_REQUEST[PIC_ID];?>"  />

  </tr> 
</table>
</div>
</form>
      
    </div>
      
      </div>
  </div>
    </div>
  </div>

<?php }?>


<?php 
if($_REQUEST[CHECKOUT_ID]!="")
{

		include('../includes/products-management.php');

	$dbFactory= new ProductsManagement();
?>

<div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel">Checkout Form</h4>
      </div>
      <div class="modal-body">
      <div class="container-fluid">
  <div class="row">
      <form id="myForm" method="post"><div class="wrap">
       
      

 

<table class="table table-bordered table-condensed tb2">

<tbody>

<tr>

<!--<th>ITEM</th>-->

<th>item name</th>


<!--<th>WEIGHT</th>
<th>QTY</th>-->

<th>PRICE</th>

<!--<th>DELIVARY DETALS</th>-->

<th>SUB TOTAL</th>

<th></th>

</tr>

<?php



 if(count($_REQUEST[CHECKOUT_ID])==0){?>

<tr><td colspan="7">No Products Are There In Cart.</td></tr>

<?php }?>

   <?php

   $total=0;

  for($i=0;$i<count($_SESSION[products])&&$_SESSION[products][0]!='';$i++){

   $s=$dbFactory->details_item($_SESSION[products][$i]);
  // echo count($s);

   ?>



<tr>



<td class="it2"><?php echo $s[0][IMG_NAME];?></td>


<!--<td class="it3">



                <a  onclick="myFunction()" ><i class="icon-refresh"></i>refresh</a>

</td>-->
<input type="hidden" name="quantity[]" value="<?php echo $_SESSION[qnty][$i];?>" onKeyPress="return isNumberKey(event)" style="width:30px;display:inline-block;margin-right:5px;" id="<?php echo $_REQUEST[CHECKOUT_ID];?>"  autocomplete="off" onCopy="return false" onDrag="return false" onDrop="return false" onPaste="return false"/>
<td class="it4"><?php echo $s[0][COST];?></td>

<td class="it6"><?php echo $_SESSION[qnty][$i]*$s[0][COST];$total=$total+$_SESSION[qnty][$i]*$s[0][COST]; ?></td>



<td class="it7"><a href="index.php?delete=<?php echo $_SESSION[products][$i];?>"><img src="images/close.png" class="img-responsive" /></a></td>

</tr>

   <?php }?>

</tbody></table>



    	     <!--<h4 class="title">Shopping cart is empty</h4>
    	     <p class="cart">You have no items in your shopping cart.<br>Click<a href="index.php"> here</a> to continue shopping</p>-->
    	   </div> <p class="pull-left"><a href="recipes.php"class="btn btn-primary" >Continue Shopping</a><a href="checkout.php?clear"class="btn btn-danger" >Clear All</a></p> 

 <?php if($_SESSION[user_id]!=''){?>
 <p class="pull-right total" style="padding-left:5px">TOTAL :<span> RS. <?php echo $_SESSION[total]=$total?></span></p>
 <?php } else {?><?php }?>


<?php if($_SESSION[user_id]==''){?>
<!--<input type="submit" value="Please login to place order">-->
<?php if(count($_SESSION[products])==0){?><?php } else {?> <p class="pull-right" ><a class="btn btn-warning" href="login.php" style="cursor:pointer">Please login to place order</a></p><?php }?>
<?php } else if(count($_SESSION[products])==0){?><?php } else {?>
<p class="pull-right"><a href="shipping.php" class="btn btn-warning">Place order</a></p>
<?php }?>
           <input type="hidden" name="THICKNESS_ID" value="<?php echo $_REQUEST[CHECKOUT_ID]?>" />    
   <!-- <p class="pull-right"><a href="signup.php"class="btn btn-warning" >Please login to place order</a></p>-->

</form>
      
    </div>
      
      </div>
  </div>
    </div>
  </div>

<?php }?>


