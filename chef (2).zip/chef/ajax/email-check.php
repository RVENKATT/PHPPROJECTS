<?php
session_start();
ob_start();
error_reporting(0);
	include('../includes/products-management.php');
$dbFactory= new ProductsManagement();
		$ff=$dbFactory->user_email_check($_REQUEST[email]);
		echo count($ff);
		
?>

