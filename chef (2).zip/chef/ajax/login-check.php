<?php
session_start();
ob_start();
error_reporting(0);
	include('../includes/products-management.php');

$dbFactory= new ProductsManagement();
	
	$user=$dbFactory->registeruser_check($_REQUEST[EMAIL],$_REQUEST[PASSWORD]);
		echo count($user);
		
	if(count($user)==1)
{
	$_SESSION[user_id]=$user[0][USER_ID];	
	$_SESSION[user_name]=$user[0][USERNAME];	
}		
		
?>

