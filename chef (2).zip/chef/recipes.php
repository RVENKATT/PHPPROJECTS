<?php
session_start();
ob_start();
error_reporting(0);
include('includes/products-management.php');
$dbFactory= new ProductsManagement();
 ?>


<!DOCTYPE  html>
<html lang="en">

<head>
  <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>DeleciousAndhra</title>


    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="css/animate.css" type="text/css">
	<link rel="stylesheet" href="font-awesome-4.2.0/css/font-awesome.min.css" type="text/css">
    
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script> 
    <script src="js/bootstrap.min.js"></script> 
    <script src="js/scripts.js"></script>
    <!-- Just include this Js file -->
	<script src="./js/jquery.carousel.fullscreen.js"></script>
</head>


<body onLoad="chagediv(<?php if($_REQUEST[part]==''){ echo "1";} else echo $_REQUEST[part]; ?>)">
<?php if($_REQUEST[mes]==1){ ?>
 <div class="alert alert-success" style="margin:10px">
        <a href="#" class="close" data-dismiss="alert">&times;</a>
        <strong>Success!</strong> Check your mail and complete the registration get free Delicious meal on first day. and get more offers..
    </div>
<?php }?>
	<?php /*?><div class="mani_slide">
    <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
		<!-- Indicators -->
		<ol class="carousel-indicators">
			<li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
			<li data-target="#carousel-example-generic" data-slide-to="1"></li>
			<li data-target="#carousel-example-generic" data-slide-to="2"></li>
		</ol>

		<!-- Wrapper for slides -->
		<div class="carousel-inner">
         <?php $s=$dbFactory->banner_image();
 // echo count($s);
	for($i=0;$i<count($s);$i++)
	{?>
			<div class="item <?php  if($i==0){?>active <?php }?>">
				<img src="admin/banner_images/<?php echo $s[$i][BANNER_IMG_ID];?>.png" alt="" />
				<div class="container">
					<div class="carousel-caption wow pulse">
						<h1 class="brand_name " style="visibility: visible;">
						<a href="./">DeleciousAndhra</a>
						</h1>
						<p class="brand_slogan">premium cuisine </p>
					</div>
				</div>
			</div>
<?php }?>
			
		</div>

		<!-- Controls -->
		<a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
			<span class="glyphicon glyphicon-chevron-left"></span>
		</a>
		<a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
			<span class="glyphicon glyphicon-chevron-right"></span>
		</a>
	</div>
    </div><?php */?>
	
	<?php include("includes/menu.php"); ?>
    
    
	<div class="container ac">
    <div class="row">
  <div class="col-md-4"><h4 style=" background:#0494f4; color:#FFFFFF; cursor:pointer; padding:5px; border-bottom:5px solid #3b5a9b" onClick="chagediv(1)" id="h1">Andhra Special</h4></div>
  <div class="col-md-4"><h4 style="  background:#0494f4; color:#FFFFFF;cursor:pointer;padding:5px; border-bottom:5px solid #3b5a9b" onClick="chagediv(2)" id="h2">Andhara Veg Items</h4></div>
  <div class="col-md-4"><h4 style="  background:#0494f4; color:#FFFFFF;cursor:pointer;padding:5px; border-bottom:5px solid #3b5a9b" onClick="chagediv(3)" id="h3">Andhra Non veg Items</h4></div>
 
	</div>
	</div>
    
	<section class="well bg-section slideInLeft wow">
	<div class="container ac">
	<p class="p__mod">
      
			    	<table width="100%" border="0" cellspacing="5" cellpadding="5" style="background:#FFFFFF"  class=" table-hover table-bordered table-stripped"  id="1">
	  <?php $s=$dbFactory->internal_item(59);
	  for($i=0;$i<count($s);$i++){
				  
					   ?>
                  
  <tr style="font-size:16px">
  
    <td width="20%"><img src="admin/images/<?php echo $s[$i][PIC_ID];?>.jpg" width="100%"></td>
    <td  valign="middle" ><strong><?php echo $s[$i][IMG_NAME];?></strong></td>
    <td  valign="middle"  width="20%"><?php echo $s[$i][COST];?>/-</td>
    <td  valign="middle"  width="20%" align="left"><?php $t=explode(",",$s[$i][DAYS]); for ($j=0;$j<count($t);$j++){?>
	&nbsp;<label><input type="radio" name="item" onClick="calItem('<?php echo $t[$j].",";?>','<?php echo $s[$i][PIC_ID];?>')" data-toggle="modal" data-target=".bs-example-modal-lg"><?php echo $t[$j];?></label>
    
     <!-- <label><input type="radio" style="margin-bottom:6px" class="btn btn-primary btn-xs" data-toggle="modal" data-target="#myModal" onClick="calItemm('<?php echo $t[$j].",";?>','<?php echo $s[$i][PIC_ID];?>')"  ><?php echo $t[$j];?></span></label>--><br>
	<?php }?></td>
    
  </tr> 
<?php }?>
</table>
	</p>
	<p class="p__mod">
      
			    	<table width="100%" border="0" cellspacing="5" cellpadding="5" style="background:#FFFFFF"  class=" table-hover table-bordered table-stripped"   id="2">
	  <?php $s=$dbFactory->internal_item(60);
	  for($i=0;$i<count($s);$i++){
				  
					   ?>
                  
  <tr style="font-size:16px">
  
    <td width="20%"><img src="admin/images/<?php echo $s[$i][PIC_ID];?>.jpg" width="100%"></td>
    <td  valign="middle" ><strong><?php echo $s[$i][IMG_NAME];?></strong></td>
  <td  valign="middle"  width="20%"><?php echo $s[$i][COST];?>/-</td>
    <td  valign="middle"  width="20%" align="left"><?php $t=explode(",",$s[$i][DAYS]); for ($j=0;$j<count($t);$j++){?>
	&nbsp;<label><input type="radio" name="item" onClick="calItem('<?php echo $t[$j].",";?>','<?php echo $s[$i][PIC_ID];?>')" data-toggle="modal" data-target=".bs-example-modal-lg"><?php echo $t[$j];?></label>
      <!--<label><input type="radio" style="margin-bottom:6px" class="btn btn-primary btn-xs" data-toggle="modal" data-target="#myModal" onClick="calItemm(<?php echo $s[$i][PIC_ID];?>)"  ><?php echo $t[$j];?></span></label>--><br>
	<?php }?></td>
    
  </tr>     
  </tr> 
<?php }?>
</table>
	</p>
	<p class="p__mod">
      
			    	<table width="100%" border="0" cellspacing="5" cellpadding="5" style="background:#FFFFFF"  class=" table-hover table-bordered table-stripped"  id="3">
	  <?php $s=$dbFactory->internal_item(61);
	  for($i=0;$i<count($s);$i++){
				  
					   ?>
                  
  <tr style="font-size:16px">
  
    <td width="20%"><img src="admin/images/<?php echo $s[$i][PIC_ID];?>.jpg" width="100%"></td>
    <td  valign="middle" ><strong><?php echo $s[$i][IMG_NAME];?></strong></td>
   <td  valign="middle"  width="20%"><?php echo $s[$i][COST];?>/-</td>
    <td  valign="middle"  width="20%" align="left"><?php $t=explode(",",$s[$i][DAYS]); for ($j=0;$j<count($t);$j++){?>
	&nbsp;
    
    <label><input type="radio" name="item" onClick="calItem('<?php echo $t[$j].",";?>','<?php echo $s[$i][PIC_ID];?>')" data-toggle="modal" data-target=".bs-example-modal-lg"><?php echo $t[$j];?>
    
    <!--<label><input type="radio" style="margin-bottom:6px" class="btn btn-primary btn-xs" data-toggle="modal" data-target="#myModal" onClick="calItemm(<?php echo $s[$i][PIC_ID];?>)"  ><?php echo $t[$j];?></span></label></label>-->
    <br>
	<?php }?></td>
    
  </tr> 
<?php }?>
</table>
	</p>

	<!--<a class="btn" href="#">More</a>-->
	</div>
	</section>
    

        <?php include("includes/footer.php"); ?>


	
    
</body>
</html>
<script src="js/wow.js"></script>
	<script>
    new WOW().init();
    function chagediv(s)
    {
    //alert(s);
        for(i=1;i<4;i++)
        {
        t="#"+i;
        $(t).hide(500);
        q="#h"+i;
        $(q).css({ 'color': 'white','border-bottom':'5px solid #0494f4','background':'#0494f4'});
        }
    
        q="#h"+s;
        s="#"+s;
        $(s).show(1000);
        $(q).css({ 'color': 'white','border-bottom':'5px solid #3b5a9b','background':'#3b5a9b'});
    
    }
	function calItem(day,id)
	{
		url="ajax/itemNew.php?id="+id+"&day="+day; 
		$.post( url, function( data ) {
		  $( "#item-new" ).html( data );
		});
	}
	function calcost(qty,cost)
	{
		  i=qty*cost;
		  $( "#cost" ).html( i );
		  $('#costofitem').val(i);

	}
	iqty=0;icost=0;
	function addorder(id,date){
	qty=$('#qty').val();
	cost=$('#costofitem').val();
    iqty=parseInt(iqty)+parseInt(qty);
	$( "#items" ).html( iqty );
	  icost=parseInt(icost)+parseInt(cost);
	$( "#amount" ).html( icost );	  

	
	}
    </script>
    
<div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
  <div class="modal-dialog modal-lg">
    <div class="modal-content" >
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel">Please confirm date</h4>
      </div>
      <div class="modal-body" id="item-new">
      Loading..
      </div>
    </div>
  </div>
</div>

